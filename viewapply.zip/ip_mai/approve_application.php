<?php
include 'database.php'; // เชื่อมต่อฐานข้อมูล

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $job_applications_id = isset($_POST['id']) ? intval($_POST['id']) : null;
    $student_id = isset($_POST['student_id']) ? intval($_POST['student_id']) : null;
    $post_id = isset($_POST['post_id']) ? intval($_POST['post_id']) : null;
    $accepted_at = date('Y-m-d H:i:s'); // เวลาปัจจุบัน

    if (!$job_applications_id || !$student_id || !$post_id) {
        echo '<div class="alert alert-danger">❌ ข้อมูลไม่ถูกต้อง!</div>';
        exit();
    }

    // 1️⃣ ตรวจสอบว่าใบสมัครมีอยู่จริง
    $sql = "SELECT id FROM job_applications WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $job_applications_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 0) {
        echo '<div class="alert alert-danger">❌ ไม่พบใบสมัครนี้!</div>';
        exit();
    }

    // 2️⃣ ตรวจสอบว่าใบสมัครนี้ได้รับการอนุมัติแล้วหรือไม่
    $sql = "SELECT id FROM accepted_applications WHERE application_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $job_applications_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        echo '<div class="alert alert-warning">⚠️ ใบสมัครนี้ได้รับการอนุมัติแล้ว!</div>';
        exit();
    }

    // 3️⃣ ตรวจสอบสถานะ "Approved"
    $sql = "SELECT id FROM accept_status WHERE accept_status_name = 'Approved' LIMIT 1";
    $result = $conn->query($sql);
    $accept_status = $result->fetch_assoc();

    if (!$accept_status) {
        echo '<div class="alert alert-danger">❌ ไม่พบสถานะการอนุมัติ!</div>';
        exit();
    }

    $accept_status_id = $accept_status['id'];

    // 4️⃣ บันทึกการอนุมัติลงในฐานข้อมูล
    $sql = "INSERT INTO accepted_applications (application_id, post_id, student_id, accept_status_id, accepted_at) 
            VALUES (?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("iiiis", $job_applications_id, $post_id, $student_id, $accept_status_id, $accepted_at);
    $insert_success = $stmt->execute();

    if (!$insert_success) {
        echo '<div class="alert alert-danger">❌ เกิดข้อผิดพลาดในการอนุมัติใบสมัคร!</div>';
        exit();
    }

    // 5️⃣ เพิ่มข้อมูลการแจ้งเตือน
    $user_id = $student_id;
    $role_id = 3; // สมมติว่า role_id = 3 คือบริษัท
    $event_type = 'job_approved';
    $reference_table = 'accepted_applications';
    $reference_id = $conn->insert_id;
    $message = "🎉 ใบสมัครของคุณได้รับการอนุมัติแล้ว!";
    $status = 'unread';

    $sql_notify = "INSERT INTO notifications (user_id, role_id, event_type, reference_table, reference_id, message, status) 
                   VALUES (?, ?, ?, ?, ?, ?, ?)";
    $stmt_notify = $conn->prepare($sql_notify);
    $stmt_notify->bind_param("iississ", $user_id, $role_id, $event_type, $reference_table, $reference_id, $message, $status);
    $stmt_notify->execute();

    if ($stmt_notify->affected_rows > 0) {
        echo '<div class="alert alert-success">✅ อนุมัติใบสมัครเรียบร้อยแล้ว!</div>';
        echo '<script>
                setTimeout(function() {
                    window.location.href = "view_all_apply.html"; // กลับไปหน้าดูใบสมัครทั้งหมด
                }, 2000); // รอ 2 วินาที
              </script>';
    } else {
        echo '<div class="alert alert-warning">⚠️ อนุมัติสำเร็จ แต่ไม่สามารถส่งการแจ้งเตือนได้!</div>';
    }

    $stmt_notify->close();
    $stmt->close();
}


$conn->close();
?>
