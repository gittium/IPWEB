<?php
include 'database.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $reason_id = isset($_POST['reason_id']) ? intval($_POST['reason_id']) : 0;

    if ($reason_id > 0) {
        $sql = "INSERT INTO reports (reason_id, report_date) VALUES (?, NOW())";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $reason_id);
        if ($stmt->execute()) {
            echo "การรายงานสำเร็จ";
        } else {
            echo "เกิดข้อผิดพลาดในการบันทึกข้อมูล";
        }
    } else {
        echo "กรุณาเลือกเหตุผลที่ถูกต้อง";
    }
}
?>
