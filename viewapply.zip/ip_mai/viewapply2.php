<?php
include 'database.php'; // เชื่อมต่อกับฐานข้อมูล

// รับค่า id และ IP จาก URL
$job_applications_id = isset($_GET['id']) ? $_GET['id'] : null;
$user_ip = isset($_GET['ip']) ? $_GET['ip'] : null;

$job_application = null;
if ($job_applications_id) {
    // ดึงข้อมูลรายละเอียดของงานตาม ID
    $sql = "SELECT job_applications.Resume, students.name, mojor.mojor_name, students.year, job_applications.GPA, students.email, job_applications.phone_number
            FROM job_applications 
            JOIN students ON job_applications.student_id = students.id
            JOIN mojor ON students.major_id = mojor.id
            WHERE job_applications.id = ?";

    $stmt = $conn->prepare($sql); // เตรียมคำสั่ง SQL
    $stmt->bind_param("i", $job_applications_id); // ผูกค่าพารามิเตอร์
    $stmt->execute(); // ประมวลผลคำสั่ง SQL
    $result = $stmt->get_result();
    $job_application = $result->fetch_assoc(); // ดึงข้อมูลเป็น array
}


// ดึงกฎการรายงานจากฐานข้อมูล
$report_reasons = [];
$sql = "SELECT id, report_category_name FROM report_categories";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $report_reasons[] = $row; // เก็บข้อมูลเหตุผลการรายงาน
    }
}

// ตรวจสอบการส่งข้อมูล
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $job_applications_id = isset($_POST['id']) ? intval($_POST['id']) : null;
    $accepted_at = date('Y-m-d H:i:s'); // เวลาปัจจุบัน

    if (!$job_applications_id) {
        echo '<div class="alert alert-danger">❌ ข้อมูลไม่ถูกต้อง!</div>';
        exit();
    }

    // 1️⃣ ตรวจสอบว่า $job_applications_id มีอยู่จริง
    $sql = "SELECT id, student_id, post_jobs_id FROM job_applications WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $$job_applications_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $application = $result->fetch_assoc();

    if (!$application) {
        echo '<div class="alert alert-danger">❌ ไม่พบใบสมัคร!</div>';
        exit();
    }

    $student_id = $application['student_id'];
    $post_id = $application['post_jobs_id'];

    // 2️⃣ ตรวจสอบว่าใบสมัครได้รับการอนุมัติไปแล้วหรือไม่
    $sql = "SELECT id FROM accepted_applications WHERE application_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $$job_applications_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        echo '<div class="alert alert-warning">⚠️ ใบสมัครนี้ได้รับการอนุมัติแล้ว!</div>';
        exit();
    }

    // 3️⃣ ตรวจสอบสถานะ "Approved"
    $sql = "SELECT id FROM accept_status WHERE accept_status_name = 'Approved' LIMIT 1";
    $result = $conn->query($sql);
    $accept_status = $result->fetch_assoc();

    if (!$accept_status) {
        echo '<div class="alert alert-danger">❌ ไม่พบสถานะการอนุมัติ!</div>';
        exit();
    }

    $accept_status_id = $accept_status['id'];

    // 4️⃣ บันทึกลงใน accepted_applications
    $sql = "INSERT INTO accepted_applications (application_id, post_id, student_id, accept_status_id, accepted_at) 
            VALUES (?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("iiiis", $$job_applications_id, $post_id, $student_id, $accept_status_id, $accepted_at);
    $insert_success = $stmt->execute();

    if (!$insert_success) {
        echo '<div class="alert alert-danger">❌ เกิดข้อผิดพลาดในการอนุมัติใบสมัคร!</div>';
        exit();
    }

    // 5️⃣ เพิ่มข้อมูลการแจ้งเตือนลงใน notifications
    $user_id = $student_id;
    $role_id = 3; // สมมติว่า role_id = 3 คือบริษัท
    $event_type = 'job_approved';
    $reference_table = 'accepted_applications';
    $reference_id = $conn->insert_id;
    $message = "🎉 ใบสมัครของคุณได้รับการอนุมัติแล้ว!";
    $status = 'unread';

    $sql_notify = "INSERT INTO notifications (user_id, role_id, event_type, reference_table, reference_id, message, status) 
                   VALUES (?, ?, ?, ?, ?, ?, ?)";
    $stmt_notify = $conn->prepare($sql_notify);
    $stmt_notify->bind_param("iississ", $user_id, $role_id, $event_type, $reference_table, $reference_id, $message, $status);
    $stmt_notify->execute();

    if ($stmt_notify->affected_rows > 0) {
        echo '<div class="alert alert-success">✅ อนุมัติใบสมัครเรียบร้อยแล้ว!</div>';
        echo '<script>
                setTimeout(function() {
                    window.location.href = "viewallapply.html"; // กลับไปหน้าดูใบสมัครทั้งหมด
                }, 2000); // รอ 2 วินาที
              </script>';
    } else {
        echo '<div class="alert alert-warning">⚠️ อนุมัติสำเร็จ แต่ไม่สามารถส่งการแจ้งเตือนได้!</div>';
    }

    $stmt_notify->close();
    $stmt->close();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="View Applications Page">
    <title>View Applications</title>
    <link rel="stylesheet" href="css/viewapply2.css">
    <link rel="stylesheet" href="css/header-footerstyle.css">
</head>
<body>
    <!-- Header ส่วนหัวของเว็บไซต์ -->
    <header class="headerTop">
        <div class="headerTopImg">
            <img src="logo.png" alt="Naresuan University Logo">
            <a href="#">Naresuan University</a>
        </div>
        <nav class="header-nav">
            <a href="#">About Us</a>
            <a href="#">News</a>
            <a href="#">Logout</a>
        </nav>
    </header>

    <!-- Main Content ส่วนแสดงรายละเอียดของผู้สมัคร -->
    <a href="viewallapply.html" class="back-arrow"></a>
    <div class="container">
        <div class="title-container">
            <h1 class="section-title">View Applications (1)</h1>
        </div>
        
        <?php if ($job_application): ?>
        <!-- Applicant Card การ์ดแสดงรายละเอียดของผู้สมัคร -->
        <div class="applicant-card">
            <div class="applicant-photo-name">
                <div class="applicant-photo">
                    <span></span>
                </div> 
                <?php echo strtoupper(mb_substr($job_application['name'], 0, 1, 'UTF-8')); ?>
                <!--<div class="applicant-name"> <!?= htmlspecialchars($job_application['student']) ?> </div> -->
            </div>
            
            <div class="details">
                <label for="resume">Resume / เรซูเม่</label>
            </div>

            <div class="resume">
                <?php
                $resumeFile = 'resumes/' . htmlspecialchars($job_application['Resume']); // ดึงชื่อไฟล์จากฐานข้อมูล
                $fileType = pathinfo($resumeFile, PATHINFO_EXTENSION); // หาชื่อไฟล์และนามสกุล

                if (in_array($fileType, ['jpg', 'jpeg', 'png', 'gif'])) {
                    // หากเป็นไฟล์รูปภาพ
                    echo '<img src="' . $resumeFile . '" alt="Resume Image">';
                } elseif ($fileType == 'pdf') {
                    // หากเป็นไฟล์ PDF
                    echo '<embed src="' . $resumeFile . '" type="application/pdf" width="600" height="400">';
                } else {
                echo '<p>ไฟล์ที่อัพโหลดไม่ใช่ไฟล์ที่รองรับ!</p>';
                }
                ?>
            </div>


            <div class="details">
                <label>Name / ชื่อ</label>
                <span> <?= htmlspecialchars($job_application['name']) ?> </span>

                <label>Field / สาขา</label>
                <span> <?= htmlspecialchars($job_application['mojor_name']) ?> </span>

                <label>Year / ชั้นปี</label>
                <span> <?= htmlspecialchars($job_application['year']) ?> </span>

                <label>GPAX / เกรดเฉลี่ย</label>
                <span> <?= htmlspecialchars($job_application['GPA']) ?> </span>

                <label>E-mail / อีเมล</label>
                <span><a href="mailto:<?= htmlspecialchars($job_application['email']) ?>"> <?= htmlspecialchars($job_application['email']) ?> </a></span>

                <label>Phone / เบอร์ติดต่อ</label>
                <span> <?= htmlspecialchars($job_application['phone_number']) ?> </span>
            </div>

            <!-- Inside the .applicant-card div -->
            <form method="POST" action="approve_application.php">
                <input type="hidden" name="id" value="<?= htmlspecialchars($job_applications['id']) ?>">
                <input type="hidden" name="student_id" value="<?= htmlspecialchars( $job_applications['student_id']) ?>">
                <input type="hidden" name="post_id" value="<?= htmlspecialchars($job_applications['post_jobs_id']) ?>">

                <button type="submit" class="approve-btn">Approve</button>
            </form>
        </div>
        <?php else: ?>
        <p>No application found.</p>
        <?php endif; ?>
    </div>

    <!-- Footer ส่วนท้ายของเว็บไซต์ -->
    <footer class="footer">
        <p>© CSIT - Computer Science and Information Technology</p>
    </footer>

    <script src="js/approve.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>