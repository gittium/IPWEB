// เปิด modal
function showReportModal(event) {
    event.preventDefault(); // ป้องกันการรีเฟรชหน้า
    console.log("เปิด Modal"); // ตรวจสอบว่า function ทำงานไหม
    document.getElementById('reportModal').style.visibility = 'visible';
    document.getElementById('reportModal').style.opacity = '1';
}

// ปิด modal
function closeReportModal() {
    let modal = document.getElementById('reportModal');
    if (modal) {
        modal.style.visibility = 'hidden';
        modal.style.opacity = '0';
    }
}

document.getElementById("submit-report").addEventListener("click", function () {
    var reason = document.getElementById("report-reason").value;

    if (!reason) {
        alert("กรุณาเลือกสาเหตุการรายงาน");
        return;
    }

    // ส่งข้อมูลไปยัง PHP (Ajax)
    fetch("report.php", {
        method: "POST",
        headers: {
            "Content-Type": "application/x-www-form-urlencoded"
        },
        body: "reason_id=" + encodeURIComponent(reason)
    })
    .then(response => response.text())
    .then(data => {
        alert("รายงานสำเร็จ: " + data);
        closeReportModal();
    })
    .catch(error => {
        alert("เกิดข้อผิดพลาด: " + error);
    });
});

// ตรวจสอบว่าปุ่มกดได้หรือไม่
document.addEventListener("DOMContentLoaded", function () {
    let reportButton = document.querySelector(".report-btn");
    let confirmButton = document.getElementById("submit-report");

    if (reportButton) {
        reportButton.addEventListener("click", showReportModal);
    }
    if (confirmButton) {
        confirmButton.addEventListener("click", submitReport);
    }
});
