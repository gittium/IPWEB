document.addEventListener("DOMContentLoaded", function () {
    const approveBtn = document.querySelector(".approve-btn");

    if (approveBtn) {
        approveBtn.addEventListener("click", function () {
            const urlParams = new URLSearchParams(window.location.search);
            const jobApplicationId = urlParams.get("id");

            if (!jobApplicationId) {
                alert("Invalid job application ID.");
                return;
            }

            fetch("approve.php", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ id: jobApplicationId })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert("Application approved successfully!");
                    window.location.href = "view_all_jobs.php"; // กลับไปหน้าเดิม
                } else {
                    alert("Error: " + data.message);
                }
            })
            .catch(error => {
                console.error("Fetch Error:", error);
                alert("An error occurred while approving the application.");
            });
        });
    }
});
