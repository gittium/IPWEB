<?php
header('Content-Type: application/json; charset=utf-8');
require_once 'config.php';  // Make sure this file sets up $db = new mysqli(...);

function buildWhereClause($startDate, $endDate, $category, $status, $reward, $teacher) {
    $where = [];
    if (!empty($startDate) && !empty($endDate)) {
        $where[] = "pj.created_at BETWEEN '$startDate' AND '$endDate'";
    }
    if (!empty($category)) {
        $where[] = "pj.job_categories_id = " . (int)$category;
    }
    if (!empty($status)) {
        $where[] = "pj.job_status_id = " . (int)$status;
    }
    if (!empty($reward)) {
        $where[] = "pj.reward_type_id = " . (int)$reward;
    }
    if (!empty($teacher)) {
        $teacher = addslashes($teacher);
        $where[] = "pj.teachers_id = '$teacher'";
    }
    if (!empty($_GET['month'])) {
        $month = (int)$_GET['month'];
        // This example filters based on the month of pj.created_at.
        $where[] = "MONTH(pj.created_at) = $month";
    }
    return !empty($where) ? "WHERE " . implode(" AND ", $where) : "";
}


// Gather filters
$startDate = $_GET['start']   ?? '';
$endDate   = $_GET['end']     ?? '';
$category  = $_GET['category']?? '';
$status    = $_GET['status']  ?? '';
$reward    = $_GET['reward']  ?? '';
$teacher   = $_GET['teacher'] ?? '';

$endpoint = $_GET['endpoint'] ?? '';
$whereClause = buildWhereClause($startDate, $endDate, $category, $status, $reward, $teacher);

$sql = '';
$data = [];

switch ($endpoint) {
    case 'job-market':
        $sql = "
            SELECT jc.categories_name AS category_name,
                   COUNT(pj.post_jobs_id) AS total_jobs
            FROM job_categories jc
            LEFT JOIN post_jobs pj ON jc.job_categories_id = pj.job_categories_id
            $whereClause
            GROUP BY jc.job_categories_id, jc.categories_name
        ";
        break;

    case 'applications':
        $sql = "
            SELECT p.title,
                   COUNT(a.job_app_id) AS total_applications
            FROM job_application a
            LEFT JOIN post_jobs p ON a.post_jobs_id = p.post_jobs_id
            $whereClause
            GROUP BY p.post_jobs_id, p.title
        ";
        break;

    case 'job-categories-stats':
        $sql = "
            SELECT 
                jc.categories_name,
                COUNT(pj.post_jobs_id) AS total_jobs,
                ROUND(
                  COUNT(pj.post_jobs_id) * 100.0 
                  / NULLIF(
                      (SELECT COUNT(*) FROM post_jobs WHERE job_status_id != 3),
                      0
                  ),
                  1
                ) AS percentage
            FROM job_categories jc
            LEFT JOIN post_jobs pj
                   ON jc.job_categories_id = pj.job_categories_id
                   AND pj.job_status_id != 3
        ";
        if (!empty($whereClause)) {
            $sql .= preg_replace('/^WHERE/i', 'WHERE pj.job_status_id != 3 AND', $whereClause, 1);
        } else {
            $sql .= " WHERE pj.job_status_id != 3";
        }
        $sql .= "
            GROUP BY jc.job_categories_id, jc.categories_name
            ORDER BY total_jobs DESC
        ";
        break;

    case 'job-status-stats':
        $sql = "
            SELECT 
                js.job_status_name,
                COUNT(pj.post_jobs_id) AS total_jobs,
                ROUND(
                    COUNT(pj.post_jobs_id) * 100.0 
                    / (SELECT COUNT(*) FROM post_jobs),
                    1
                ) AS percentage
            FROM job_status js
            LEFT JOIN post_jobs pj ON js.job_status_id = pj.job_status_id
            $whereClause
            GROUP BY js.job_status_id, js.job_status_name
            ORDER BY js.job_status_id
        ";
        break;
        case 'applications-over-time':
            $sql = "
                SELECT 
                    DATE_FORMAT(ja.created_at, '%Y-%m') AS month,
                    COUNT(ja.job_app_id) AS total_applications
                FROM job_application ja
                LEFT JOIN post_jobs pj ON ja.post_jobs_id = pj.post_jobs_id
                $whereClause
                GROUP BY DATE_FORMAT(ja.created_at, '%Y-%m')
                ORDER BY month
            ";
            break;
    
        /*
        |-------------------------------------------------
        | B) MAJOR DISTRIBUTION
        |   Pie chart by major of students who have job_applications
        |-------------------------------------------------
        */
        case 'major-distribution':
            $sql = "
                SELECT 
                    m.major_name,
                    COUNT(s.students_id) AS total_students
                FROM students s
                LEFT JOIN major m ON s.major_id = m.major_id
                LEFT JOIN job_application ja ON s.students_id = ja.students_id
                LEFT JOIN post_jobs pj ON ja.post_jobs_id = pj.post_jobs_id
                $whereClause
                GROUP BY m.major_id, m.major_name
                ORDER BY total_students DESC
            ";
            break;
    
        /*
        |-------------------------------------------------
        | C) AVG GPA
        |   Single row average of ja.GPA
        |-------------------------------------------------
        */
        case 'avg-gpa':
            $sql = "
                SELECT 
                    AVG(ja.GPA) AS avg_gpa
                FROM job_application ja
                LEFT JOIN post_jobs pj ON ja.post_jobs_id = pj.post_jobs_id
                $whereClause
            ";
            break;
    
        /*
        |-------------------------------------------------
        | D) TOP 5 COMPLETED
        |   If accept_status_id=1 is "completed"
        |-------------------------------------------------
        */
        case 'top5-completed':
            $sql = "
                SELECT 
                    s.name,
                    COUNT(aa.accepted_app_id) AS completed_count
                FROM accepted_application aa
                JOIN students s ON aa.students_id = s.students_id
                LEFT JOIN post_jobs pj ON aa.post_jobs_id = pj.post_jobs_id
                WHERE aa.accept_status_id = 1
            ";
    
            // If we want the same $whereClause filters on pj, we must merge it carefully:
            if (!empty($whereClause)) {
                // The $whereClause starts with "WHERE", we already have a "WHERE" above with "aa.accept_status_id=1"
                // So we replace the "WHERE" in $whereClause with "AND" instead:
                $sql .= preg_replace('/^WHERE/i', 'AND', $whereClause, 1);
            }
    
            $sql .= "
                GROUP BY s.students_id, s.name
                ORDER BY completed_count DESC
                LIMIT 5
            ";
            break;

    case 'reward-type-stats':
        $sql = "
            SELECT
                rt.reward_name,
                COUNT(pj.post_jobs_id) AS total_jobs,
                ROUND(
                    COUNT(pj.post_jobs_id) * 100.0 
                    / NULLIF(
                        (SELECT COUNT(*) FROM post_jobs WHERE job_status_id != 3),
                        0
                    ),
                    1
                ) AS percentage
            FROM reward_type rt
            LEFT JOIN post_jobs pj
                   ON rt.reward_type_id = pj.reward_type_id
                   AND pj.job_status_id != 3
        ";
        if (!empty($whereClause)) {
            $sql .= preg_replace('/^WHERE/i','WHERE pj.job_status_id != 3 AND',$whereClause,1);
        } else {
            $sql .= " WHERE pj.job_status_id != 3";
        }
        $sql .= "
            GROUP BY rt.reward_type_id, rt.reward_name
            ORDER BY rt.reward_type_id
        ";
        break;

    case 'pay-rate':
        $sql = "
            SELECT
                COUNT(*) AS total_jobs,
                ROUND(
                    COUNT(CASE WHEN pj.reward_type_id = 1 THEN 1 END) * 100.0 
                    / COUNT(*),
                    2
                ) AS money_percentage,
                ROUND(
                    COUNT(CASE WHEN pj.reward_type_id = 2 THEN 1 END) * 100.0 
                    / COUNT(*),
                    2
                ) AS experience_percentage
            FROM post_jobs pj
            WHERE pj.job_status_id != 3
        ";
        if (!empty($whereClause)) {
            $trimmed = preg_replace('/^WHERE\s+/i', '', $whereClause);
            $sql .= " AND $trimmed";
        }
        break;

    case 'completion-rate':
        $sql = "
            SELECT 
                COUNT(DISTINCT ja.job_app_id) AS total_applications,
                COUNT(DISTINCT CASE WHEN aa.accept_status_id = 1 THEN aa.accepted_app_id END) AS accepted_applications,
                ROUND(
                    COUNT(DISTINCT CASE WHEN aa.accept_status_id = 1 THEN aa.accepted_app_id END) * 100.0
                    / NULLIF(COUNT(DISTINCT ja.job_app_id), 0),
                    2
                ) AS completion_percentage
            FROM job_application ja
            LEFT JOIN accepted_application aa ON ja.job_app_id = aa.job_app_id
            LEFT JOIN post_jobs pj ON ja.post_jobs_id = pj.post_jobs_id
            $whereClause
        ";
        break;


        case 'application-status-distribution':
            $sql = "
                SELECT 
                    COUNT(DISTINCT CASE WHEN aa.accept_status_id = 1 THEN aa.accepted_app_id END) AS accepted_applications,
                    COUNT(DISTINCT CASE WHEN aa.accept_status_id = 2 THEN aa.accepted_app_id END) AS rejected_applications,
                    COUNT(DISTINCT CASE WHEN aa.accept_status_id = 3 THEN aa.accepted_app_id END) AS pending_applications
                FROM job_application ja
                LEFT JOIN accepted_application aa ON ja.job_app_id = aa.job_app_id
                LEFT JOIN post_jobs pj ON ja.post_jobs_id = pj.post_jobs_id
                $whereClause
            ";
            break;
        case 'active-students':
            $sql = "
              SELECT 
                 COUNT(DISTINCT s.students_id) AS total_students,
                 COUNT(DISTINCT CASE WHEN aa.accept_status_id = 1 THEN s.students_id END) AS accepted_students,
                 COUNT(DISTINCT s.students_id) - COUNT(DISTINCT CASE WHEN aa.accept_status_id = 1 THEN s.students_id END) AS not_accepted_students
              FROM students s
              JOIN job_application ja ON s.students_id = ja.students_id
              JOIN post_jobs pj ON ja.post_jobs_id = pj.post_jobs_id
              LEFT JOIN accepted_application aa ON s.students_id = aa.students_id AND aa.accept_status_id = 1
              $whereClause
            ";
            break;
        

    case 'student-performance':
        $sql = "
            SELECT s.name,
                   AVG(r.rating) AS avg_rating
            FROM students s
            LEFT JOIN reviews r ON s.students_id = r.students_id
            LEFT JOIN post_jobs pj ON r.post_jobs_id = pj.post_jobs_id
            $whereClause
            GROUP BY s.students_id, s.name
            ORDER BY avg_rating DESC
        ";
        break;

        case 'active-professors':
            $sql = "
                SELECT 
                    (SELECT COUNT(*) FROM teachers) AS total_professors,
                    COUNT(DISTINCT t.teachers_id) AS active_professors
                FROM teachers t
                JOIN post_jobs pj ON t.teachers_id = pj.teachers_id
                $whereClause
            ";
            break;
        
        
        

    case 'top-professors':
        $sql = "
            SELECT t.name AS name,
                   COUNT(pj.post_jobs_id) AS job_count
            FROM teachers t
            JOIN post_jobs pj ON t.teachers_id = pj.teachers_id
            $whereClause
            GROUP BY t.teachers_id, t.name
            ORDER BY job_count DESC
            LIMIT 5
        ";
        break;

    case 'job-posts':
        $sql = "
            SELECT jc.categories_name, COUNT(pj.post_jobs_id) AS total_jobs
            FROM job_categories jc
            LEFT JOIN post_jobs pj ON jc.job_categories_id = pj.job_categories_id
            $whereClause
            GROUP BY jc.categories_name
        ";
        break;

    case 'top-jobs':
        $sql = "
            SELECT p.title,
                   COUNT(a.job_app_id) AS total_applications
            FROM job_application a
            JOIN post_jobs p ON a.post_jobs_id = p.post_jobs_id
            $whereClause
            GROUP BY p.post_jobs_id, p.title
            ORDER BY total_applications DESC
            LIMIT 5
        ";
        break;

    // NEW: monthly grouping
    case 'jobs-over-time':
        $sql = "
            SELECT DATE_FORMAT(pj.created_at, '%Y-%m') AS month,
                   COUNT(pj.post_jobs_id) AS total_posts
            FROM post_jobs pj
            $whereClause
            GROUP BY DATE_FORMAT(pj.created_at, '%Y-%m')
            ORDER BY month
        ";
        break;

        case 'jobs-taken-overtime':
            $sql = "
                SELECT DATE_FORMAT(pj.job_end, '%Y-%m') AS month,
                       COUNT(pj.post_jobs_id) AS total_jobs_closed
                FROM post_jobs pj
                WHERE pj.job_status_id = 2
            ";
            // Append additional filters (like start/end, category, status, reward, teacher)
            if (!empty($whereClause)) {
                // Replace the initial "WHERE" from $whereClause with "AND" to merge conditions
                $sql .= preg_replace('/^WHERE/i', 'AND', $whereClause, 1);
            }
            // Now, add the month filter on the job_end date for this endpoint
            if (!empty($_GET['month'])) {
                $month = (int)$_GET['month'];
                $sql .= " AND MONTH(pj.job_end) = $month";
            }
            $sql .= "
                GROUP BY DATE_FORMAT(pj.job_end, '%Y-%m')
                ORDER BY month
            ";
            break;
        
    
    // NEW: subcategories distribution
    case 'job-subcategories-stats':
        $sql = "
            SELECT jsc.subcategories_name,
                   COUNT(pj.post_jobs_id) AS total_jobs
            FROM job_subcategories jsc
            LEFT JOIN post_jobs pj ON jsc.job_sub_id = pj.job_sub_id
        ";
        if (!empty($whereClause)) {
            $sql .= " " . $whereClause;
        }
        $sql .= "
            GROUP BY jsc.job_sub_id, jsc.subcategories_name
            ORDER BY total_jobs DESC
        ";
        break;

        case 'applications-per-student':
            $sql = "
                SELECT 
                    s.name AS name,
                    COUNT(ja.job_app_id) AS total_apps
                FROM students s
                JOIN job_application ja 
                    ON s.students_id = ja.students_id
                JOIN post_jobs pj
                    ON ja.post_jobs_id = pj.post_jobs_id
                $whereClause  -- uses filters for date range, category, etc.
                GROUP BY s.students_id, s.name
                ORDER BY total_apps DESC
            ";
            break;

        // FILTER API
    case 'categories-list':
        $sql = "SELECT job_categories_id, categories_name FROM job_categories ORDER BY categories_name";
        $result = $db->query($sql);
        $data = [];
        while ($row = $result->fetch_assoc()) {
            $data[] = $row;
        }
        echo json_encode($data);
        exit;

    case 'status-list':
        $sql = "SELECT job_status_id, job_status_name FROM job_status ORDER BY job_status_id";
        $result = $db->query($sql);
        $data = [];
        while ($row = $result->fetch_assoc()) {
            $data[] = $row;
        }
        echo json_encode($data);
        exit;

    case 'reward-list':
        $sql = "SELECT reward_type_id, reward_name FROM reward_type ORDER BY reward_type_id";
        $result = $db->query($sql);
        $data = [];
        while ($row = $result->fetch_assoc()) {
            $data[] = $row;
        }
        echo json_encode($data);
        exit;
        
    case 'teacher-list':
        $sql = "SELECT teachers_id, name FROM teachers ORDER BY name";
        $result = $db->query($sql);
        $data = [];
        while ($row = $result->fetch_assoc()) {
            $data[] = $row;
        }
        echo json_encode($data);
        exit;

    case 'skills-list' :
        $sql = "SELECT skills_id, skills_name FROM skills ORDER BY skills_id";
        $result = $db->query($sql);
        $data = [];
        while ($row = $result->fetch_assoc()) {
            $data[] = $row;
        }
        echo json_encode($data);
        exit;

    
    case 'top5-students':
    // อ่าน sortBy ว่าเป็น rating หรือ accept
    $sort = $_GET['sort'] ?? 'rating';
    
    if ($sort === 'accept') {
        // เรียงตาม accept_count
        $sql = "
            SELECT s.name,
                   COUNT(aa.accepted_app_id) AS accept_count
            FROM accepted_application aa
            JOIN students s ON aa.students_id = s.students_id
            WHERE aa.accept_status_id = 1
            GROUP BY s.students_id, s.name
            ORDER BY accept_count DESC
            LIMIT 5
        ";
    } else {
        // เรียงตาม rating
        $sql = "
            SELECT s.name,
                   AVG(r.rating) AS avg_rating
            FROM students s
            LEFT JOIN reviews r ON s.students_id = r.students_id
            GROUP BY s.students_id, s.name
            ORDER BY avg_rating DESC
            LIMIT 5
        ";
    }
    break;

    case 'supply-demand-skills':
        // Check if a specific skill is provided via GET
        $skillFilter = isset($_GET['skill']) ? $_GET['skill'] : '';
        
        $sql = "
          SELECT 
              s.skills_name,
              (
                SELECT COUNT(*) 
                FROM students st 
                WHERE FIND_IN_SET(s.skills_id, st.skills) > 0
              ) AS supply,
              (
                SELECT COUNT(*) 
                FROM post_jobs pj 
                WHERE FIND_IN_SET(s.skills_id, pj.skills) > 0
              ) AS demand
          FROM skills s
        ";
        
        if (!empty($skillFilter)) {
          // Only show the specified skill (or you can use IN(...) for multiple skills)
          $sql .= " WHERE s.skills_id = " . intval($skillFilter);
        }
        
        $sql .= " ORDER BY demand DESC";
        break;
    
    

    case 'job-duration-stats':
        // สมมติว่า job_status=2 คือปิดแล้ว
        // ใช้ TIMESTAMPDIFF(DAY, created_at, job_end) เป็น duration
        $sql = "
            SELECT 
                post_jobs_id,
                title,
                TIMESTAMPDIFF(DAY, created_at, job_end) as duration_days
            FROM post_jobs
            WHERE job_status_id=2
            -- $whereClause
            ORDER BY duration_days DESC
        ";
        // execute
        $result = $db->query($sql);
        $rows = [];
        while($r = $result->fetch_assoc()){
            $rows[] = $r;
        }
        echo json_encode($rows);
        break;
        

    case 'top-teachers-by-success':
        /*
            ไอเดีย: success = #jobs accepted & completed / #jobs posted
            สมมติ close job=2 => success
        */
        $sql = "
            SELECT t.name,
                    COUNT(pj.post_jobs_id) as total_posts,
                    SUM(CASE WHEN pj.job_status_id=2 THEN 1 ELSE 0 END) as success_count
            FROM teachers t
            LEFT JOIN post_jobs pj ON pj.teachers_id = t.teachers_id
            GROUP BY t.teachers_id, t.name
            ORDER BY success_count DESC
            LIMIT 5
        ";
        // ...
        break;
                     
    // NEW: professor rating
    case 'professor-rating':
        $sql = "
            SELECT t.name,
            COUNT(cj.post_jobs_id) AS total_closings
        FROM teachers t
        LEFT JOIN post_jobs pj ON t.teachers_id = pj.teachers_id
        LEFT JOIN close_jobs cj ON pj.post_jobs_id = cj.post_jobs_id
        $whereClause
        GROUP BY t.teachers_id, t.name
        ORDER BY total_closings DESC

        ";
        break;

    default:
        echo json_encode(["error" => "Invalid API endpoint"]);
        exit;
}

$result = $db->query($sql);
if (!$result) {
    echo json_encode(["error" => "Query failed: " . $db->error]);
    exit;
}

$data = [];
while ($row = $result->fetch_assoc()) {
    $data[] = $row;
}
echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);

$db->close();
