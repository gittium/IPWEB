<?php
include 'database.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $job_id = $_POST['job_id'];
    $user_ip = $_POST['ip'];
    $reason_id = $_POST['reason'];

    $stmt = $conn->prepare("INSERT INTO reports (job_id, user_ip, reason_id) VALUES (?, ?, ?)");
    $stmt->bind_param("isi", $job_id, $user_ip, $reason_id);
    $stmt->execute();

    echo "รายงานสำเร็จ!";
}
?>
