<?php
include 'database.php'; // เชื่อมต่อกับฐานข้อมูล

// รับค่า id และ IP จาก URL
$job_applications_id = isset($_GET['id']) ? $_GET['id'] : null;
$user_ip = isset($_GET['ip']) ? $_GET['ip'] : null;

$job_application = null;
if ($job_applications_id) {
    // ดึงข้อมูลรายละเอียดของงานตาม ID
    $sql = "SELECT job_applications.Resume, students.name, mojor.mojor_name, students.year, job_applications.GPA, students.email, job_applications.phone_number
            FROM job_applications 
            JOIN students ON job_applications.student_id = students.id
            JOIN mojor ON students.major_id = mojor.id
            WHERE job_applications.id = ?";

    $stmt = $conn->prepare($sql); // เตรียมคำสั่ง SQL
    $stmt->bind_param("i", $job_applications_id); // ผูกค่าพารามิเตอร์
    $stmt->execute(); // ประมวลผลคำสั่ง SQL
    $result = $stmt->get_result();
    $job_application = $result->fetch_assoc(); // ดึงข้อมูลเป็น array
}


// ดึงกฎการรายงานจากฐานข้อมูล
$report_reasons = [];
$sql = "SELECT id, report_category_name FROM report_categories";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $report_reasons[] = $row; // เก็บข้อมูลเหตุผลการรายงาน
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="View Applications Page">
    <title>View Applications</title>
    <link rel="stylesheet" href="viewapply2.css">
    <link rel="stylesheet" href="header-footerstyle.css">
</head>
<body>
    <!-- Header ส่วนหัวของเว็บไซต์ -->
    <header class="headerTop">
        <div class="headerTopImg">
            <img src="logo.png" alt="Naresuan University Logo">
            <a href="#">Naresuan University</a>
        </div>
        <nav class="header-nav">
            <a href="#">About Us</a>
            <a href="#">News</a>
            <a href="#">Logout</a>
        </nav>
    </header>

    <!-- Main Content ส่วนแสดงรายละเอียดของผู้สมัคร -->
    <a href="viewallapply.html" class="back-arrow"></a>
    <div class="container">
        <div class="title-container">
            <h1 class="section-title">View Applications (1)</h1>
        </div>
        
        <?php if ($job_application): ?>
        <!-- Applicant Card การ์ดแสดงรายละเอียดของผู้สมัคร -->
        <div class="applicant-card">
            <div class="applicant-photo-name">
                <div class="applicant-photo">
                    <span></span>
                </div> 
                <?php echo strtoupper(mb_substr($job_application['name'], 0, 1, 'UTF-8')); ?>
                <!--<div class="applicant-name"> <!?= htmlspecialchars($job_application['student']) ?> </div> -->
            </div>
            
            <div class="details">
                <label for="resume">Resume / เรซูเม่</label>
            </div>

            <div class="resume">
                <?php
                $job_applications_id = $job_application['Resume']; // หรือดึงจากตัวแปรที่มีอยู่
                $resumeFile = 'resumes/' . htmlspecialchars($job_application['Resume']); // ดึงชื่อไฟล์จากฐานข้อมูล
                // แสดงรูปภาพหากเป็นรูป
                echo '<img src="fetch_resume.php?id=' . htmlspecialchars($job_applications_id) . '" alt="Resume Image" >';

                // หรือแสดง PD
                // F ถ้าเป็นไฟล์ PDF
                // echo '<embed src="fetch_resume.php?id=' . htmlspecialchars($application_id) . '" type="application/pdf" width="600" height="400">';
                ?>
            </div>

            <div class="details">
                <label>Name / ชื่อ</label>
                <span> <?= htmlspecialchars($job_application['name']) ?> </span>

                <label>Field / สาขา</label>
                <span> <?= htmlspecialchars($job_application['mojor_name']) ?> </span>

                <label>Year / ชั้นปี</label>
                <span> <?= htmlspecialchars($job_application['year']) ?> </span>

                <label>GPAX / เกรดเฉลี่ย</label>
                <span> <?= htmlspecialchars($job_application['GPA']) ?> </span>

                <label>E-mail / อีเมล</label>
                <span><a href="mailto:<?= htmlspecialchars($job_application['email']) ?>"> <?= htmlspecialchars($job_application['email']) ?> </a></span>

                <label>Phone / เบอร์ติดต่อ</label>
                <span> <?= htmlspecialchars($job_application['phone_number']) ?> </span>
            </div>

            <button class="approve-btn">Approve</button>
        </div>
        <?php else: ?>
        <p>No application found.</p>
        <?php endif; ?>
    </div>

    <!-- Footer ส่วนท้ายของเว็บไซต์ -->
    <footer class="footer">
        <p>© CSIT - Computer Science and Information Technology</p>
    </footer>

    <script src="approve.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>