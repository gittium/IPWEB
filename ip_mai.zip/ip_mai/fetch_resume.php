<?php
require 'db_connect.php'; // เชื่อมต่อฐานข้อมูล

// รับ ID ของใบสมัครจาก URL
$job_application_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// ดึงข้อมูลเรซูเม่จากฐานข้อมูล
$stmt = $conn->prepare("SELECT Resume, mime_type FROM job_applications WHERE id = ?");
$stmt->bind_param("i", $job_application_id);
$stmt->execute();
$stmt->bind_result($resumeData, $mimeType);
$stmt->fetch();
$stmt->close();
$conn->close();

if ($resumeData) {
    header("Content-Type: " . $mimeType); // ส่ง header ที่บอกประเภทไฟล์ เช่น application/pdf, image/jpeg
    echo $resumeData; // ส่งข้อมูลเรซูเม่ไปยังเบราว์เซอร์
    exit;
}

// ถ้าไม่พบเรซูเม่
http_response_code(404);
echo "Resume not found";
?>
