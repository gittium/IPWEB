<?php
include 'database.php'; // เชื่อมต่อฐานข้อมูล

// อ่าน JSON ที่ส่งมา
$data = json_decode(file_get_contents("php://input"), true);

if (!isset($data['id'])) {
    error_log("❌ ERROR: Invalid request, missing application ID.");
    echo json_encode(["success" => false, "message" => "Invalid request."]);
    exit();
}

$job_applications_id = $data['id'];
$accepted_at = date('Y-m-d H:i:s'); // เวลาปัจจุบัน

// 🔍 ตรวจสอบว่า job_application_id ถูกต้องไหม
error_log("🔍 Approving application ID: " . $job_applications_id);

// 1️⃣ ดึงข้อมูลใบสมัครจากฐานข้อมูล
$sql = "SELECT id, student_id, post_jobs_id FROM job_applications WHERE id = ?";
$stmt = $conn->prepare($sql);

if (!$stmt) {
    error_log("❌ ERROR: SQL Prepare failed - " . $conn->error);
    echo json_encode(["success" => false, "message" => "SQL Prepare failed."]);
    exit();
}

$stmt->bind_param("i", $job_applications_id);
$stmt->execute();
$result = $stmt->get_result();
$application = $result->fetch_assoc();

if (!$application) {
    error_log("❌ ERROR: Job application not found for ID " . $job_applications_id);
    echo json_encode(["success" => false, "message" => "Job application not found."]);
    exit();
}

$student_id = $application['student_id'];
$post_id = $application['post_jobs_id']; // ใช้ post_jobs_id แทน post_id

// 2️⃣ ตรวจสอบสถานะ "Approved" ในตาราง accept_status
$sql = "SELECT id FROM accept_status WHERE accept_status_name = 'Approved' LIMIT 1";
$result = $conn->query($sql);
$accept_status = $result->fetch_assoc();

if (!$accept_status) {
    error_log("❌ ERROR: Accept status 'Approved' not found.");
    echo json_encode(["success" => false, "message" => "Accept status not found."]);
    exit();
}

$accept_status_id = $accept_status['id'];

// 3️⃣ อัปเดตสถานะ job_applications
$sql = "UPDATE job_applications SET status = 'approved' WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $job_applications_id);
$update_success = $stmt->execute();

if (!$update_success) {
    error_log("❌ ERROR: Failed to update job_applications - " . $stmt->error);
    echo json_encode(["success" => false, "message" => "Failed to update job application."]);
    exit();
}

// 4️⃣ เพิ่มข้อมูลเข้า accepted_applications
$sql = "INSERT INTO accepted_applications (application_id, post_id, student_id, accept_status_id, accepted_at) 
        VALUES (?, ?, ?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("iiiis", $job_applications_id, $post_id, $student_id, $accept_status_id, $accepted_at);
$insert_success = $stmt->execute();

if (!$insert_success) {
    error_log("❌ ERROR: Failed to insert into accepted_applications - " . $stmt->error);
    echo json_encode(["success" => false, "message" => "Failed to insert into accepted applications."]);
    exit();
}

error_log("✅ SUCCESS: Application approved successfully.");
echo json_encode(["success" => true, "message" => "Application approved!"]);

$conn->close();
?>
