function showReportModal() {
    document.getElementById('reportModal').style.display = 'flex';
}

function closeReportModal() {
    document.getElementById('reportModal').style.display = 'none';
}

function submitReport() {
    let selectedReason = document.getElementById("report-reason").value;
    if (selectedReason) {
        alert("รายงานเหตุผล: " + selectedReason);
        // ส่งไปยังเซิร์ฟเวอร์
        window.location.href = "report_process.php?reason_id=" + selectedReason;
    }
}