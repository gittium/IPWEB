<?php
session_start();
include 'database.php';

$category = isset($_GET['category']) ? urldecode($_GET['category']) : '';

$sql = "SELECT post_jobs.id, post_jobs.job_status_id, post_jobs.title, post_jobs.image, job_categories.category_name AS category, teachers.name AS teacher
        FROM post_jobs 
        JOIN teachers ON post_jobs.teacher_id = teachers.id
        JOIN job_categories ON post_jobs.category_id = job_categories.id
        WHERE job_categories.category_name = ?
        ORDER BY post_jobs.id DESC";

$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $category);
$stmt->execute();
$result = $stmt->get_result();

$jobs = [];
while ($row = $result->fetch_assoc()) {
    if ($row["job_status_id"] == 1) {
        $jobs[] = $row;
    }
}

$stmt->close();
$conn->close();
?>

<!-- index.html -->
<!DOCTYPE html>
<html lang="th">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CSIT Job Board</title>
    <!-- Bootstrap Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <!-- External CSS -->
    <link rel="stylesheet" href="css/navbar.css">
    <link rel="stylesheet" href="css/filter.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="css/styles.css">
    <link rel="stylesheet" href="css/header-footerstyle.css">
    <link rel="stylesheet" href="css/view_all_jobs.css">
</head>

<body>
    <!-- Header -->
    <header class="headerTop">
        <div class="headerTopImg">
            <img src="logo.png" alt="Naresuan University Logo">
            <a href="#">Naresuan University</a>
        </div>
        <nav class="header-nav">
            <?php
            // ตรวจสอบสถานะการล็อกอิน
            if (isset($_SESSION['user_id'])) {
                if ($_SESSION['user_role'] == 3) {
                    // หาก Role คือ 3 (อาจารย์)
                    echo '<a href="teacher_profile.php">Profile</a>';
                } elseif ($_SESSION['user_role'] == 4) {
                    // หาก Role คือ 4 (นิสิต)
                    echo '<a href="student_profile.php">Profile</a>';
                }
               
            } else {
                // หากยังไม่ได้ล็อกอิน แสดงปุ่มเข้าสู่ระบบ
                echo '<a href="login.php">Login</a>';
            }
            ?>
        </nav>
    </header>


    <!-- Navbar Placeholder -->
    <div id="navbar-placeholder"></div>

    <!-- Filter Placeholder -->
    <div id="filter-placeholder"></div>


    <div id="contentWrapper" class="content-wrapper"></div>



    <main class="main-content">
        <div class="content">
            <h1 class="category-head">งานทั้งหมดในหมวด <?php echo htmlspecialchars($category); ?></h1>
            <?php if (empty($jobs)): ?>
                <p class="no-jobs">ไม่มีการประกาศงานประเภทนี้</p>
            <?php else: ?>
                <div class="job-grid">
                    <?php foreach ($jobs as $job): ?>
                        <a href="joinustest.php?id=<?php echo htmlspecialchars($job['id']); ?>&ip=<?php echo $_SERVER['REMOTE_ADDR']; ?>">
                            <div class="job-card">
                                <img class="job-image" src="<?php echo isset($job["image"]) ? htmlspecialchars($job["image"]) : "images/default.jpg"; ?>" alt="Job Image">
                                <div class="job-info">
                                    <div class="job-title"><?php echo htmlspecialchars($job["title"]); ?></div>
                                    <div class="job-author"><?php echo htmlspecialchars($job["teacher"]); ?></div>
                                </div>
                            </div>
                        </a>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </main>

   
    <!-- External JS -->
    <script src="js/main.js"></script>
    <script src="js/navbar.js"></script>
    <script src="js/filter.js"></script>

</body>

</html>