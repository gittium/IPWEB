<?php
session_start();
include 'database.php';

// ตรวจสอบว่าเป็น AJAX Request หรือไม่
$is_ajax = isset($_GET['ajax']) && $_GET['ajax'] == "1";

// รับค่า id และฟิลเตอร์
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$filter_major = isset($_GET['major']) ? $_GET['major'] : '';
$filter_year = isset($_GET['year']) ? $_GET['year'] : '';

// ตรวจสอบค่าที่รับมา
if ($id <= 0) {
    die(json_encode(["error" => "ไม่พบข้อมูลงานที่ต้องการ"]));
}

// สร้าง SQL Query
$sql = "SELECT DISTINCT 
    ja.id AS job_application_id, 
    ja.post_jobs_id, 
    s.id AS student_id, 
    s.name, 
    s.year, 
    m.mojor_name 
FROM job_applications ja 
JOIN students s ON ja.student_id = s.id
JOIN mojor m ON s.major_id = m.id
WHERE ja.post_jobs_id = ?
";

$params = [$id];
$types = "i";

// เพิ่มตัวกรอง Major
if (!empty($filter_major)) {
    $sql .= " AND m.mojor_name = ?";
    $params[] = $filter_major;
    $types .= "s";
}

// เพิ่มตัวกรอง Year
if (!empty($filter_year)) {
    $sql .= " AND s.year = ?";
    $params[] = $filter_year;
    $types .= "i";
}

// เตรียม SQL Statement
$stmt = $conn->prepare($sql);
$stmt->bind_param($types, ...$params);
$stmt->execute();
$result = $stmt->get_result();

// **คืนค่าเป็น JSON ถ้าเป็น AJAX Request**
if ($is_ajax) {
    $applicants = [];
    while ($row = $result->fetch_assoc()) {
        $applicants[] = $row;
    }
    echo json_encode($applicants);
    exit;
}

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Teaching Assistant View Applications Page">
    <title>Teaching Assistant Applications</title>
    <!-- Google Fonts -->
    <link
        href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&family=Montserrat:wght@600&display=swap"
        rel="stylesheet">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <link rel="stylesheet" href="css/viewapply.css">
    <link rel="stylesheet" href="css/header-footerstyle.css">

</head>

<body>
    <!-- Header -->
    <header class="headerTop">
        <div class="headerTopImg">
            <img src="logo.png" alt="Naresuan University Logo">
            <a href="#">Naresuan University</a>
        </div>
        <nav class="header-nav">
            <?php
            // ตรวจสอบสถานะการล็อกอิน
            if (isset($_SESSION['user_id'])) {
                echo '<a href="logout.php">Logout</a>';
            } else {
                // หากยังไม่ได้ล็อกอิน แสดงปุ่มเข้าสู่ระบบ
                echo '<a href="login.php">Login</a>';
            }
            ?>
        </nav>
    </header>

    <!-- ปุ่ม back -->
    <div>
        <a href="teacher_profile.php" class="back-arrow"></a>
    </div>

    <!-- Main Content -->
    <div class="container">
        <div class="title-container">
            <a href="viewapply.php?id=<?php echo $id; ?>">View Applications</a> <!-- ลิงก์ไปยัง viewapply.php -->
            <a href="jobmanage.php?id=<?php echo $id; ?>">Manage Job</a> <!-- ลิงก์ไปยัง jobmanage.php -->
        </div>
        <br>
        <div>
            <h1>Teaching Assistant</h1>
        </div>
        <br>
        <div class="bar">
            <a href="viewapply.php" class="<?= empty($_GET['major']) ? 'active' : '' ?>">ทั้งหมด</a>
            <a href="viewapply.php?major=Computer Science" class="<?= isset($_GET['major']) && $_GET['major'] == 'Computer Science' ? 'active' : '' ?>">วิทยาการคอมพิวเตอร์</a>
            <a href="viewapply.php?major=Information Technology" class="<?= isset($_GET['major']) && $_GET['major'] == 'Information Technology' ? 'active' : '' ?>">เทคโนโลยีสารสนเทศ</a>
            <i class="bi bi-filter ms-auto" id="filter-btn" style="cursor: pointer;"></i>
        </div>

        <!-- ฟิลเตอร์ -->
        <div id="hidden-message" class="message-box">สาขา<br>
            <button class="branch-btn" data-major="Computer Science">วิทยาการคอมพิวเตอร์</button>
            <button class="branch-btn" data-major="Information Technology">เทคโนโลยีสารสนเทศ</button>

            <br><br>
            <p>ชั้นปี</p>
            <button class="year-btn" data-year="1">ปี 1</button>
            <button class="year-btn" data-year="2">ปี 2</button>
            <button class="year-btn" data-year="3">ปี 3</button>
            <button class="year-btn" data-year="4">ปี 4</button>

            <br><br>
            <button id="clear-btn">ล้าง</button>
            <button id="apply-btn">ตกลง</button>
        </div>
    </div>

    <div class="application-list">
        <!-- รายการใบสมัคร -->
        <?php if ($result && $result->num_rows > 0): ?>
            <?php while ($row = $result->fetch_assoc()): ?>
                <div class="application-card">

                    <div class="profile-img"></div>
                    <div class="details">
                        <div class="name"><?= htmlspecialchars($row['name']) ?></div>
                        <div class="department">สาขา <?= htmlspecialchars($row['mojor_name']) ?></div>
                        <div class="year">ปี <?= htmlspecialchars($row['year']) ?></div>
                    </div>
                    <a href="viewapply2.php?id=<?php echo $row['job_application_id']; ?>" class="chevron-link">
                        <i class="bi bi-chevron-right"></i>
                    </a>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <p>ไม่พบข้อมูลการสมัคร</p>
        <?php endif; ?>
    </div>

    </div>
    <!-- Footer -->

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-..." crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-..." crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script src="js/viewapply.js"></script>
</body>

</html>