<?php
// เชื่อมต่อกับฐานข้อมูล
include 'db_connect.php';

// สร้างการเชื่อมต่อ
$conn = new mysqli($servername, $username, $password, $dbname);

// ตรวจสอบการเชื่อมต่อ
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// รับค่า role_id จากพารามิเตอร์ GET
$role_id = isset($_GET['role_id']) ? intval($_GET['role_id']) : 0;

// ตรวจสอบว่า role_id เป็นค่าที่ถูกต้อง
if ($role_id > 0) {
    // คำสั่ง SQL เพื่อดึงข้อมูล Permissions ตาม Role
    $sql = "SELECT p.id, p.name, rp.status 
            FROM permissions p
            LEFT JOIN role_permissions rp ON p.id = rp.permission_id AND rp.role_id = ?";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $role_id);
    $stmt->execute();
    $result = $stmt->get_result();

    $permissions = [];
    
    // ดึงข้อมูล Permissions
    while ($row = $result->fetch_assoc()) {
        $permissions[] = [
            'id' => $row['id'],
            'name' => $row['name'],
            'status' => $row['status'] // 1 = เปิด, 0 = ปิด
        ];
    }

    // ส่งคืนข้อมูลในรูปแบบ JSON
    header('Content-Type: application/json');
    echo json_encode(['permissions' => $permissions]);
} else {
    // ถ้า role_id ไม่ถูกต้อง ส่งคืนข้อมูลว่าง
    header('Content-Type: application/json');
    echo json_encode(['permissions' => []]);
}

// ปิดการเชื่อมต่อ
$conn->close();
?>
