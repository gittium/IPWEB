<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

// โค้ดที่มีข้อผิดพลาด (เพื่อทดสอบว่ามันแสดง Error หรือไม่)
echo $undefined_variable;
?>
