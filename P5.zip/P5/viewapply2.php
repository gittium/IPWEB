<?php
session_start();
include 'database.php'; // เชื่อมต่อกับฐานข้อมูล

// รับค่า id และ IP จาก URL
$job_applications_id = isset($_GET['id']) ? $_GET['id'] : null;

$job_application = null;
if ($job_applications_id) {
    // ดึงข้อมูลรายละเอียดของงานตาม ID
    $sql = "SELECT post_jobs.title, job_applications.Resume, students.name, students.id, mojor.mojor_name, students.year, job_applications.GPA, students.email, job_applications.phone_number
            FROM job_applications 
            JOIN post_jobs ON job_applications.post_jobs_id = post_jobs.id
            JOIN students ON job_applications.student_id = students.id
            JOIN mojor ON students.major_id = mojor.id
            WHERE job_applications.id = ?";

    $stmt = $conn->prepare($sql); // เตรียมคำสั่ง SQL
    $stmt->bind_param("i", $job_applications_id); // ผูกค่าพารามิเตอร์
    $stmt->execute(); // ประมวลผลคำสั่ง SQL
    $result = $stmt->get_result();
    $job_application = $result->fetch_assoc(); // ดึงข้อมูลเป็น array
}

$conn->close();
?> 

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="View Applications Page">
    <title>View Applications</title>
    <link rel="stylesheet" href="css/viewapply2.css">
    <link rel="stylesheet" href="css/header-footerstyle.css">
</head>

<body>
    <!-- Header ส่วนหัวของเว็บไซต์ -->
    <header class="headerTop">
        <div class="headerTopImg">
            <img src="logo.png" alt="Naresuan University Logo">
            <a href="#">Naresuan University</a>
        </div>
        <nav class="header-nav">
            <?php
            // ตรวจสอบสถานะการล็อกอิน
            if (isset($_SESSION['user_id'])) {
                echo '<a href="logout.php">Logout</a>';
            } else {
                // หากยังไม่ได้ล็อกอิน แสดงปุ่มเข้าสู่ระบบ
                echo '<a href="login.php">Login</a>';
            }
            ?>
        </nav>
    </header>

    <!-- Main Content ส่วนแสดงรายละเอียดของผู้สมัคร -->
    <a href="javascript:window.history.back();" class="back-arrow"></a>
    <div class="container">
        <div class="title-container">
            <h1 class="section-title"><?php echo htmlspecialchars($job_application['title']); ?></h1>
        </div>

        <?php if ($job_application): ?>
        <!-- Applicant Card การ์ดแสดงรายละเอียดของผู้สมัคร -->
        <div class="applicant-card">
            <a href="profilestapplication.php?id=<?php echo $job_application['id']; ?>" class="photo-link">
                <div class="applicant-photo-name">
                    <div class="applicant-photo">
                        <?php
                        $photoPath = "path/to/student/photo.jpg"; // เปลี่ยนเป็น path ของรูปภาพจริง
                        if (file_exists($photoPath)) {
                            echo '<img src="' . $photoPath . '" alt="Applicant Photo" class="applicant-photo-img">';
                        } else {
                            echo '<span>' . strtoupper(mb_substr($job_application['name'], 0, 1, 'UTF-8')) . '</span>';
                        }
                        ?>
                    </div>
                </div>
            </a>

            <div class="details">
                <label for="resume">Resume / เรซูเม่</label>
            </div>

            <!-- แก้ไขส่วนนี้เพื่อเรียกใช้ฟังก์ชัน openFullscreenResume -->
            <div class="resume"
                onclick="openFullscreenResume('<?php echo htmlspecialchars($job_application['Resume']); ?>')">
                <?php
                    $resumeFile = htmlspecialchars($job_application['Resume']); // ดึงชื่อไฟล์จากฐานข้อมูล

                    if (file_exists($resumeFile)) {
                        $fileType = pathinfo($resumeFile, PATHINFO_EXTENSION); // ดึงประเภทไฟล์
            
                        // ตรวจสอบประเภทไฟล์
                        if (in_array($fileType, ['jpg', 'jpeg', 'png', 'gif'])) {
                            echo '<img src="' . $resumeFile . '" class="img-fluid" style="max-height: 400px; object-fit: cover;" alt="Resume Image">';
                        } elseif ($fileType == 'pdf') {
                            echo '<embed src="' . $resumeFile . '" type="application/pdf" class="w-100" style="height: 500px;">';
                        } else {
                            echo '<p>ไฟล์เรซูเม่ไม่รองรับประเภทนี้</p>';
                            echo '<p class="text-danger">ไฟล์ที่อัพโหลดไม่ใช่ไฟล์ที่รองรับ!</p>';
                        }
                    } else {
                        echo '<p class="text-warning">ไม่พบไฟล์เรซูเม่ในระบบ!</p>';
                    }
                    ?>
            </div>

            <div class="details">
                <label>Name / ชื่อ :</label>
                <span> <?= htmlspecialchars($job_application['name']) ?> </span>

                <label>Field / สาขา :</label>
                <span> <?= htmlspecialchars($job_application['mojor_name']) ?> </span>

                <label>Year / ชั้นปี :</label>
                <span> <?= htmlspecialchars($job_application['year']) ?> </span>

                <label>GPAX / เกรดเฉลี่ย :</label>
                <span> <?= number_format($job_application['GPA'], 1) ?> </span>
                <label>E-mail / อีเมล :</label>
                <span><a href="mailto:<?= htmlspecialchars($job_application['email']) ?>">
                        <?= htmlspecialchars($job_application['email']) ?> </a></span>

                <label>Phone / เบอร์ติดต่อ :</label>
                <span> <?= htmlspecialchars($job_application['phone_number']) ?> </span>
            </div>

            <div id="message-container"></div>
            <form method="POST" action="approve_application.php">
                <input type="hidden" name="id" value="<?= htmlspecialchars($job_applications_id) ?>">
                <input type="hidden" name="student_id" value="<?= htmlspecialchars($job_applications['student_id']) ?>">
                <input type="hidden" name="post_id" value="<?= htmlspecialchars($job_applications['post_jobs_id']) ?>">

                <!-- ปุ่ม Reject -->
                <button type="button" class="reject-btn" id="reject-btn"
                    data-application-id="<?= htmlspecialchars($job_applications_id) ?>"
                    data-action="reject">Reject</button>

                <!-- ปุ่ม Approve -->
                <button type="button" class="approve-btn" id="approve-btn"
                    data-application-id="<?= htmlspecialchars($job_applications_id) ?>"
                    data-action="approve">Approve</button>
            </form>

        </div>
        <?php else: ?>
        <p>No application found.</p>
        <?php endif; ?>
    </div>

    <!-- Modal สำหรับแสดง Resume แบบเต็มหน้าจอ -->
    <div id="fullscreenResumeModal" class="modal">
        <span class="close" onclick="closeFullscreenResume()">&times;</span>
        <div id="fullscreenResumeContent" class="modal-content"></div>
    </div>

    <!-- Footer ส่วนท้ายของเว็บไซต์ -->
    <footer class="footer">
        <p>© CSIT - Computer Science and Information Technology</p>
    </footer>

    <script src="js/fullscreenResume.js"></script>
    <script src="js/approve.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>