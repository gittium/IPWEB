<a href="profilestapplication.php?id=<?php echo 64312132; ?>" class="btn btn-info">
    ดูโปรไฟล์
</a>
