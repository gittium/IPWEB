document.addEventListener("DOMContentLoaded", function() {
    const filterBtn = document.getElementById("filter-btn"); // ปุ่ม filter
    const messageBox = document.getElementById("hidden-message"); // กล่อง filter

    if (filterBtn && messageBox) {
        filterBtn.addEventListener("click", function() {
            // ซ่อน/แสดง message-box
            if (messageBox.style.display === "none" || messageBox.style.display === "") {
                messageBox.style.display = "block";
            } else {
                messageBox.style.display = "none";
            }
        });
    }
});

document.addEventListener("DOMContentLoaded", function() {
    const applyBtn = document.getElementById("apply-btn");
    const clearBtn = document.getElementById("clear-btn");
    const applicationList = document.querySelector(".application-list");
    const barLinks = document.querySelectorAll(".bar a");
    const branchButtons = document.querySelectorAll(".branch-btn");
    const yearButtons = document.querySelectorAll(".year-btn");

    let selectedFilters = {
        major: new URLSearchParams(window.location.search).get('major') || null,
        year: new URLSearchParams(window.location.search).get('year') || null
    };
    // **กดปุ่ม Bar เพื่อเปลี่ยนสาขา**
    barLinks.forEach(link => {
        link.addEventListener("click", function(event) {
            event.preventDefault();
            const params = new URLSearchParams();
            const major = new URL(this.href).searchParams.get("major");
            if (major) {
                params.append("major", major);
            }
            fetchApplications(params);
        });
    });
    // **ฟังก์ชัน Fetch ข้อมูลใบสมัคร**
    
    // ไฮไลท์ปุ่มที่ถูกเลือกเมื่อโหลดหน้าใหม่
    branchButtons.forEach(button => {
        let value = button.getAttribute("data-major");
        if (selectedFilters.major === value) {
            button.classList.add("active");
        }

        button.addEventListener("click", function() {
            if (selectedFilters.major === value) {
                selectedFilters.major = null;
                this.classList.remove("active");
            } else {
                selectedFilters.major = value;
                branchButtons.forEach(btn => btn.classList.remove("active"));
                this.classList.add("active");
            }
        });
    });

    yearButtons.forEach(button => {
        let value = button.getAttribute("data-year");
        if (selectedFilters.year === value) {
            button.classList.add("active");
        }

        button.addEventListener("click", function() {
            if (selectedFilters.year === value) {
                selectedFilters.year = null;
                this.classList.remove("active");
            } else {
                selectedFilters.year = value;
                yearButtons.forEach(btn => btn.classList.remove("active"));
                this.classList.add("active");
            }
        });
    });
    // **เมื่อกด "ตกลง" ให้ Fetch ข้อมูลใหม่**
    applyBtn.addEventListener("click", function() {
        let params = new URLSearchParams();
        if (selectedFilters.major) {
            params.append("major", selectedFilters.major);
        }
        if (selectedFilters.year) {
            params.append("year", selectedFilters.year);
        }
        fetchApplications(params);
    });
    // **ปุ่มล้างค่าฟิลเตอร์**
    // ✅ เมื่อกด "ล้าง" ให้รีเซ็ตค่าฟิลเตอร์และ Fetch ข้อมูลใหม่
    clearBtn.addEventListener("click", function() {
        selectedFilters.major = null;
        selectedFilters.year = null;

        branchButtons.forEach(btn => btn.classList.remove("active"));
        yearButtons.forEach(btn => btn.classList.remove("active"));

        let params = new URLSearchParams();
        fetchApplications(params);
    });



    // **ปุ่ม Filter แสดง/ซ่อน Filter Box**
    if (filterBtn && messageBox) {
        filterBtn.addEventListener("click", function() {
            messageBox.style.display = messageBox.style.display === "none" ? "block" : "none";
        });
    }
});