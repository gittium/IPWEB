// fullscreenResume.js

// ฟังก์ชันเปิด modal และแสดง Resume แบบเต็มหน้าจอ
function openFullscreenResume(resumeFile) {
    const modal = document.getElementById('fullscreenResumeModal');
    const content = document.getElementById('fullscreenResumeContent');
    const fileType = resumeFile.split('.').pop();

    // ตรวจสอบประเภทไฟล์และแสดงผลตามนั้น
    if (fileType === 'pdf') {
        content.innerHTML = `<embed src="${resumeFile}" type="application/pdf" class="w-100" style="height: 90vh;">`;
    } else if (['jpg', 'jpeg', 'png', 'gif'].includes(fileType)) {
        content.innerHTML = `<img src="${resumeFile}" style="max-width: 100%; max-height: 90vh;">`;
    } else {
        content.innerHTML = '<p>ไฟล์เรซูเม่ไม่รองรับประเภทนี้</p>';
    }

    modal.style.display = 'flex'; // ใช้ flex เพื่อจัดให้อยู่ตรงกลาง
}

// ฟังก์ชันปิด modal
function closeFullscreenResume() {
    const modal = document.getElementById('fullscreenResumeModal');
    modal.style.display = 'none';
}

// ปิด modal เมื่อคลิกนอกเนื้อหา
window.onclick = function (event) {
    const modal = document.getElementById('fullscreenResumeModal');
    if (event.target == modal) {
        modal.style.display = 'none';
    }
}
