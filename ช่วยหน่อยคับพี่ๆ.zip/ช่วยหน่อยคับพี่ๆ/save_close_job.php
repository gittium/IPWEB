<?php
header('Content-Type: application/json');
include 'database.php';

try {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception('Invalid request method');
    }

    $jobId = $_POST['job_id'] ?? null;
    $reasonId = $_POST['close_detail_id'] ?? null;
    $detail = trim($_POST['detail'] ?? '');

    if (!$jobId || !$reasonId) {
        throw new Exception('Missing parameters');
    }

    $stmt = $conn->prepare("INSERT INTO close_job (post_job_id, close_detail_id, detail, created_at) VALUES (?, ?, ?, NOW())");
    $stmt->bind_param('iis', $jobId, $reasonId, $detail);

    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'message' => 'Reason saved successfully']);
    } else {
        throw new Exception('Failed to save reason: ' . $stmt->error);
    }

    $stmt->close();
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}

$conn->close();
