<?php
header('Content-Type: application/json');
include 'database.php';

$job_id = $_POST['job_id'];
$new_status = $_POST['new_status'];

$sql = "UPDATE post_job SET job_status_id = ? WHERE post_job_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ii", $new_status, $job_id);

if ($stmt->execute()) {
    echo 'success';
} else {
    echo 'error: ' . $stmt->error;
}

$stmt->close();
$conn->close();
?>