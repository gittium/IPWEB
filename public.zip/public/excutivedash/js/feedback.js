// feedback.js

// Chart Configurations
const chartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
        legend: {
            position: 'bottom',
            labels: {
                boxWidth: 12,
                font: { size: 11 }
            }
        },
        title: {
            display: true,
            font: { size: 14 }
        }
    },
    scales: {
        y: {
            beginAtZero: true,
            ticks: {
                font: { size: 11 }
            },
            grid: {
                color: 'rgba(0, 0, 0, 0.1)'
            }
        },
        x: {
            ticks: {
                font: { size: 11 }
            },
            grid: {
                display: false
            }
        }
    }
};

// 1. Satisfaction and Feedback Metrics

// Overall Satisfaction Score (Doughnut Chart)
const satisfactionCtx = document.getElementById('satisfactionChart').getContext('2d');
new Chart(satisfactionCtx, {
    type: 'doughnut',
    data: {
        labels: ['Satisfied', 'Neutral', 'Dissatisfied'],
        datasets: [{
            data: [70, 20, 10],
            backgroundColor: [
                '#4CAF50',
                '#FFC107',
                '#f44336'
            ]
        }]
    },
    options: {
        ...chartOptions,
        plugins: {
            ...chartOptions.plugins,
            title: {
                text: 'Overall Satisfaction Score'
            },
            tooltip: {
                callbacks: {
                    label: function(context) {
                        const label = context.label || '';
                        const value = context.parsed;
                        return `${label}: ${value}%`;
                    }
                }
            }
        }
    }
});

// Net Promoter Score (NPS) (Pie Chart)
// const npsCtx = document.getElementById('npsChart').getContext('2d');
// new Chart(npsCtx, {
//     type: 'pie',
//     data: {
//         labels: ['Promoters', 'Passives', 'Detractors'],
//         datasets: [{
//             data: [60, 25, 15],
//             backgroundColor: [
//                 '#4CAF50',
//                 '#FFC107',
//                 '#f44336'
//             ]
//         }]
//     },
//     options: {
//         ...chartOptions,
//         plugins: {
//             ...chartOptions.plugins,
//             title: {
//                 text: 'Net Promoter Score (NPS)'
//             },
//             tooltip: {
//                 callbacks: {
//                     label: function(context) {
//                         const label = context.label || '';
//                         const value = context.parsed;
//                         return `${label}: ${value}%`;
//                     }
//                 }
//             }
//         }
//     }
// });

// Feedback Categories (Pie Chart)
const feedbackCategoriesCtx = document.getElementById('feedbackCategoriesChart').getContext('2d');
new Chart(feedbackCategoriesCtx, {
    type: 'pie',
    data: {
        labels: ['User Interface', 'Features', 'Support', 'Performance', 'Others'],
        datasets: [{
            data: [30, 25, 20, 15, 10],
            backgroundColor: [
                '#4361ee',
                '#ff6b6b',
                '#ffd93d',
                '#6c5ce7',
                '#a8e6cf'
            ]
        }]
    },
    options: {
        ...chartOptions,
        plugins: {
            ...chartOptions.plugins,
            title: {
                text: 'Feedback Categories'
            },
            tooltip: {
                callbacks: {
                    label: function(context) {
                        const label = context.label || '';
                        const value = context.parsed;
                        return `${label}: ${value}%`;
                    }
                }
            }
        }
    }
});

// Sentiment Analysis (Stacked Bar Chart)
const sentimentCtx = document.getElementById('sentimentChart').getContext('2d');
new Chart(sentimentCtx, {
    type: 'bar',
    data: {
        labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
        datasets: [
            {
                label: 'Positive',
                data: [50, 55, 60, 58, 62, 65],
                backgroundColor: '#4CAF50'
            },
            {
                label: 'Neutral',
                data: [20, 18, 22, 25, 20, 18],
                backgroundColor: '#FFC107'
            },
            {
                label: 'Negative',
                data: [10, 12, 8, 7, 5, 5],
                backgroundColor: '#f44336'
            }
        ]
    },
    options: {
        ...chartOptions,
        plugins: {
            ...chartOptions.plugins,
            title: {
                text: 'Sentiment Analysis'
            },
            tooltip: {
                mode: 'index',
                intersect: false
            }
        },
        responsive: true,
        interaction: {
            mode: 'index',
            intersect: false
        },
        scales: {
            y: {
                stacked: true
            },
            x: {
                stacked: true
            }
        }
    }
});

// 2. Demographic and Segmentation Insights

// User Demographics (Pie Chart)
const demographicsCtx = document.getElementById('demographicsChart').getContext('2d');
new Chart(demographicsCtx, {
    type: 'pie',
    data: {
        labels: ['First Year', 'Second Year', 'Third Year', 'Fourth Year', 'Professor'],
        datasets: [{
            data: [25, 30, 20, 15, 10],
            backgroundColor: [
                '#4361ee',
                '#ff6b6b',
                '#ffd93d',
                '#6c5ce7',
                '#a8e6cf'
            ]
        }]
    },
    options: {
        ...chartOptions,
        plugins: {
            ...chartOptions.plugins,
            title: {
                text: 'User Demographics'
            },
            tooltip: {
                callbacks: {
                    label: function(context) {
                        const label = context.label || '';
                        const value = context.parsed;
                        return `${label}: ${value}%`;
                    }
                }
            }
        }
    }
});

// User Activity Segmentation (Horizontal Bar Chart)
const userActivityCtx = document.getElementById('userActivityChart').getContext('2d');
new Chart(userActivityCtx, {
    type: 'bar',
    data: {
        labels: ['Highly Active', 'Moderately Active', 'Inactive'],
        datasets: [{
            label: 'User Count',
            data: [800, 400, 34],
            backgroundColor: [
                '#4CAF50',
                '#FFC107',
                '#f44336'
            ]
        }]
    },
    options: {
        ...chartOptions,
        indexAxis: 'y',
        plugins: {
            ...chartOptions.plugins,
            title: {
                text: 'User Activity Segmentation'
            },
            tooltip: {
                callbacks: {
                    label: function(context) {
                        const label = context.label || '';
                        const value = context.parsed.x;
                        return `${label}: ${value} users`;
                    }
                }
            }
        }
    }
});

// 3. Interactive Features

// Hover effect for feedback table rows
document.querySelectorAll('.feedback-table tbody tr').forEach(row => {
    row.addEventListener('mouseover', () => {
        row.style.backgroundColor = '#f1f1f1';
    });
    row.addEventListener('mouseout', () => {
        row.style.backgroundColor = '';
    });
});

// Optional: Add more interactive features as needed
