// jobmarket.js

// Chart configurations and data
const chartConfig = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
        legend: {
            position: 'bottom',
            labels: {
                padding: 20,
                font: { size: 12 }
            }
        }
    },
    scales: {
        y: {
            beginAtZero: true,
            ticks: { font: { size: 12 } }
        },
        x: {
            ticks: { font: { size: 12 } }
        }
    }
};

// Active Jobs Chart
new Chart(document.getElementById('activeJobsChart'), {
    type: 'line',
    data: {
        labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
        datasets: [{
            label: 'Active Jobs',
            data: [30, 35, 40, 38, 42, 45],
            borderColor: '#FF6B00',
            backgroundColor: 'rgba(255, 107, 0, 0.1)',
            fill: true,
            tension: 0.4
        }]
    },
    options: chartConfig
});

// Pay Rate Chart
new Chart(document.getElementById('payRateChart'), {
    type: 'bar',
    data: {
        labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
        datasets: [{
            label: 'Average Pay Rate',
            data: [7500, 7800, 8000, 8200, 8400, 8500],
            backgroundColor: '#4B0082'
        }]
    },
    options: chartConfig
});

// Success Rate Chart
new Chart(document.getElementById('successRateChart'), {
    type: 'doughnut',
    data: {
        labels: ['Success', 'Other'],
        datasets: [{
            data: [92, 8],
            backgroundColor: ['#4B0082', '#f0f0f0']
        }]
    },
    options: {
        ...chartConfig,
        cutout: '70%'
    }
});

// Categories Chart
new Chart(document.getElementById('categoriesChart'), {
    type: 'pie',
    data: {
        labels: ['Teaching Assistant', 'Research', 'Development', 'Design'],
        datasets: [{
            data: [35, 25, 25, 15],
            backgroundColor: [
                '#FF6B00',
                '#4B0082',
                '#FFA726',
                '#66BB6A'
            ]
        }]
    },
    options: {
        ...chartConfig,
        plugins: {
            legend: {
                position: 'bottom'
            }
        }
    }
});

// Salary Trends Chart
new Chart(document.getElementById('salaryTrendsChart'), {
    type: 'line',
    data: {
        labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
        datasets: [{
            label: 'Average Salary',
            data: [8000, 8200, 8400, 8600, 8800, 9000],
            borderColor: '#FF6B00',
            tension: 0.4
        }]
    },
    options: chartConfig
});

// Seasonal Trends Chart
// new Chart(document.getElementById('seasonalTrendsChart'), {
//     type: 'line',
//     data: {
//         labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
//         datasets: [{
//             label: '2024',
//             data: [30, 35, 45, 50, 40, 35, 30, 35, 40, 55, 60, 45],
//             borderColor: '#FF6B00',
//             tension: 0.4
//         }, {
//             label: '2023',
//             data: [25, 30, 40, 45, 35, 30, 25, 30, 35, 50, 55, 40],
//             borderColor: '#4B0082',
//             tension: 0.4
//         }]
//     },
//     options: {
//         ...chartConfig,
//         plugins: {
//             legend: {
//                 position: 'bottom'
//             }
//         }
//     }
// });

// Add interactivity to elements
document.querySelectorAll('.salary-range').forEach(range => {
    range.addEventListener('mouseover', () => {
        range.style.transform = 'translateX(10px)';
    });
    range.addEventListener('mouseout', () => {
        range.style.transform = 'translateX(0)';
    });
});

// document.querySelectorAll('.category-tag').forEach(tag => {
//     tag.addEventListener('click', () => {
//         // Here you would typically filter the data based on the category
//         console.log('Selected category:', tag.textContent);
//     });
// });

document.querySelectorAll('.stat-card').forEach(card => {
    card.addEventListener('mouseover', () => {
        card.style.transform = 'translateY(-5px)';
    });
    card.addEventListener('mouseout', () => {
        card.style.transform = 'translateY(0)';
    });
});

document.querySelectorAll('.trend-card').forEach(card => {
    card.addEventListener('mouseover', () => {
        card.style.transform = 'translateY(-5px)';
    });
    card.addEventListener('mouseout', () => {
        card.style.transform = 'translateY(0)';
    });
});


