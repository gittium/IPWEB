// profanaly.js

// Chart Configurations
const chartConfig = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
        legend: {
            display: false
        }
    }
};

// Active Professors Chart
new Chart(document.getElementById('activeProfsChart'), {
    type: 'line',
    data: {
        labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
        datasets: [{
            data: [12, 13, 14, 14, 15, 15],
            borderColor: '#FF6B00',
            backgroundColor: 'rgba(255, 107, 0, 0.1)',
            fill: true,
            tension: 0.4
        }]
    },
    options: chartConfig
});

// Job Posts Chart
new Chart(document.getElementById('jobPostsChart'), {
    type: 'bar',
    data: {
        labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
        datasets: [{
            data: [95, 102, 108, 115, 120, 124],
            backgroundColor: '#4B0082'
        }]
    },
    options: chartConfig
});

// Rating Chart
new Chart(document.getElementById('ratingChart'), {
    type: 'doughnut',
    data: {
        labels: ['5★', '4★', '3★', '2★', '1★'],
        datasets: [{
            data: [75, 20, 5, 0, 0],
            backgroundColor: [
                '#4B0082',
                '#FF6B00',
                '#FFA726',
                '#FF7043',
                '#FF5722'
            ]
        }]
    },
    options: {
        ...chartConfig,
        cutout: '70%'
    }
});

// Interactive Features
document.querySelectorAll('.interactive-card').forEach(card => {
    card.addEventListener('mouseover', () => {
        card.style.transform = 'translateY(-5px)';
    });
    card.addEventListener('mouseout', () => {
        card.style.transform = 'translateY(0)';
    });
});

// document.querySelectorAll('.tab').forEach(tab => {
//     tab.addEventListener('click', () => {
//         // Remove active class from all tabs
//         document.querySelectorAll('.tab').forEach(t => {
//             t.classList.remove('active');
//         });
//         // Add active class to clicked tab
//         tab.classList.add('active');
//     });
// });

// Animated Rating Bars
document.querySelectorAll('.rating-bar').forEach(bar => {
    const fill = bar.querySelector('.rating-fill');
    const targetWidth = fill.style.width;
    fill.style.width = '0';
    setTimeout(() => {
        fill.style.width = targetWidth;
    }, 100);
});
