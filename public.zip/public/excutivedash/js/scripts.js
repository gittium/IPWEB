// scripts.js

/**
 * Loads external HTML components into placeholders.
 * Currently handles loading the sidebar.
 */
async function loadSidebar() {
    try {
        const response = await fetch('sidebar.html');
        if (!response.ok) throw new Error('Network response was not ok');
        const sidebarHTML = await response.text();
        document.getElementById('sidebar-placeholder').innerHTML = sidebarHTML;
        
        // Set the active nav-item based on current URL
        const currentPage = window.location.pathname.split('/').pop();
        const navItems = document.querySelectorAll('.nav-item');
        navItems.forEach(item => {
            if (item.getAttribute('href') === currentPage) {
                item.classList.add('active');
            } else {
                item.classList.remove('active');
            }
        });
    } catch (error) {
        console.error('Failed to load sidebar:', error);
    }
}

/**
 * Initializes shared interactive features across all pages.
 */
// function initializeSharedInteractivity() {
    // Example: Global button animations or interactions can be added here
    // Currently, no additional shared interactivity is defined
    // Placeholder for future enhancements
// }

// Load the sidebar and initialize shared interactivity when the DOM is fully loaded
document.addEventListener('DOMContentLoaded', () => {
    loadSidebar();
    initializeSharedInteractivity();
});
