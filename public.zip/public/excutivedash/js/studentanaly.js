// studentanaly.js

// Chart Configurations
const chartConfig = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
        legend: {
            position: 'bottom',
            labels: {
                padding: 20,
                font: { size: 12 }
            }
        },
        title: {
            display: false,
            text: ''
        }
    },
    scales: {
        y: {
            beginAtZero: true,
            ticks: {
                font: { size: 12 }
            },
            grid: {
                color: 'rgba(0, 0, 0, 0.1)'
            }
        },
        x: {
            ticks: {
                font: { size: 12 }
            },
            grid: {
                display: false
            }
        }
    }
};

// Completion Rate Chart
new Chart(document.getElementById('completionChart'), {
    type: 'line',
    data: {
        labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
        datasets: [{
            label: 'Completion Rate',
            data: [90, 91, 92, 93, 93, 94],
            borderColor: '#FF6B00',
            backgroundColor: 'rgba(255, 107, 0, 0.1)',
            fill: true,
            tension: 0.4
        }]
    },
    options: chartConfig
});

// Active Students Chart
new Chart(document.getElementById('activeStudentsChart'), {
    type: 'bar',
    data: {
        labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
        datasets: [{
            label: 'Active Students',
            data: [100, 110, 115, 120, 125, 127],
            backgroundColor: '#4B0082',
            borderRadius: 6
        }]
    },
    options: chartConfig
});

// Ratings Distribution Chart
new Chart(document.getElementById('ratingsChart'), {
    type: 'doughnut',
    data: {
        labels: ['5★', '4★', '3★', '2★', '1★'],
        datasets: [{
            data: [45, 30, 15, 7, 3],
            backgroundColor: [
                '#4B0082',
                '#FF6B00',
                '#FFA726',
                '#FF7043',
                '#FF5722'
            ]
        }]
    },
    options: {
        ...chartConfig,
        cutout: '70%',
        plugins: {
            ...chartConfig.plugins,
            title: {
                display: true,
                text: 'Ratings Distribution',
                font: {
                    size: 14,
                    weight: 'bold'
                }
            }
        }
    }
});

// Skills Progress Chart
new Chart(document.getElementById('skillsProgressChart'), {
    type: 'radar',
    data: {
        labels: [
            'Technical Skills',
            'Communication',
            'Problem Solving',
            'Teamwork',
            'Time Management',
            'Leadership'
        ],
        datasets: [{
            label: 'Current Level',
            data: [85, 75, 82, 80, 77, 70],
            borderColor: '#FF6B00',
            backgroundColor: 'rgba(255, 107, 0, 0.2)'
        }, {
            label: 'Previous Month',
            data: [75, 70, 75, 75, 70, 65],
            borderColor: '#4B0082',
            backgroundColor: 'rgba(75, 0, 130, 0.2)'
        }]
    },
    options: {
        ...chartConfig,
        scales: {
            r: {
                angleLines: {
                    color: 'rgba(0, 0, 0, 0.1)'
                },
                grid: {
                    color: 'rgba(0, 0, 0, 0.1)'
                },
                pointLabels: {
                    font: {
                        size: 12
                    }
                },
                suggestedMin: 0,
                suggestedMax: 100
            }
        },
        plugins: {
            ...chartConfig.plugins,
            title: {
                display: true,
                text: 'Skills Development Progress',
                font: {
                    size: 14,
                    weight: 'bold'
                }
            }
        }
    }
});

// Add interactivity to elements

// Hover effect for performance cards
document.querySelectorAll('.performance-card').forEach(card => {
    card.addEventListener('mouseover', () => {
        card.style.transform = 'translateY(-5px)';
    });
    card.addEventListener('mouseout', () => {
        card.style.transform = 'translateY(0)';
    });
});

// Click animation for achievement badges
// document.querySelectorAll('.achievement-badge').forEach(badge => {
//     badge.addEventListener('click', () => {
//         badge.style.transform = 'scale(1.1)';
//         setTimeout(() => {
//             badge.style.transform = 'scale(1)';
//         }, 200);
//     });
// });

// Hover effect for rankings table rows
document.querySelectorAll('.rankings-table tbody tr').forEach(row => {
    row.addEventListener('mouseover', () => {
        row.style.backgroundColor = '#f8f9fa';
    });
    row.addEventListener('mouseout', () => {
        row.style.backgroundColor = '';
    });
});

// Progress bar animation
document.querySelectorAll('.progress-bar').forEach(bar => {
    const fill = bar.querySelector('.progress-fill');
    const targetWidth = fill.style.width;
    fill.style.width = '0';
    setTimeout(() => {
        fill.style.width = targetWidth;
    }, 100);
});
