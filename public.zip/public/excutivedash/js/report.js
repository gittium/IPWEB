// report.js

// Chart Configurations
const chartConfig = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
        legend: {
            position: 'bottom',
            labels: {
                padding: 20,
                font: { size: 12 }
            }
        }
    },
    scales: {
        y: {
            beginAtZero: true,
            grid: {
                color: 'rgba(0, 0, 0, 0.1)'
            }
        },
        x: {
            grid: {
                display: false
            }
        }
    }
};

// System Performance Chart
new Chart(document.getElementById('performanceChart'), {
    type: 'line',
    data: {
        labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
        datasets: [{
            label: 'System Performance',
            data: [95, 96, 97, 96.5, 97.5, 98.5],
            borderColor: '#FF6B00',
            backgroundColor: 'rgba(255, 107, 0, 0.1)',
            fill: true,
            tension: 0.4
        }]
    },
    options: chartConfig
});

// Job Completion Chart
new Chart(document.getElementById('completionChart'), {
    type: 'bar',
    data: {
        labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
        datasets: [{
            label: 'Completion Rate',
            data: [85, 87, 88, 90, 91, 92],
            backgroundColor: '#4B0082',
            borderRadius: 6
        }]
    },
    options: chartConfig
});

// Student Engagement Chart
new Chart(document.getElementById('engagementChart'), {
    type: 'line',
    data: {
        labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
        datasets: [{
            label: 'Engagement Rate',
            data: [80, 85, 88, 90, 88, 85],
            borderColor: '#FFC107',
            backgroundColor: 'rgba(255, 193, 7, 0.1)',
            fill: true,
            tension: 0.4
        }]
    },
    options: chartConfig
});

// Interactive Features

// Report Buttons Click Event
document.querySelectorAll('.report-button').forEach(button => {
    button.addEventListener('click', () => {
        // Remove active class from all buttons in the same group
        button.parentElement.querySelectorAll('.report-button').forEach(btn => {
            btn.classList.remove('active');
        });
        // Add active class to clicked button
        button.classList.add('active');
        
        // Add click animation
        button.style.transform = 'scale(0.95)';
        setTimeout(() => {
            button.style.transform = 'scale(1)';
        }, 100);
        
        // TODO: Implement report filtering based on selected controls
    });
});

// Report Cards Hover Effect
document.querySelectorAll('.report-card').forEach(card => {
    card.addEventListener('mouseover', () => {
        card.style.transform = 'translateY(-5px)';
    });
    card.addEventListener('mouseout', () => {
        card.style.transform = 'translateY(0)';
    });
});

// Table Row Hover Effect
// document.querySelectorAll('.report-table tbody tr').forEach(row => {
//     row.addEventListener('mouseover', () => {
//         row.style.backgroundColor = 'var(--light-bg)';
//     });
//     row.addEventListener('mouseout', () => {
//         row.style.backgroundColor = '';
//     });
// });
