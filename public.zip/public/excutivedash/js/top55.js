// top55.js

// Chart Configurations
const chartConfig = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
        legend: {
            position: 'bottom',
            labels: {
                padding: 20,
                font: { size: 12 }
            }
        }
    },
    scales: {
        y: {
            beginAtZero: true,
            grid: {
                color: 'rgba(0, 0, 0, 0.1)'
            }
        },
        x: {
            grid: {
                display: false
            }
        }
    }
};

// Students Performance Chart
new Chart(document.getElementById('studentsChart'), {
    type: 'bar',
    data: {
        labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
        datasets: [{
            label: 'Job Completed',
            data: [12, 15, 18, 20, 22, 25],
            backgroundColor: '#FF6B00',
            borderRadius: 6
        }]
    },
    options: chartConfig
});

// Professors Activity Chart
new Chart(document.getElementById('professorsChart'), {
    type: 'bar',
    data: {
        labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
        datasets: [{
            label: 'Posted Jobs',
            data: [12, 15, 18, 20, 22, 25],
            backgroundColor: '#4B0082',
            borderRadius: 6
        }]
    },
    options: chartConfig
});


// Popular Jobs Chart
new Chart(document.getElementById('jobsChart'), {
    type: 'doughnut',
    data: {
        labels: ['Web Dev', 'Teaching', 'Research', 'Design', 'Other'],
        datasets: [{
            data: [30, 25, 20, 15, 10],
            backgroundColor: [
                '#FF6B00',
                '#4B0082',
                '#FFD700',
                '#C0C0C0',
                '#CD7F32'
            ]
        }]
    },
    options: {
        ...chartConfig,
        cutout: '70%',
        plugins: {
            ...chartConfig.plugins,
            title: {
                display: true,
                text: 'Popular Jobs Distribution',
                font: {
                    size: 2,
                    weight: 'bold'
                }
            }
        }
    }
});

// Interactive Features

// Hover effect for ranking items
document.querySelectorAll('.ranking-item').forEach(item => {
    item.addEventListener('mouseover', () => {
        item.style.transform = 'translateX(10px)';
    });
    item.addEventListener('mouseout', () => {
        item.style.transform = 'translateX(0)';
    });
});

// Hover effect for ranking cards
document.querySelectorAll('.ranking-card').forEach(card => {
    card.addEventListener('mouseover', () => {
        card.style.transform = 'translateY(-5px)';
    });
    card.addEventListener('mouseout', () => {
        card.style.transform = 'translateY(0)';
    });
});
