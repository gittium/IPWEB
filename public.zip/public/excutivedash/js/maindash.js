// maindash.js

// Chart Configurations
const chartConfig = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
        legend: {
            position: 'bottom',
            labels: {
                padding: 20,
                font: { size: 12 }
            }
        }
    },
    scales: {
        y: {
            beginAtZero: true,
            grid: {
                color: 'rgba(0, 0, 0, 0.1)'
            }
        },
        x: {
            grid: {
                display: false
            }
        }
    }
};

// Job Trends Chart
new Chart(document.getElementById('jobTrendsChart'), {
    type: 'line',
    data: {
        labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
        datasets: [{
            label: 'Active Jobs',
            data: [30, 35, 40, 38, 42, 45],
            borderColor: '#FF6B00',
            backgroundColor: 'rgba(255, 107, 0, 0.1)',
            tension: 0.4,
            fill: true
        }]
    },
    options: chartConfig
});

// Job Distribution Chart
new Chart(document.getElementById('jobDistributionChart'), {
    type: 'doughnut',
    data: {
        labels: ['Teaching', 'Research', 'Development', 'Design', 'Other'],
        datasets: [{
            data: [35, 25, 20, 15, 5],
            backgroundColor: [
                '#FF6B00',
                '#4B0082',
                '#4CAF50',
                '#FFC107',
                '#9C27B0'
            ]
        }]
    },
    options: {
        ...chartConfig,
        cutout: '65%'
    }
});

// Budget Chart
new Chart(document.getElementById('budgetChart'), {
    type: 'bar',
    data: {
        labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
        datasets: [{
            label: 'Budget Utilization',
            data: [85000, 92000, 98000, 105000, 115000, 125000],
            backgroundColor: '#4B0082'
        }]
    },
    options: chartConfig
});

// Department Performance Chart
new Chart(document.getElementById('departmentChart'), {
    type: 'radar',
    data: {
        labels: [
            'Job Completion',
            'Student Engagement',
            //'Budget Efficiency',
             'Feedback Score'
            // 'Skills Development'
        ],
        datasets: [{
            label: 'Current Period',
            data: [90, 85, 88, 92, 86],
            borderColor: '#FF6B00',
            backgroundColor: 'rgba(255, 107, 0, 0.2)'
        }, {
            label: 'Previous Period',
            data: [85, 80, 82, 87, 80],
            borderColor: '#4B0082',
            backgroundColor: 'rgba(75, 0, 130, 0.2)'
        }]
    },
    options: {
        ...chartConfig,
        scales: {
            r: {
                angleLines: {
                    color: 'rgba(0, 0, 0, 0.1)'
                },
                suggestedMin: 0,
                suggestedMax: 100
            }
        }
    }
});

// Interactive Features
document.querySelectorAll('.stat-card, .chart-card, .activity-feed, .alerts-section, .metric-card').forEach(card => {
    card.addEventListener('mouseover', () => {
        card.style.transform = 'translateY(-5px)';
    });
    card.addEventListener('mouseout', () => {
        card.style.transform = 'translateY(0)';
    });
});

// document.querySelectorAll('.action-button').forEach(button => {
//     button.addEventListener('click', () => {
//         button.style.transform = 'scale(0.95)';
//         setTimeout(() => {
//             button.style.transform = 'scale(1)';
//         }, 100);
//     });
// });

document.querySelectorAll('.alert-item').forEach(alert => {
    alert.addEventListener('click', () => {
        alert.style.transform = 'translateX(10px)';
        setTimeout(() => {
            alert.style.transform = 'translateX(0)';
        }, 100);
    });
});
