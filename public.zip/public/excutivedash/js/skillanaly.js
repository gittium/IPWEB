// skillanaly.js

// Chart configuration with consistent styling
const chartConfig = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
        legend: {
            position: 'bottom',
            labels: {
                padding: 20,
                font: {
                    size: 12
                }
            }
        },
        title: {
            display: false,
            text: ''
        }
    },
    scales: {
        y: {
            beginAtZero: true,
            ticks: {
                font: {
                    size: 12
                }
            },
            grid: {
                color: 'rgba(0, 0, 0, 0.1)'
            }
        },
        x: {
            ticks: {
                font: {
                    size: 12
                }
            },
            grid: {
                display: false
            }
        }
    }
};

// Most Demanded Skills Chart
new Chart(document.getElementById('demandedSkillsChart'), {
    type: 'bar',
    data: {
        labels: ['React', 'Python', 'Node.js', 'UI/UX', 'Java', 'Flutter'],
        datasets: [{
            label: 'Demand Score',
            data: [85, 80, 75, 70, 65, 60],
            backgroundColor: '#FF6B00',
            borderRadius: 6
        }]
    },
    options: {
        ...chartConfig,
        plugins: {
            ...chartConfig.plugins,
            title: {
                display: true,
                text: 'Skill Demand Distribution',
                font: {
                    size: 14,
                    weight: 'bold'
                }
            }
        }
    }
});

// Skills Gap Chart
new Chart(document.getElementById('skillsGapChart'), {
    type: 'bar',
    data: {
        labels: ['React', 'Python', 'Node.js', 'UI/UX', 'Java', 'Flutter'],
        datasets: [{
            label: 'Required Skills',
            data: [90, 85, 80, 75, 70, 65],
            backgroundColor: '#4B0082',
            borderRadius: 6
        }, {
            label: 'Current Student Skills',
            data: [70, 65, 60, 55, 50, 45],
            backgroundColor: '#FF6B00',
            borderRadius: 6
        }]
    },
    options: {
        ...chartConfig,
        plugins: {
            ...chartConfig.plugins,
            title: {
                display: true,
                text: 'Skills Gap Analysis',
                font: {
                    size: 14,
                    weight: 'bold'
                }
            }
        }
    }
});

// Skills Development Timeline Chart
new Chart(document.getElementById('developmentTimeline'), {
    type: 'line',
    data: {
        labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
        datasets: [{
            label: 'Web Development',
            data: [65, 70, 75, 80, 85, 90],
            borderColor: '#4B0082',
            backgroundColor: 'rgba(75, 0, 130, 0.1)',
            fill: true,
            tension: 0.4
        }, {
            label: 'Mobile Development',
            data: [55, 60, 65, 70, 75, 80],
            borderColor: '#FF6B00',
            backgroundColor: 'rgba(255, 107, 0, 0.1)',
            fill: true,
            tension: 0.4
        }]
    },
    options: {
        ...chartConfig,
        plugins: {
            ...chartConfig.plugins,
            title: {
                display: true,
                text: 'Skills Development Progress',
                font: {
                    size: 14,
                    weight: 'bold'
                }
            }
        }
    }
});

// Add interactivity to table rows
document.querySelectorAll('.skills-table tbody tr').forEach(row => {
    row.addEventListener('mouseover', () => {
        row.style.backgroundColor = '#f8f9fa';
    });
    row.addEventListener('mouseout', () => {
        row.style.backgroundColor = '';
    });
});

// Add interactivity to filters
// document.querySelectorAll('.filter-select').forEach(select => {
//     select.addEventListener('change', () => {
//         // Here you would typically update the charts and table based on selection
//         console.log('Filter changed:', select.value);
//         // TODO: Implement dynamic data filtering based on selected filters
//     });
// });
