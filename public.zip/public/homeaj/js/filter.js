// components/filter.js

// Ensure the namespace exists
var CSITJobBoard = CSITJobBoard || {};

// Filter Module
CSITJobBoard.Filter = (function() {
    // Private functions

    function toggleFilter() {
        var sidebar = document.getElementById('filterSidebar');
        var filterButton = document.getElementById('filterButton');
        var contentWrapper = document.getElementById('contentWrapper');

        if (sidebar && filterButton && contentWrapper) {
            sidebar.classList.toggle('show');
            filterButton.classList.toggle('active');
            contentWrapper.classList.toggle('shifted');
        }
    }

    function closeFilterOnClickOutside(event) {
        var sidebar = document.getElementById('filterSidebar');
        var filterButton = document.getElementById('filterButton');

        if (sidebar && filterButton) {
            if (!sidebar.contains(event.target) && 
                !filterButton.contains(event.target) && 
                sidebar.classList.contains('show')) {
                toggleFilter();
            }
        }
    }

    function handleFilterChips() {
        var filterChips = document.querySelectorAll('.filter-chip');
        filterChips.forEach(function(chip) {
            chip.addEventListener('click', function() {
                chip.classList.toggle('selected');
                // Implement filter functionality here
            });
        });
    }

    function handleResetButton() {
        var resetButton = document.querySelector('.reset-button');
        if (resetButton) {
            resetButton.addEventListener('click', function() {
                var selectedChips = document.querySelectorAll('.filter-chip.selected');
                selectedChips.forEach(function(chip) {
                    chip.classList.remove('selected');
                });
                // Implement additional reset functionality here
            });
        }
    }

    function handleApplyButton() {
        var applyButton = document.querySelector('.apply-button');
        if (applyButton) {
            applyButton.addEventListener('click', function() {
                // Implement apply filter functionality here
                toggleFilter(); // Close the filter sidebar after applying
            });
        }
    }

    // Public API
    return {
        init: function() {
            var filterButton = document.getElementById('filterButton');
            var closeButton = document.querySelector('.close-button');

            if (filterButton) {
                filterButton.addEventListener('click', toggleFilter);
            }

            if (closeButton) {
                closeButton.addEventListener('click', toggleFilter);
            }

            handleFilterChips();
            handleResetButton();
            handleApplyButton();

            // Close filter when clicking outside
            document.addEventListener('click', closeFilterOnClickOutside);
        }
    };
})();
