<?php
include 'database.php';

// ตรวจสอบว่ามี student_id หรือไม่
$student_id = isset($_GET['student_id']) ? intval($_GET['student_id']) : 0;

// ตัวกรองสาขาและชั้นปี
$filter_major = isset($_GET['major']) ? $_GET['major'] : '';
$filter_year = isset($_GET['year']) ? $_GET['year'] : '';

// ดึงข้อมูลนักศึกษา
$sql = "SELECT DISTINCT ja.id, ja.post_jobs_id, s.id, s.name, s.year, m.mojor_name 
        FROM job_applications ja 
        JOIN students s ON ja.student_id = s.id
        JOIN mojor m ON s.major_id = m.id
        WHERE 1";

$params = [];
$types = "";

// เพิ่มเงื่อนไขตัวกรอง
if ($student_id > 0) {
    $sql .= " AND s.id = ?";
    $params[] = $student_id;
    $types .= "i";
}
if (!empty($filter_major)) {
    $sql .= " AND m.mojor_name = ?";
    $params[] = $filter_major;
    $types .= "s";
}
if (!empty($filter_year)) {
    $sql .= " AND s.year = ?";
    $params[] = $filter_year;
    $types .= "s";
}



// เตรียมและ execute SQL
$stmt = $conn->prepare($sql);
if ($types) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$result = $stmt->get_result();

// ปิดการเชื่อมต่อ
$stmt->close();
$conn->close();

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Teaching Assistant View Applications Page">
    <title>Teaching Assistant Applications</title>
    <!-- Google Fonts -->
    <link
        href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&family=Montserrat:wght@600&display=swap"
        rel="stylesheet">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <link rel="stylesheet" href="viewapply.css">
    <link rel="stylesheet" href="header-footerstyle.css">

</head>

<body>
    <!-- Header -->
    <header class="headerTop">
        <div class="headerTopImg">
            <img src="logo.png" alt="Naresuan University Logo">
            <a href="#">Naresuan University</a>
        </div>
        <nav class="header-nav">
            <a href="#">About Us</a>
            <a href="#">News</a>
            <a href="#">Logout</a>
        </nav>
    </header>

    <!-- ปุ่ม back -->
    <div>
        <a href="" class="back-arrow"></a>
    </div>

    <!-- Main Content -->
    <div class="container">
        <div class="title-container">
            <a href="#">View Applications</a> <!-- เพิ่ม href ที่นี่ -->
            <a href="#">Manage Job</a> <!-- เพิ่ม href ที่นี่ -->
        </div>
        <br>
        <div>
            <h1>Teaching Assistant</h1>
        </div>
        <br>
        <div class="bar">
            <a href="viewapply1.php" class="<?= empty($_GET['major']) ? 'active' : '' ?>">ทั้งหมด</a>
            <a href="viewapply1.php?major=Computer Science" class="<?= isset($_GET['major']) && $_GET['major'] == 'Computer Science' ? 'active' : '' ?>">วิทยาการคอมพิวเตอร์</a>
            <a href="viewapply1.php?major=Information Technology" class="<?= isset($_GET['major']) && $_GET['major'] == 'Information Technology' ? 'active' : '' ?>">เทคโนโลยีสารสนเทศ</a>
            <i class="bi bi-filter ms-auto" id="filter-btn" style="cursor: pointer;"></i>
        </div>

        <!-- ฟิลเตอร์ -->
        <div id="hidden-message" class="message-box">สาขา<br>
                <button class="selected branch-btn" data-major="Computer Science">วิทยาการคอมพิวเตอร์</button>
                <button class="selected branch-btn" data-major="Information Technology">เทคโนโลยีสารสนเทศ</button>
    
                <br><br>
                <p>ชั้นปี</p>
                <button class="selected year-btn" data-year="1">ปี 1</button>
                <button class="selected year-btn" data-year="2">ปี 2</button>
                <button class="selected year-btn" data-year="3">ปี 3</button>
                <button class="selected year-btn" data-year="4">ปี 4</button>
    
                <br><br>
                <button class="selected" id="clear-btn">ล้าง</button>
                <button class="selected" id="apply-btn">ตกลง</button>
            </div>
        </div>

        <div class="application-list">
            <!-- รายการใบสมัคร -->
            <?php if ($result && $result->num_rows > 0): ?>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <div class="application-card">
                        
                        <div class="profile-img"></div>
                        <div class="details">
                            <div class="name"><?= htmlspecialchars($row['name']) ?></div>
                            <div class="department">สาขา <?= htmlspecialchars($row['mojor_name']) ?></div>
                            <div class="year">ปี <?= htmlspecialchars($row['year']) ?></div>
                        </div>
                        <a href="viewapply2.php?student_id=<?= htmlspecialchars($row['id']) ?>" class="chevron-link">
                            <i class="bi bi-chevron-right"></i>
                        </a> 
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <p>ไม่พบข้อมูลการสมัคร</p>
            <?php endif; ?>
        </div>
    
    </div> 

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-..." crossorigin="anonymous"></script>
       
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-..." crossorigin="anonymous"></script>

    <script src="viewapply.js"></script>

    <!-- Footer -->
    <footer class="footer">
        <p>© CSIT - Computer Science and Information Technology</p>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>

</script>
</body>
</html>
