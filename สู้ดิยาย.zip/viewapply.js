document.addEventListener("DOMContentLoaded", function() {
    const branchButtons = document.querySelectorAll(".branch-btn");
    const yearButtons = document.querySelectorAll(".year-btn");
    const applyBtn = document.getElementById("apply-btn");
    const clearBtn = document.getElementById("clear-btn");

    let selectedFilters = {
        major: new URLSearchParams(window.location.search).get('major') || null,
        year: new URLSearchParams(window.location.search).get('year') || null
    };

    // ไฮไลท์ปุ่มที่ถูกเลือกเมื่อโหลดหน้าใหม่
    branchButtons.forEach(button => {
        let value = button.getAttribute("data-major");
        if (selectedFilters.major === value) {
            button.classList.add("active");
        }

        button.addEventListener("click", function() {
            if (selectedFilters.major === value) {
                selectedFilters.major = null;
                this.classList.remove("active");
            } else {
                selectedFilters.major = value;
                branchButtons.forEach(btn => btn.classList.remove("active"));
                this.classList.add("active");
            }
        });
    });

    yearButtons.forEach(button => {
        let value = button.getAttribute("data-year");
        if (selectedFilters.year === value) {
            button.classList.add("active");
        }

        button.addEventListener("click", function() {
            if (selectedFilters.year === value) {
                selectedFilters.year = null;
                this.classList.remove("active");
            } else {
                selectedFilters.year = value;
                yearButtons.forEach(btn => btn.classList.remove("active"));
                this.classList.add("active");
            }
        });
    });

    // เมื่อกด "ตกลง" ให้โหลดข้อมูลใหม่โดยใช้ฟิลเตอร์ (ไม่มีแจ้งเตือน)
    applyBtn.addEventListener("click", function() {
        let params = new URLSearchParams();
        if (selectedFilters.major) {
            params.append("major", selectedFilters.major);
        }
        if (selectedFilters.year) {
            params.append("year", selectedFilters.year);
        }

        // โหลดหน้าใหม่ตามค่าที่เลือก
        window.location.href = params.toString() ? "viewapply1.php?" + params.toString() : "viewapply1.php";
    });

    // ปุ่มล้างค่าฟิลเตอร์
    clearBtn.addEventListener("click", function() {
        window.location.href = "viewapply1.php"; // รีเซ็ตหน้า
    });
});
