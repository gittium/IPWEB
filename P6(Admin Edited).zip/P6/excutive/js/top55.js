// top55.js

// We'll store references to each chart in a dictionary:
const chartInstances = {};

// ======= 1) Load Filter Options on DOMContentLoaded
document.addEventListener("DOMContentLoaded", function () {
  Promise.all([
    loadCategoryOptions(),
    loadStatusOptions(),
    loadRewardOptions(),
    loadTeacherOptions(),
    loadSkillOptions()
  ]).then(() => {
    // Now that we've loaded all filter options, we can do the main logic
    loadTopRankings();
  }).catch(err => {
    console.error("Error loading filter options:", err);
    // even if they fail, still attempt to load main logic
    loadTopRankings();
  });
});

// ======= 2) Loading Filter Options (category, status, reward, teacher)
function loadCategoryOptions() {
  return fetch("api/api.php?endpoint=categories-list")
    .then(res => res.json())
    .then(data => {
      const categorySelect = document.getElementById("category");
      categorySelect.innerHTML = '<option value="">All</option>';
      data.forEach(item => {
        const opt = document.createElement("option");
        opt.value = item.job_categories_id;
        opt.textContent = item.categories_name;
        categorySelect.appendChild(opt);
      });
    });
}

function loadStatusOptions() {
  return fetch("api/api.php?endpoint=status-list")
    .then(res => res.json())
    .then(data => {
      const statusSelect = document.getElementById("status");
      statusSelect.innerHTML = '<option value="">All</option>';
      data.forEach(item => {
        const opt = document.createElement("option");
        opt.value = item.job_status_id;
        opt.textContent = item.job_status_name;
        statusSelect.appendChild(opt);
      });
    });
}

function loadRewardOptions() {
  return fetch("api/api.php?endpoint=reward-list")
    .then(res => res.json())
    .then(data => {
      const rewardSelect = document.getElementById("reward");
      rewardSelect.innerHTML = '<option value="">All</option>';
      data.forEach(item => {
        const opt = document.createElement("option");
        opt.value = item.reward_type_id;
        opt.textContent = item.reward_name;
        rewardSelect.appendChild(opt);
      });
    });
}

function loadTeacherOptions() {
  return fetch("api/api.php?endpoint=teacher-list")
    .then(res => res.json())
    .then(data => {
      const teacherSelect = document.getElementById("teacher");
      teacherSelect.innerHTML = '<option value="">All</option>';
      data.forEach(item => {
        const opt = document.createElement("option");
        opt.value = item.teachers_id;
        opt.textContent = item.name;
        teacherSelect.appendChild(opt);
      });
    });
}

function loadSkillOptions() {
    return fetch("api/api.php?endpoint=skills-list")
      .then(res => res.json())
      .then(data => {
        const skillSelect = document.getElementById("skillFilter");
        skillSelect.innerHTML = '<option value="">All</option>';
        data.forEach(item => {
          const opt = document.createElement("option");
          opt.value = item.skills_id;
          opt.textContent = item.skills_name;
          skillSelect.appendChild(opt);
        });
      });
  }

// ======= 3) When user clicks "Apply" button
function applyFilters() {
  loadTopRankings();
}

// ======= 4) Load the top rankings and charts
function loadTopRankings() {
  const { start, end, category, status, reward, teacher, skill } = getFilterValues();

  // (A) Top Students: rating or accept
  const sortBy = document.getElementById("studentSort")?.value || "rating";
  let paramsStudents = buildParams("top5-students", start, end, category, status, reward, teacher , skill);
  paramsStudents.set("sort", sortBy);

  fetch("api/api.php?" + paramsStudents.toString())
    .then(res => res.json())
    .then(data => {
      const top5 = data.slice(0, 5);
      const labels = top5.map(d => d.name);
      let values, chartLabel;
      if (sortBy === "accept") {
        values = top5.map(d => Number(d.accept_count) || 0);
        chartLabel = "Accepted Jobs";
      } else {
        values = top5.map(d => Number(d.avg_rating) || 0);
        chartLabel = "Avg Rating";
      }
      renderBarChart("studentsChart", labels, values, chartLabel, "#FF6B00");
    })
    .catch(err => console.error("Error fetching top5-students:", err));

  // (B) Top Professors
  let paramsProf = buildParams("top-professors", start, end, category, status, reward, teacher , skill);
  fetch("api/api.php?" + paramsProf.toString())
    .then(res => res.json())
    .then(data => {
      const labels = data.map(d => d.name);
      const values = data.map(d => Number(d.job_count));
      renderBarChart("professorsChart", labels, values, "Posted Jobs", "#4B0082");
    })
    .catch(err => console.error("Error fetching top-professors:", err));

  // (C) Top Jobs
  let paramsJobs = buildParams("top-jobs", start, end, category, status, reward, teacher , skill);
  fetch("api/api.php?" + paramsJobs.toString())
    .then(res => res.json())
    .then(data => {
      const labels = data.map(d => d.title);
      const values = data.map(d => Number(d.total_applications));
      renderPieChart("jobsChart", labels, values, ["#FFD700","#C0C0C0","#CD7F32","#FF6B00","#4B0082"]);
    })
    .catch(err => console.error("Error fetching top-jobs:", err));

  // (D) Supply vs Demand (Skills)
  let paramsSupply = buildParams("supply-demand-skills", start, end, category, status, reward, teacher , skill);
  // NEW: Add skill filter if selected
//   const skillFilter = document.getElementById("skillFilter")?.value || "";
//   if (skillFilter) {
//     paramsSupply.set("skill", skillFilter);
//   }
  fetch("api/api.php?" + paramsSupply.toString())
    .then(res => res.json())
    .then(data => {
      // Filter out skills where both supply and demand are 0.
      const filtered = data.filter(d => Number(d.supply) > 0 || Number(d.demand) > 0);
      const labels = filtered.map(d => d.skills_name);
      const supplyValues = filtered.map(d => Number(d.supply));
      const demandValues = filtered.map(d => Number(d.demand));
      renderGroupedBarChart("supplyDemandChart", labels, supplyValues, demandValues, "Supply", "Demand");
    })
    .catch(err => console.error("Error fetching supply-demand-skills:", err));
}

// ======= Helper Functions =======
function getFilterValues() {
  return {
    start: document.getElementById('startDate')?.value || '',
    end: document.getElementById('endDate')?.value || '',
    category: document.getElementById('category')?.value || '',
    status: document.getElementById('status')?.value || '',
    reward: document.getElementById('reward')?.value || '',
    teacher: document.getElementById('teacher')?.value || '',
    skill: document.getElementById('skillFilter')?.value || ''
  };
}

function buildParams(endpoint, start, end, category, status, reward, teacher , skill) {
  const p = new URLSearchParams({ endpoint });
  if (start) p.set('start', start);
  if (end) p.set('end', end);
  if (category) p.set('category', category);
  if (status) p.set('status', status);
  if (reward) p.set('reward', reward);
  if (teacher) p.set('teacher', teacher);
  if (skill) p.set('skill', skill);
  return p;
}

// ======= Chart Renderers =======
function renderBarChart(canvasId, labels, values, labelText, bgColor) {
  if (chartInstances[canvasId]) {
    chartInstances[canvasId].destroy();
  }
  chartInstances[canvasId] = new Chart(document.getElementById(canvasId), {
    type: 'bar',
    data: {
      labels,
      datasets: [{
        label: labelText,
        data: values,
        backgroundColor: bgColor
      }]
    },
    options: { responsive: true, maintainAspectRatio: false }
  });
}

function renderPieChart(canvasId, labels, values, colorsArray, chartTitle = "") {
  // Calculate total sum of values
  const total = values.reduce((acc, cur) => acc + Number(cur), 0);

  if (chartInstances[canvasId]) {
      chartInstances[canvasId].destroy();
  }

  // Set a threshold: show data labels if there are 8 or fewer slices
  const showDataLabels = labels.length <= 8;

  chartInstances[canvasId] = new Chart(document.getElementById(canvasId), {
      type: "pie",
      data: {
          labels,
          datasets: [{
              data: values,
              backgroundColor: colorsArray
          }]
      },
      options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
              title: {
                  display: chartTitle !== "",
                  text: chartTitle,
                  font: { size: 16 }
              },
              datalabels: {
                  display: showDataLabels,  // conditionally display labels
                  formatter: function(value, context) {
                      let label = context.chart.data.labels[context.dataIndex] || "";
                      // Optionally, break the label into multiple lines if it's long:
                      if (label.length > 15) {
                          label = label.match(/.{1,15}/g).join("\n");
                      }
                      const total = context.chart.data.datasets[0].data.reduce((acc, cur) => acc + Number(cur), 0);
                      const percent = ((value / total) * 100).toFixed(1) + '%';
                      return label + "\n" + percent;
                  },
                  color: '#fff',
                  font: { weight: 'bold', size: 8 },
                  padding: 6,
                  clip: true
              },
              tooltip: {
                  enabled: true
              }
          }
      },
      plugins: [ChartDataLabels]
  });
}



// New: Render a grouped bar chart for Supply vs Demand skills
function renderGroupedBarChart(canvasId, labels, supplyValues, demandValues, supplyLabel, demandLabel) {
    if (chartInstances[canvasId]) {
      chartInstances[canvasId].destroy();
    }
    chartInstances[canvasId] = new Chart(document.getElementById(canvasId), {
      type: 'bar',
      data: {
        labels,
        datasets: [
          {
            label: supplyLabel,
            data: supplyValues,
            backgroundColor: '#66BB6A'
          },
          {
            label: demandLabel,
            data: demandValues,
            backgroundColor: '#FF7043'
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        scales: {
          x: { stacked: false, ticks: { font: { size: 14 } } },
          y: { stacked: false, beginAtZero: true, ticks: { font: { size: 14 } } }
        }
      }
    });
  }