// jobmarket.js

const chartInstances = {};

document.addEventListener('DOMContentLoaded', function() {
    Promise.all([
        loadCategoryOptions(), 
        loadStatusOptions(),
        loadRewardOptions(),
        loadTeacherOptions()
      ]).then(() => {
    loadJobMarketData();
}).catch(err => {
    console.error("Error loading filter options:", err);
    // even if they fail, still attempt to load main logic
    loadJobMarketData();
  });
});


function loadCategoryOptions() {
    return fetch("api/api.php?endpoint=categories-list")
      .then(res => res.json())
      .then(data => {
        const categorySelect = document.getElementById("category");
        categorySelect.innerHTML = '<option value="">All</option>';
        data.forEach(item => {
          const opt = document.createElement("option");
          opt.value = item.job_categories_id;
          opt.textContent = item.categories_name;
          categorySelect.appendChild(opt);
        });
      });
  }
  
  function loadStatusOptions() {
    return fetch("api/api.php?endpoint=status-list")
      .then(res => res.json())
      .then(data => {
        const statusSelect = document.getElementById("status");
        statusSelect.innerHTML = '<option value="">All</option>';
        data.forEach(item => {
          const opt = document.createElement("option");
          opt.value = item.job_status_id;
          opt.textContent = item.job_status_name;
          statusSelect.appendChild(opt);
        });
      });
  }
  
  function loadRewardOptions() {
    return fetch("api/api.php?endpoint=reward-list")
      .then(res => res.json())
      .then(data => {
        const rewardSelect = document.getElementById("reward");
        rewardSelect.innerHTML = '<option value="">All</option>';
        data.forEach(item => {
          const opt = document.createElement("option");
          opt.value = item.reward_type_id;
          opt.textContent = item.reward_name;
          rewardSelect.appendChild(opt);
        });
      });
  }
  
  function loadTeacherOptions() {
    return fetch("api/api.php?endpoint=teacher-list")
      .then(res => res.json())
      .then(data => {
        const teacherSelect = document.getElementById("teacher");
        teacherSelect.innerHTML = '<option value="">All</option>';
        data.forEach(item => {
          const opt = document.createElement("option");
          opt.value = item.teachers_id;
          opt.textContent = item.name;
          teacherSelect.appendChild(opt);
        });
      });
  }

function applyFilters() {
    loadJobMarketData();
}

function loadJobMarketData() {
    const { start, end, category, status, reward, teacher } = getFilterValues();

    let paramsMarket = buildParams("job-market", start, end, category, status, reward, teacher);
    fetch("api/api.php?" + paramsMarket.toString())
        .then(res => res.json())
        .then(data => {
            if (!data || data.length === 0) return;
            const totalJobs = data.reduce((sum, row) => sum + Number(row.total_jobs), 0);
            if (document.getElementById("activeJobs")) {
                document.getElementById("activeJobs").textContent = totalJobs;
            }
            renderBarChart("activeJobsChart",
                data.map(d => d.category_name),
                data.map(d => d.total_jobs),
                "Active Jobs",
                "#FF6B00"
            );
        })
        .catch(err => console.error("Error fetching active jobs:", err));

    // job-categories-stats => doughnut
    let paramsCat = buildParams("job-categories-stats", start, end, category, status, reward, teacher);
    fetch("api/api.php?" + paramsCat.toString())
        .then(res => res.json())
        .then(data => {
            renderPieChart("jobCategoriesChart",
                data.map(d => `${d.categories_name} `),
                data.map(d => d.total_jobs),
                [
                    "#FF6384","#36A2EB","#FFCE56","#4BC0C0","#9966FF",
                    "#FF9F40","#4BC0C0","#FF6384","#36A2EB","#FFCE56"
                ]
            );
        })
        .catch(err => console.error("Error fetching categories stats:", err));

    // job-status-stats => doughnut
    let paramsStatus = buildParams("job-status-stats", start, end, category, status, reward, teacher);
    fetch("api/api.php?" + paramsStatus.toString())
        .then(res => res.json())
        .then(data => {
            renderPieChart("jobStatusChart",
                data.map(d => `${d.job_status_name}`),
                data.map(d => d.total_jobs),
                ["#36A2EB","#FF6384","#FFCE56"]
            );
        })
        .catch(err => console.error("Error fetching status stats:", err));

    // reward-type-stats => doughnut
    let paramsReward = buildParams("reward-type-stats", start, end, category, status, reward, teacher);
    fetch("api/api.php?" + paramsReward.toString())
        .then(res => res.json())
        .then(data => {
            renderPieChart("rewardTypeChart",
                data.map(d => `${d.reward_name} `),
                data.map(d => d.total_jobs),
                ["#4BC0C0","#FF6384"]
            );
        })  //(${d.percentage}%)
        .catch(err => console.error("Error fetching reward type:", err));

    // pay-rate => money vs experience
    let paramsPay = buildParams("pay-rate", start, end, category, status, reward, teacher);
    fetch("api/api.php?" + paramsPay.toString())
        .then(res => res.json())
        .then(data => {
            if (data && data.length > 0) {
                const payRateStats = data[0];
                if (document.getElementById("averagePayRate")) {
                    document.getElementById("averagePayRate").innerHTML = `
                        <div class="text-lg">
                            <div>Money: ${payRateStats.money_percentage}%</div>
                            <div>Experience: ${payRateStats.experience_percentage}%</div>
                        </div>
                    `;
                }
                renderPieChart("payRateChart",
                    ["Money","Experience"],
                    [payRateStats.money_percentage, payRateStats.experience_percentage],
                    ["#36A2EB","#FF6384"]
                );
            }
        })
        .catch(err => console.error("Error fetching pay-rate:", err));

    // completion-rate => doughnut
    let paramsComp = buildParams("completion-rate", start, end, category, status, reward, teacher);
    fetch("api/api.php?" + paramsComp.toString())
        .then(res => res.json())
        .then(data => {
            if (data && data.length > 0) {
                const stats = data[0];
                if (document.getElementById("completionRate")) {
                    document.getElementById("completionRate").innerHTML = `
                        <div class="text-lg">${stats.completion_percentage}%</div>
                        <div class="text-sm">(${stats.accepted_applications}/${stats.total_applications} apps)</div>
                    `;
                }
                renderPieChart("successRateChart",
                    ["Accepted","Other"],
                    [
                        stats.completion_percentage,
                        (100 - stats.completion_percentage)
                    ],
                    ["#4BC0C0","#FF6384"]
                );
            }
        })
        .catch(err => console.error("Error fetching completion-rate:", err));

    // job-subcategories-stats => subcategory distribution
    let paramsSubcat = buildParams("job-subcategories-stats", start, end, category, status, reward, teacher);
    fetch("api/api.php?" + paramsSubcat.toString())
        .then(res => res.json())
        .then(data => {
            renderPieChart("jobSubcatChart",
                data.map(d => `${d.subcategories_name} (${d.total_jobs})`),
                data.map(d => Number(d.total_jobs)),
                [
                    "#FFD700","#C0C0C0","#CD7F32","#FF6B00","#4B0082","#7E57C2"
                ]
            );
        })
        .catch(err => console.error("Error fetching subcategories:", err));


    // Fetch and render application status distribution
let paramsStatusDist = buildParams("application-status-distribution", start, end, category, status, reward, teacher);
fetch("api/api.php?" + paramsStatusDist.toString())
    .then(res => res.json())
    .then(data => {
        if (data && data.length > 0) {
            const stats = data[0];
            renderPieChart("applicationStatusChart",
                ["Accepted", "Rejected", "Pending"],
                [stats.accepted_applications, stats.rejected_applications, stats.pending_applications],
                ["#36A2EB", "#FF6384", "#FFCE56"] // Colors for Accepted, Rejected, Pending
            );
        }
    })
    .catch(err => console.error("Error fetching application status distribution:", err));
}

// ============== Helper Functions ==============
function getFilterValues() {
    return {
        start: document.getElementById('startDate')?.value || '',
        end: document.getElementById('endDate')?.value || '',
        category: document.getElementById('category')?.value || '',
        status: document.getElementById('status')?.value || '',
        reward: document.getElementById('reward')?.value || '',
        teacher: document.getElementById('teacher')?.value || ''
    };
}

function buildParams(endpoint, start, end, category, status, reward, teacher) {
    const p = new URLSearchParams({ endpoint });
    if (start) p.set('start', start);
    if (end) p.set('end', end);
    if (category) p.set('category', category);
    if (status) p.set('status', status);
    if (reward) p.set('reward', reward);
    if (teacher) p.set('teacher', teacher);
    return p;
}

function renderBarChart(canvasId, labels, values, labelText, bgColor) {
    if (!chartInstances[canvasId]) chartInstances[canvasId] = null;
    if (chartInstances[canvasId]) {
        chartInstances[canvasId].destroy();
    }
    chartInstances[canvasId] = new Chart(document.getElementById(canvasId), {
        type: "bar",
        data: { labels, datasets: [{ label: labelText, data: values, backgroundColor: bgColor }] },
        options: { responsive: true, maintainAspectRatio: false }
    });
}

function renderPieChart(canvasId, labels, values, colorsArray, chartTitle = "") {
    // Calculate total sum of values
    const total = values.reduce((acc, cur) => acc + Number(cur), 0);
  
    if (chartInstances[canvasId]) {
        chartInstances[canvasId].destroy();
    }
  
    // Set a threshold: show data labels if there are 8 or fewer slices
    const showDataLabels = labels.length <= 8;
  
    chartInstances[canvasId] = new Chart(document.getElementById(canvasId), {
        type: "pie",
        data: {
            labels,
            datasets: [{
                data: values,
                backgroundColor: colorsArray
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                title: {
                    display: chartTitle !== "",
                    text: chartTitle,
                    font: { size: 16 }
                },
                datalabels: {
                    display: showDataLabels,
                    anchor: 'center',
                    align: 'end',
                    offset: 2,  // conditionally display labels
                    formatter: function(value, context) {
                        let label = context.chart.data.labels[context.dataIndex] || "";
                        // Optionally, break the label into multiple lines if it's long:
                        if (label.length > 15) {
                            label = label.match(/.{1,15}/g).join("\n");
                        }
                        const total = context.chart.data.datasets[0].data.reduce((acc, cur) => acc + Number(cur), 0);
                        const percent = ((value / total) * 100).toFixed(1) + '%';
                        return label + "\n" + "         "+percent;
                        
                    },
                    color: '#000000',
                    font: { weight: 'bold', size: 12 },
                    padding: 12,
                    clip: true
                },
                tooltip: {
                    enabled: true
                }
            }
        },
        plugins: [ChartDataLabels]
    });
  }

function renderLineChart(canvasId, labels, values, labelText, color) {
    if (chartInstances[canvasId]) {
        chartInstances[canvasId].destroy();
    }
    chartInstances[canvasId] = new Chart(document.getElementById(canvasId), {
        type: "line",
        data: {
            labels,
            datasets: [{
                label: labelText,
                data: values,
                borderColor: color,
                fill: false
            }]
        },
        options: { responsive: true, maintainAspectRatio: false }
    });
}


