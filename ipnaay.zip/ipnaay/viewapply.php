<?php
// เชื่อมต่อกับฐานข้อมูล
include('database.php');


// ตัวกรองสาขาและชั้นปี
$filter_major = isset($_GET['major']) ? mysqli_real_escape_string($conn, $_GET['major']) : '';
$filter_year = isset($_GET['year']) ? mysqli_real_escape_string($conn, $_GET['year']) : '';

// สร้างคำสั่ง SQL
$sql = "SELECT 
            students.id, 
            students.name, 
            mojor.mojor_name, 
            students.year, 
            job_applications.resume
        FROM students
        INNER JOIN mojor ON students.major_id = mojor.id
        INNER JOIN job_applications ON job_applications.student_id = students.id";


// เพิ่มเงื่อนไขตัวกรองใน SQL
$where_conditions = [];
if ($filter_major) {
    $where_conditions[] = "mojor.mojor_name = '$filter_major'";
}
if ($filter_year) {
    $where_conditions[] = "students.year = '$filter_year'";
}
if (!empty($where_conditions)) {
    $sql .= " WHERE " . implode(" AND ", $where_conditions);
}

// เรียกใช้คำสั่ง SQL
$result = $conn->query($sql);


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Teaching Assistant View Applications Page">
    <title>Teaching Assistant Applications</title>
    <!-- Google Fonts -->
    <link
        href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&family=Montserrat:wght@600&display=swap"
        rel="stylesheet">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <link rel="stylesheet" href="viewapply.css">
    <link rel="stylesheet" href="header-footerstyle.css">

</head>

<body>
    <!-- Header -->
    <header class="headerTop">
        <div class="headerTopImg">
            <img src="logo.png" alt="Naresuan University Logo">
            <a href="#">Naresuan University</a>
        </div>
        <nav class="header-nav">
            <a href="#">About Us</a>
            <a href="#">News</a>
            <a href="#">Logout</a>
        </nav>
    </header>

    <!-- ปุ่ม back -->
    <div>
        <a href="#" class="back-arrow"></a> <!-- เพิ่ม href หน้าโปรไฟล์จารย์-->
    </div>

    <!-- Main Content -->
    <div class="container">
        <div class="title-container">
            <a href="#">View Applications</a> <!-- เพิ่ม href ที่นี่ -->
            <a href="#">Manage Job</a> <!-- เพิ่ม href ที่นี่ -->
        </div>
        <br>
        <div>
            <h1>Teaching Assistant</h1>
        </div>
        <br>
        <div class="bar">
            <a href="viewapply.php" class="<?= empty($_GET['major']) ? 'active' : '' ?>">ทั้งหมด</a>
            <a href="viewapply.php?major=Computer Science" class="<?= isset($_GET['major']) && $_GET['major'] == 'Computer Science' ? 'active' : '' ?>">วิทยาการคอมพิวเตอร์</a>
            <a href="viewapply.php?major=Information Technology" class="<?= isset($_GET['major']) && $_GET['major'] == 'Information Technology' ? 'active' : '' ?>">เทคโนโลยีสารสนเทศ</a>
            <!-- เพิ่มปุ่มฟิลเตอร์ -->
            <i class="bi bi-filter ms-auto" id="filter-btn" style="cursor: pointer;" ></i>
        </div>

        <!-- ซ่อนข้อความ -->
        <div id="hidden-message" class="message-box">สาขา<br>
                <button class="selected branch-btn" data-major="Computer Science">วิทยาการคอมพิวเตอร์</button>
                <button class="selected branch-btn" data-major="Information Technology">เทคโนโลยีสารสนเทศ</button>
    
                <br><br>
                <p>ชั้นปี</p>
                <button class="selected year-btn" data-year="1">ปี 1</button>
                <button class="selected year-btn" data-year="2">ปี 2</button>
                <button class="selected year-btn" data-year="3">ปี 3</button>
                <button class="selected year-btn" data-year="4">ปี 4</button>
    
                <br><br>
                <button class="selected" id="clear-btn">ล้าง</button>
                <button class="selected" id="apply-btn">ตกลง</button>
            </div>
        </div>

        <!-- รายชื่อนิสิต -->
        <div class="application-list">
            <?php
            // วนลูปแสดงผลข้อมูลนิสิต
            if ($result->num_rows > 0) {
                $number = 1; // ตัวเลขลำดับ
                while ($row = $result->fetch_assoc()) {
                    ?>
                    <div class="application-card">
                        <div class="number"><?= $number ?></div>
                        <div class="profile-img">
                            <?= strtoupper(mb_substr($row['name'], 0, 1, 'UTF-8')) ?>
                        </div>
                        <div class="details">
                            <div class="name"><?= htmlspecialchars($row['name']) ?></div>
                            <div class="department">สาขา <?= htmlspecialchars($row['mojor_name']) ?></div>
                            <div class="year">ปี <?= htmlspecialchars($row['year']) ?></div>
                        </div>
                        <a href="viewapply2.html" class="chevron-link">
                            <i class="bi bi-chevron-right"></i>
                        </a> 
                    </div>
                    <?php
                    $number++;
                }
            } else {
                // กรณีไม่มีข้อมูล
                echo "<div>ไม่มีข้อมูลนิสิตที่สมัครงาน</div>";
            }
        ?>
    </div>
    
    </div>

    <script src="viewapply.js"></script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-..." crossorigin="anonymous"></script>
       
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-..." crossorigin="anonymous"></script>

    <!-- Footer -->
    <footer class="footer">
        <p>© CSIT - Computer Science and Information Technology</p>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
