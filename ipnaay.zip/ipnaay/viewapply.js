// รอให้ DOM โหลดเสร็จก่อนทำงาน
document.addEventListener('DOMContentLoaded', () => {
    let selectedMajor = ""; // เก็บค่าที่เลือกของสาขา
    let selectedYear = "";  // เก็บค่าที่เลือกของชั้นปี

    // เลือกปุ่มฟิลเตอร์โดยใช้ ID
    document.getElementById('filter-btn').addEventListener('click', function () {
        // เลือกกรอบข้อความที่ซ่อนโดยใช้ ID
        const message = document.getElementById('hidden-message');
        
        // ตรวจสอบสถานะการแสดงผลของกรอบข้อความ
        if (message.style.display === 'none' || message.style.display === '') {
            message.style.display = 'block'; // แสดงกรอบข้อความ
        } else {
            message.style.display = 'none'; // ซ่อนกรอบข้อความ
        }
    });

    // จัดการปุ่มสาขา (แยกเฉพาะปุ่มใน #hidden-message)
    const branchButtons = document.querySelectorAll('.branch-btn');
    branchButtons.forEach(button => {
        button.addEventListener('click', () => {
            // ลบคลาส active จากปุ่มสาขาเดิมทั้งหมดใน #hidden-message
            branchButtons.forEach(btn => btn.classList.remove('active'));

            // เพิ่มคลาส active ให้ปุ่มที่ถูกเลือก
            button.classList.add('active');

            // เก็บค่า major ที่เลือก
            selectedMajor = button.getAttribute("data-major");
        });
    });

    // จัดการปุ่มชั้นปี (แยกเฉพาะปุ่มใน #hidden-message)
    const yearButtons = document.querySelectorAll('.year-btn');
    yearButtons.forEach(button => {
        button.addEventListener('click', () => {
            // ลบคลาส active จากปุ่มชั้นปีเดิมทั้งหมดใน #hidden-message
            yearButtons.forEach(btn => btn.classList.remove('active'));

            // เพิ่มคลาส active ให้ปุ่มที่ถูกเลือก
            button.classList.add('active');

            // เก็บค่า year ที่เลือก
            selectedYear = button.getAttribute("data-year");
        });
    });

    // ปุ่ม Clear สำหรับรีเซ็ตทั้งปุ่มสาขาและปุ่มชั้นปี
    const clearButton = document.getElementById('clear-btn');
    clearButton.addEventListener('click', () => {
        // ลบคลาส active จากปุ่มสาขาและปุ่มชั้นปีทั้งหมดใน #hidden-message
        branchButtons.forEach(btn => btn.classList.remove('active'));
        yearButtons.forEach(btn => btn.classList.remove('active'));

        // รีเซ็ตค่าที่เลือก
        selectedMajor = "";
        selectedYear = "";
    });

    // ปุ่มตกลง
    const applyButton = document.getElementById('apply-btn');
    applyButton.addEventListener('click', () => {

        // ตรวจสอบว่ามีการเลือกค่าหรือไม่
        if (selectedMajor && selectedYear) {
            // ส่งค่าไปยัง PHP ผ่าน URL
            window.location.href = `viewapply.php?major=${encodeURIComponent(selectedMajor)}&year=${encodeURIComponent(selectedYear)}`;
        } else {
            alert("กรุณาเลือกสาขาและชั้นปี");
        }
    });
});



//เส้นใต้ตรงแถบ bar ค้างอยู่
document.addEventListener("DOMContentLoaded", function() {
    const links = document.querySelectorAll(".bar a");

    links.forEach(link => {
        link.addEventListener("click", function() {
            // ลบคลาส active จากทุกลิงก์ก่อน
            links.forEach(el => el.classList.remove("active"));

            // เพิ่มคลาส active ให้ลิงก์ที่ถูกคลิก
            this.classList.add("active");
        });
    });
});
