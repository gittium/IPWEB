function showReportModal() {
    document.getElementById("reportModal").style.display = "block";
}

function closeReportModal() {
    document.getElementById("reportModal").style.display = "none";
}

function submitReport() {
    const reasonId = document.getElementById("report-reason").value;
    // ทำการส่งข้อมูลการรายงานไปยังเซิร์ฟเวอร์
    // ตัวอย่างการใช้ AJAX หรือการส่งฟอร์ม
    alert("รายงานเหตุผล ID: " + reasonId);
    closeReportModal();
}