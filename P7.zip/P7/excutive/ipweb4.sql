-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: db
-- Generation Time: Mar 01, 2025 at 05:03 AM
-- Server version: 8.0.40
-- PHP Version: 8.2.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;


--

--

-- --------------------------------------------------------

--
-- Table structure for table `accepted_application`
--

CREATE TABLE `accepted_application` (
  `accepted_app_id` int NOT NULL,
  `job_app_id` int NOT NULL,
  `post_jobs_id` int NOT NULL,
  `students_id` varchar(11) COLLATE utf8mb4_general_ci NOT NULL,
  `accept_status_id` int NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `accepted_application`
--

INSERT INTO `accepted_application` (`accepted_app_id`, `job_app_id`, `post_jobs_id`, `students_id`, `accept_status_id`, `created_at`) VALUES
(1, 1, 1, '64312132', 1, '2025-02-26 18:48:57'),
(2, 2, 2, '65312121', 1, '2025-02-26 18:48:57'),
(3, 3, 4, '65312122', 1, '2025-02-26 18:48:57'),
(4, 4, 4, '65312123', 2, '2025-02-26 18:48:57'),
(5, 5, 5, '65312124', 1, '2025-02-26 18:48:57'),
(6, 6, 6, '65312125', 3, '2025-02-26 18:48:57'),
(7, 7, 7, '65312126', 1, '2025-02-26 18:48:57'),
(8, 8, 8, '65312127', 1, '2025-02-26 18:48:57'),
(9, 9, 9, '65312128', 2, '2025-02-26 18:48:57'),
(10, 10, 10, '65312129', 1, '2025-02-26 18:48:57'),
(11, 11, 11, '65312130', 3, '2025-02-26 18:48:57'),
(12, 12, 12, '66312121', 1, '2025-02-26 18:48:57'),
(13, 13, 13, '66312122', 2, '2025-02-26 18:48:57'),
(14, 14, 3, '67312111', 3, '2025-02-26 18:48:57'),
(15, 15, 3, '67312112', 1, '2025-02-26 18:48:57'),
(16, 16, 12, '64312132', 1, '2025-02-26 18:48:57'),
(17, 17, 6, '64312132', 2, '2025-02-26 18:48:57'),
(18, 18, 1, '67312112', 2, '2025-02-26 18:48:57'),
(19, 6, 6, '65312125', 1, '2025-02-27 05:12:16'),
(20, 6, 6, '65312125', 1, '2025-02-27 05:16:57'),
(21, 6, 6, '65312125', 1, '2025-02-27 05:17:57'),
(22, 6, 6, '65312125', 1, '2025-02-27 05:18:26'),
(23, 6, 6, '65312125', 1, '2025-02-27 05:18:42'),
(24, 6, 6, '65312125', 1, '2025-02-27 05:28:09'),
(25, 6, 6, '65312125', 2, '2025-02-27 05:28:25'),
(26, 6, 6, '65312125', 1, '2025-02-27 05:31:16'),
(27, 6, 6, '65312125', 2, '2025-02-27 05:31:41'),
(28, 6, 6, '65312125', 1, '2025-02-27 05:48:54'),
(29, 6, 6, '65312125', 2, '2025-02-27 05:49:02'),
(30, 6, 6, '65312125', 1, '2025-02-27 05:49:18'),
(31, 6, 6, '65312125', 2, '2025-02-27 05:49:46'),
(32, 6, 6, '65312125', 1, '2025-02-27 05:52:00');

-- --------------------------------------------------------

--
-- Table structure for table `accept_status`
--

CREATE TABLE `accept_status` (
  `accept_status_id` int NOT NULL,
  `accept_status_name` enum('Accepted','Rejected','Pending') COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `accept_status`
--

INSERT INTO `accept_status` (`accept_status_id`, `accept_status_name`) VALUES
(1, 'Accepted'),
(2, 'Rejected'),
(3, 'Pending');

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `admins_id` varchar(11) COLLATE utf8mb4_general_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`admins_id`, `name`, `email`) VALUES
('admin0141', 'อานนท์ สุขสบาย', 'anons@nu.ac.th'),
('admin0142', 'ปวีณา ทองดี', 'paweenat@nu.ac.th'),
('admin0143', 'กฤษณะ วงศ์ใหญ่', 'krisanaw@nu.ac.th'),
('admin0144', 'จิราพร อินทร', 'jiraporni@nu.ac.th'),
('admin0145', 'สมพงษ์ ศรีสุข', 'sompongs@nu.ac.th');

-- --------------------------------------------------------

--
-- Table structure for table `close_detail`
--

CREATE TABLE `close_detail` (
  `close_detail_id` int NOT NULL,
  `close_detail_name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `close_detail`
--

INSERT INTO `close_detail` (`close_detail_id`, `close_detail_name`) VALUES
(1, 'นิสิตเกิดอุบัติเหตุ'),
(2, 'นิสิตป่วย'),
(3, 'อาจารย์ป่วย'),
(4, 'นิสิตติดกิจธุระ เช่น ลาบวช'),
(5, 'นิสิตพ้นสภาพ'),
(6, 'นิสิตเสียชีวิต'),
(7, 'มีปัญหาด้านคุณภาพงาน'),
(8, 'ต้องการปิดโครงการให้เสร็จภายในภาคการศึกษานั้น ๆ'),
(9, 'นิสิตอาจทำงานไม่ตรงตามที่อาจารย์คาดหวัง'),
(10, 'ตรวจสอบแล้วว่างานบรรลุเป้าหมายที่ตั้งไว้'),
(11, 'อาจารย์มีภารกิจอื่นที่ต้องจัดการต่อ'),
(12, 'อื่นๆ');

-- --------------------------------------------------------

--
-- Table structure for table `close_jobs`
--

CREATE TABLE `close_jobs` (
  `close_jobs_id` int NOT NULL,
  `post_jobs_id` int NOT NULL,
  `close_detail_id` int NOT NULL,
  `detail` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `close_jobs`
--

INSERT INTO `close_jobs` (`close_jobs_id`, `post_jobs_id`, `close_detail_id`, `detail`, `created_at`) VALUES
(1, 10, 10, '', '2025-02-26 18:48:57');

-- --------------------------------------------------------

--
-- Table structure for table `executives`
--

CREATE TABLE `executives` (
  `executives_id` varchar(11) COLLATE utf8mb4_general_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `executives`
--

INSERT INTO `executives` (`executives_id`, `name`, `email`) VALUES
('exec0146', 'ดร.วิชาญ ปัญญาไว', 'wichanp@nu.ac.th'),
('exec0147', 'สุรีย์พร วัฒนธรรม', 'sureepornw@nu.ac.th'),
('exec0148', 'มนตรี กิจเจริญ', 'montreek@nu.ac.th'),
('exec0149', 'ปิยะดา อินทรสวัสดิ์', 'piyadai@nu.ac.th'),
('exec0150', 'อำพร คงวิเศษ', 'amponk@nu.ac.th');

-- --------------------------------------------------------

--
-- Table structure for table `interests`
--

CREATE TABLE `interests` (
  `interests_id` int NOT NULL,
  `interests_name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `interests`
--

INSERT INTO `interests` (`interests_id`, `interests_name`) VALUES
(1, 'Technology'),
(2, 'Sports'),
(3, 'Music'),
(4, 'Cooking'),
(5, 'Traveling'),
(6, 'Reading'),
(7, 'Photography'),
(8, 'Gardening'),
(9, 'Fashion'),
(10, 'Art'),
(11, 'Fitness'),
(12, 'Movies'),
(13, 'Gaming'),
(14, 'History'),
(15, 'Science'),
(16, 'Education'),
(17, 'Literature'),
(18, 'Painting'),
(19, 'Coding'),
(20, 'Architecture'),
(21, 'Yoga'),
(22, 'Animals'),
(23, 'Astronomy'),
(24, 'Social Media'),
(25, 'Philosophy'),
(26, 'Politics'),
(27, 'Meditation'),
(28, 'Comics'),
(29, 'Theatre'),
(30, 'Dance'),
(31, 'Entrepreneurship'),
(32, 'Hiking'),
(33, 'Languages'),
(34, 'DIY Projects'),
(35, 'Volunteering'),
(36, 'Environmentalism'),
(37, 'Sustainability'),
(38, 'Comedy'),
(39, 'IOT'),
(40, 'Blockchain'),
(41, 'AI&ML'),
(42, 'Spirituality'),
(43, 'Cloud Computing'),
(44, 'Shopping'),
(45, 'Cryptocurrency'),
(46, 'Interior Design'),
(47, 'UX&UI'),
(48, 'Music Production'),
(49, 'Vintage Collecting'),
(50, 'Graphic Design'),
(51, 'App Design'),
(52, 'Web Design'),
(53, 'Cybersecurity'),
(54, 'VR&AR');

-- --------------------------------------------------------

--
-- Table structure for table `job_application`
--

CREATE TABLE `job_application` (
  `job_app_id` int NOT NULL,
  `post_jobs_id` int NOT NULL,
  `students_id` varchar(11) COLLATE utf8mb4_general_ci NOT NULL,
  `GPA` int NOT NULL,
  `phone_number` varchar(11) COLLATE utf8mb4_general_ci NOT NULL,
  `resume` text COLLATE utf8mb4_general_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `job_application`
--

INSERT INTO `job_application` (`job_app_id`, `post_jobs_id`, `students_id`, `GPA`, `phone_number`, `resume`, `created_at`) VALUES
(1, 1, '64312132', 4, '0812345678', 'resumes/thanaree.pdf', '2025-02-26 18:48:57'),
(2, 2, '65312121', 3, '0823456789', 'resumes/somchai.pdf', '2025-02-26 18:48:57'),
(3, 4, '65312122', 4, '0834567890', 'resumes/somsri.pdf', '2025-02-26 18:48:57'),
(4, 4, '65312123', 3, '0845678901', 'resumes/suchart.pdf', '2025-02-26 18:48:57'),
(5, 5, '65312124', 4, '0856789012', 'resumes/kitti.pdf', '2025-02-26 18:48:57'),
(6, 6, '65312125', 4, '0867890123', 'resumes/pimlapas.pdf', '2025-02-26 18:48:57'),
(7, 7, '65312126', 3, '0878901234', 'resumes/anucha.pdf', '2025-02-26 18:48:57'),
(8, 8, '65312127', 4, '0889012345', 'resumes/siriporn.pdf', '2025-02-26 18:48:57'),
(9, 9, '65312128', 4, '0890123456', 'resumes/attapon.pdf', '2025-02-26 18:48:57'),
(10, 10, '65312129', 3, '0801234567', 'resumes/worawit.pdf', '2025-02-26 18:48:57'),
(11, 11, '65312130', 4, '0812345678', 'resumes/sudarat.pdf', '2025-02-26 18:48:57'),
(12, 12, '66312121', 4, '0823456789', 'resumes/tanin.pdf', '2025-02-26 18:48:57'),
(13, 13, '66312122', 3, '0834567890', 'resumes/nanticha.pdf', '2025-02-26 18:48:57'),
(14, 3, '67312111', 3, '0845678901', 'resumes/panupon.pdf', '2025-02-26 18:48:57'),
(15, 3, '67312112', 3, '0856789012', 'resumes/chalathit.pdf', '2025-02-26 18:48:57'),
(16, 12, '64312132', 4, '0812345678', 'resumes/thanaree.pdf', '2025-02-26 18:48:57'),
(17, 6, '64312132', 4, '0812345678', 'resumes/thanaree.pdf', '2025-02-26 18:48:57'),
(18, 1, '67312112', 3, '0856789012', 'resumes/chalathit.pdf', '2025-02-26 18:48:57');

-- --------------------------------------------------------

--
-- Table structure for table `job_categories`
--

CREATE TABLE `job_categories` (
  `job_categories_id` int NOT NULL,
  `categories_name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `job_categories`
--

INSERT INTO `job_categories` (`job_categories_id`, `categories_name`) VALUES
(1, 'Website Development'),
(2, 'Design'),
(3, 'Application'),
(4, 'Technical'),
(5, 'Data'),
(6, 'Education'),
(7, 'Other');

-- --------------------------------------------------------

--
-- Table structure for table `job_status`
--

CREATE TABLE `job_status` (
  `job_status_id` int NOT NULL,
  `job_status_name` enum('open','close','delete') COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'open'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `job_status`
--

INSERT INTO `job_status` (`job_status_id`, `job_status_name`) VALUES
(1, 'open'),
(2, 'close'),
(3, 'delete');

-- --------------------------------------------------------

--
-- Table structure for table `job_subcategories`
--

CREATE TABLE `job_subcategories` (
  `job_sub_id` int NOT NULL,
  `job_categories_id` int NOT NULL,
  `subcategories_name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `job_subcategories`
--

INSERT INTO `job_subcategories` (`job_sub_id`, `job_categories_id`, `subcategories_name`) VALUES
(1, 1, 'Web Development'),
(2, 1, 'Wordpress'),
(3, 1, 'E-Commerce'),
(4, 1, 'Chatbot'),
(5, 1, 'พัฒนาเกม (Game Development)'),
(6, 2, 'UX/UI Design for Web & App'),
(7, 3, 'Mobile Application'),
(8, 3, 'Desktop Application'),
(9, 4, 'IT Solution และ Support'),
(10, 4, 'ทำโปรเจค IoT'),
(11, 4, 'Website Scraping'),
(12, 4, 'IT Project Management'),
(13, 4, 'Quality Assurance'),
(14, 4, 'ทำแผนที่ GIS'),
(15, 5, 'วิเคราะห์ดาต้า'),
(16, 5, 'วิเคราะห์งานวิจัย'),
(17, 5, 'Data Science & AI'),
(18, 5, 'Data Engineering'),
(19, 5, 'Data Labeling'),
(20, 6, 'Teaching Assistant'),
(21, 6, 'Research Asistant'),
(22, 7, 'สร้างเหรียญ Crypto'),
(23, 7, 'อื่นๆ');

-- --------------------------------------------------------

--
-- Table structure for table `major`
--

CREATE TABLE `major` (
  `major_id` int NOT NULL,
  `major_name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `major`
--

INSERT INTO `major` (`major_id`, `major_name`) VALUES
(1, 'Computer Science'),
(2, 'Information Technology');

-- --------------------------------------------------------

--
-- Table structure for table `notification`
--

CREATE TABLE `notification` (
  `notifications_id` int NOT NULL,
  `user_id` varchar(11) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `roles_id` int DEFAULT NULL,
  `event_type` enum('job_accepted','job_application','post_expire','reports') COLLATE utf8mb4_general_ci NOT NULL,
  `reference_table` enum('post_jobs','accepted_application','job_appilcation','reports') COLLATE utf8mb4_general_ci NOT NULL,
  `reference_id` int NOT NULL,
  `message` text COLLATE utf8mb4_general_ci NOT NULL,
  `status` enum('unread','read') COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'unread',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `notification`
--

INSERT INTO `notification` (`notifications_id`, `user_id`, `roles_id`, `event_type`, `reference_table`, `reference_id`, `message`, `status`, `created_at`) VALUES
(1, 'CSIT0132', 3, 'job_application', 'job_appilcation', 1, '📥 มีนิสิตสมัครงานใหม่: รับสมัคร TA รายวิชา Internet Programing', 'read', '2025-02-26 21:50:24'),
(2, 'CSIT0132', 3, 'job_application', 'job_appilcation', 2, '📥 มีนิสิตสมัครงานใหม่: ทำแอปพลิเคชันจองคิวร้านอาหาร', 'read', '2025-02-27 02:25:52'),
(3, 'CSIT0134', 3, 'job_application', 'job_appilcation', 3, '📥 มีนิสิตสมัครงานใหม่: พัฒนาเว็บไซต์จองคิวร้านอาหาร', 'unread', '2025-02-26 18:48:57'),
(4, 'CSIT0134', 3, 'job_application', 'job_appilcation', 4, '📥 มีนิสิตสมัครงานใหม่: พัฒนาเว็บไซต์จองคิวร้านอาหาร', 'unread', '2025-02-26 18:48:57'),
(5, 'CSIT0135', 3, 'job_application', 'job_appilcation', 5, '📥 มีนิสิตสมัครงานใหม่: สร้างระบบแจ้งเตือนอัตโนมัติ', 'unread', '2025-02-26 18:48:57'),
(6, 'CSIT0136', 3, 'job_application', 'job_appilcation', 6, '📥 มีนิสิตสมัครงานใหม่: ออกแบบ Dashboard สำหรับร้านอาหาร', 'read', '2025-02-27 04:58:47'),
(7, 'CSIT0137', 3, 'job_application', 'job_appilcation', 7, '📥 มีนิสิตสมัครงานใหม่: พัฒนา Mobile App สำหรับร้านอาหาร', 'unread', '2025-02-26 18:48:57'),
(8, 'CSIT0138', 3, 'job_application', 'job_appilcation', 8, '📥 มีนิสิตสมัครงานใหม่: พัฒนา API สำหรับระบบจองโต๊ะ', 'unread', '2025-02-26 18:48:57'),
(9, 'CSIT0138', 3, 'job_application', 'job_appilcation', 9, '📥 มีนิสิตสมัครงานใหม่: พัฒนาแอปพลิเคชันจองโต๊ะร้านอาหาร (เวอร์ชันขั้นสูง)', 'unread', '2025-02-26 18:48:57'),
(10, 'CSIT0139', 3, 'job_application', 'job_appilcation', 10, '📥 มีนิสิตสมัครงานใหม่: ระบบ AI Chatbot สำหรับร้านอาหาร', 'read', '2025-02-27 06:29:15'),
(11, 'CSIT0140', 3, 'job_application', 'job_appilcation', 11, '📥 มีนิสิตสมัครงานใหม่: พัฒนา Dashboard วิเคราะห์ข้อมูลร้านอาหาร', 'unread', '2025-02-26 18:48:57'),
(12, 'CSIT0140', 3, 'job_application', 'job_appilcation', 12, '📥 มีนิสิตสมัครงานใหม่: พัฒนา Mobile App สำหรับสั่งอาหารและจองโต๊ะ', 'unread', '2025-02-26 18:48:57'),
(13, 'CSIT0140', 3, 'job_application', 'job_appilcation', 13, '📥 มีนิสิตสมัครงานใหม่: พัฒนา API สำหรับเชื่อมต่อร้านอาหารและระบบเดลิเวอรี', 'unread', '2025-02-26 18:48:57'),
(14, 'CSIT0133', 3, 'job_application', 'job_appilcation', 14, '📥 มีนิสิตสมัครงานใหม่: ทำเกมสำหรับฝึกภาษาญี่ปุ่น', 'unread', '2025-02-26 18:48:57'),
(15, 'CSIT0133', 3, 'job_application', 'job_appilcation', 15, '📥 มีนิสิตสมัครงานใหม่: ทำเกมสำหรับฝึกภาษาญี่ปุ่น', 'unread', '2025-02-26 18:48:57'),
(16, 'CSIT0140', 3, 'job_application', 'job_appilcation', 16, '📥 มีนิสิตสมัครงานใหม่: พัฒนา Mobile App สำหรับสั่งอาหารและจองโต๊ะ', 'unread', '2025-02-26 18:48:57'),
(18, 'CSIT0132', 3, 'job_application', 'job_appilcation', 18, '📥 มีนิสิตสมัครงานใหม่: รับสมัคร TA รายวิชา Internet Programing', 'read', '2025-02-27 02:17:03'),
(32, '64312132', 4, 'job_accepted', 'accepted_application', 1, '🎉 คุณได้รับการตอบรับเข้าทำงาน: รับสมัคร TA รายวิชา Internet Programing', 'read', '2025-02-27 11:39:30'),
(33, '65312121', 4, 'job_accepted', 'accepted_application', 2, '🎉 คุณได้รับการตอบรับเข้าทำงาน: ทำแอปพลิเคชันจองคิวร้านอาหาร', '', '2025-02-26 18:48:57'),
(34, '65312122', 4, 'job_accepted', 'accepted_application', 3, '🎉 คุณได้รับการตอบรับเข้าทำงาน: พัฒนาเว็บไซต์จองคิวร้านอาหาร', 'unread', '2025-02-26 18:48:57'),
(35, '65312123', 4, 'job_accepted', 'accepted_application', 4, '❌ ขออภัย! คุณไม่ได้รับการตอบรับ: พัฒนาเว็บไซต์จองคิวร้านอาหาร', 'unread', '2025-02-26 18:48:57'),
(36, '65312124', 4, 'job_accepted', 'accepted_application', 5, '🎉 คุณได้รับการตอบรับเข้าทำงาน: สร้างระบบแจ้งเตือนอัตโนมัติ', 'unread', '2025-02-26 18:48:57'),
(38, '65312126', 4, 'job_accepted', 'accepted_application', 7, '🎉 คุณได้รับการตอบรับเข้าทำงาน: พัฒนา Mobile App สำหรับร้านอาหาร', 'unread', '2025-02-26 18:48:57'),
(39, '65312127', 4, 'job_accepted', 'accepted_application', 8, '🎉 คุณได้รับการตอบรับเข้าทำงาน: พัฒนา API สำหรับระบบจองโต๊ะ', 'unread', '2025-02-26 18:48:57'),
(40, '65312128', 4, 'job_accepted', '', 9, '❌ ขออภัย! คุณไม่ได้รับการตอบรับ: พัฒนาแอปพลิเคชันจองโต๊ะร้านอาหาร (เวอร์ชันขั้นสูง)', 'unread', '2025-02-26 18:48:57'),
(41, '65312129', 4, 'job_accepted', '', 10, '🎉 คุณได้รับการตอบรับเข้าทำงาน: ระบบ AI Chatbot สำหรับร้านอาหาร', 'unread', '2025-02-26 18:48:57'),
(43, '66312121', 4, 'job_accepted', '', 12, '🎉 คุณได้รับการตอบรับเข้าทำงาน: พัฒนา Mobile App สำหรับสั่งอาหารและจองโต๊ะ', 'unread', '2025-02-26 18:48:57'),
(44, '66312122', 4, 'job_accepted', '', 13, '❌ ขออภัย! คุณไม่ได้รับการตอบรับ: พัฒนา API สำหรับเชื่อมต่อร้านอาหารและระบบเดลิเวอรี', 'unread', '2025-02-26 18:48:57'),
(46, '67312112', 4, 'job_accepted', '', 15, '🎉 คุณได้รับการตอบรับเข้าทำงาน: ทำเกมสำหรับฝึกภาษาญี่ปุ่น', 'unread', '2025-02-26 18:48:57'),
(47, '64312132', 4, 'job_accepted', '', 16, '🎉 คุณได้รับการตอบรับเข้าทำงาน: พัฒนา Mobile App สำหรับสั่งอาหารและจองโต๊ะ', 'unread', '2025-02-26 18:48:57'),
(48, '64312132', 4, 'job_accepted', '', 17, '❌ ขออภัย! คุณไม่ได้รับการตอบรับ: ออกแบบ Dashboard สำหรับร้านอาหาร', 'unread', '2025-02-26 18:48:57'),
(63, 'CSIT0131', 2, 'reports', 'reports', 1, '📢 โพสต์ของคุณถูกรีพอร์ต: รับสมัครตัวแทนลงทุน Forex ได้เงินจริง - เหตุผล: งานที่ชวนให้เข้าใจผิด หลอกลวง หรือฉ้อโกงโพสต์ประกาศหางานที่ชวนให้เข้าใจผิด หลอกลวง หรือฉ้อโกง ', 'read', '2025-02-26 19:14:57'),
(64, 'CSIT0139', 2, 'reports', 'reports', 2, '📢 โพสต์ของคุณถูกรีพอร์ต: ต้องการพนักงานทำงานจากที่บ้าน ด่วน!! - เหตุผล: งานที่ชวนให้เข้าใจผิด หลอกลวง หรือฉ้อโกงโพสต์ประกาศหางานที่ชวนให้เข้าใจผิด หลอกลวง หรือฉ้อโกง ', 'read', '2025-02-27 12:03:57'),
(66, '65312123', 3, 'reports', 'reports', 1, '✅ ได้รับการรีพอร์ตของคุณล้ว: รับสมัครตัวแทนลงทุน Forex ได้เงินจริง - เหตุผล: งานที่ชวนให้เข้าใจผิด หลอกลวง หรือฉ้อโกงโพสต์ประกาศหางานที่ชวนให้เข้าใจผิด หลอกลวง หรือฉ้อโกง ', 'unread', '2025-02-26 18:48:57'),
(67, '66312121', 3, 'reports', 'reports', 2, '✅ ได้รับการรีพอร์ตของคุณล้ว: ต้องการพนักงานทำงานจากที่บ้าน ด่วน!! - เหตุผล: งานที่ชวนให้เข้าใจผิด หลอกลวง หรือฉ้อโกงโพสต์ประกาศหางานที่ชวนให้เข้าใจผิด หลอกลวง หรือฉ้อโกง ', 'unread', '2025-02-26 18:48:57'),
(86, '67312112', 4, 'job_accepted', '', 18, '❌ ขออภัย! คุณไม่ได้รับการตอบรับ: รับสมัคร TA รายวิชา Internet Programing', 'unread', '2025-02-26 18:48:57'),
(100, 'CSIT0131', 2, 'reports', 'reports', 1, '1 โพสต์ของคุณถูกรีพอร์ต: รับสมัครตัวแทนลงทุน Forex ได้เงินจริง - เหตุผล: งานที่ชวนให้เข้าใจผิด หลอกลวง หรือฉ้อโกงโพสต์ประกาศหางานที่ชวนให้เข้าใจผิด หลอกลวง หรือฉ้อโกง ', 'read', '2025-02-26 19:15:12'),
(101, 'CSIT0131', 2, 'reports', 'reports', 1, '2 โพสต์ของคุณถูกรีพอร์ต: รับสมัครตัวแทนลงทุน Forex ได้เงินจริง - เหตุผล: งานที่ชวนให้เข้าใจผิด หลอกลวง หรือฉ้อโกงโพสต์ประกาศหางานที่ชวนให้เข้าใจผิด หลอกลวง หรือฉ้อโกง ', 'read', '2025-02-26 19:15:06'),
(102, '65312125', 4, 'job_accepted', 'accepted_application', 19, '✅ ใบสมัครของคุณสำหรับงาน \'ออกแบบ Dashboard สำหรับร้านอาหาร\' ได้รับการอนุมัติแล้ว!', 'unread', '2025-02-27 05:12:16'),
(103, '65312125', 4, 'job_accepted', 'accepted_application', 20, '✅ ใบสมัครของคุณสำหรับงาน \'ออกแบบ Dashboard สำหรับร้านอาหาร\' ได้รับการอนุมัติแล้ว!', 'unread', '2025-02-27 05:16:57'),
(104, '65312125', 4, 'job_accepted', 'accepted_application', 21, '✅ ใบสมัครของคุณสำหรับงาน \'ออกแบบ Dashboard สำหรับร้านอาหาร\' ได้รับการอนุมัติแล้ว!', 'unread', '2025-02-27 05:17:57'),
(105, '65312125', 4, 'job_accepted', 'accepted_application', 22, '✅ ใบสมัครของคุณสำหรับงาน \'ออกแบบ Dashboard สำหรับร้านอาหาร\' ได้รับการอนุมัติแล้ว!', 'unread', '2025-02-27 05:18:26'),
(106, '65312125', 4, 'job_accepted', 'accepted_application', 23, '✅ ใบสมัครของคุณสำหรับงาน \'ออกแบบ Dashboard สำหรับร้านอาหาร\' ได้รับการอนุมัติแล้ว!', 'unread', '2025-02-27 05:18:42'),
(107, '65312125', 4, 'job_accepted', 'accepted_application', 0, '✅ ใบสมัครของคุณได้รับการอนุมัติ', 'unread', '2025-02-27 05:48:54'),
(108, '65312125', 4, 'job_accepted', 'accepted_application', 0, '❌ ใบสมัครของคุณได้รับการปฏิเสธ', 'unread', '2025-02-27 05:49:02'),
(109, '65312125', 4, 'job_accepted', 'accepted_application', 0, '✅ ใบสมัครของคุณได้รับการอนุมัติ', 'unread', '2025-02-27 05:49:18'),
(110, '65312125', 4, 'job_accepted', 'accepted_application', 0, '❌ ใบสมัครของคุณได้รับการปฏิเสธ', 'unread', '2025-02-27 05:49:46'),
(111, '65312125', 4, 'job_accepted', 'accepted_application', 0, '✅ ใบสมัครของคุณได้รับการอนุมัติ', 'unread', '2025-02-27 05:52:00');

-- --------------------------------------------------------

--
-- Table structure for table `post_jobs`
--

CREATE TABLE `post_jobs` (
  `post_jobs_id` int NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `description` text COLLATE utf8mb4_general_ci NOT NULL,
  `skills` text COLLATE utf8mb4_general_ci NOT NULL,
  `job_start` timestamp NULL DEFAULT NULL,
  `job_end` timestamp NULL DEFAULT NULL,
  `number_student` int NOT NULL,
  `reward_type_id` int DEFAULT NULL,
  `timeandwage` int NOT NULL,
  `job_categories_id` int DEFAULT NULL,
  `job_sub_id` int DEFAULT NULL,
  `teachers_id` varchar(11) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `job_status_id` int DEFAULT NULL,
  `image` text COLLATE utf8mb4_general_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `post_jobs`
--

INSERT INTO `post_jobs` (`post_jobs_id`, `title`, `description`, `skills`, `job_start`, `job_end`, `number_student`, `reward_type_id`, `timeandwage`, `job_categories_id`, `job_sub_id`, `teachers_id`, `job_status_id`, `image`, `created_at`) VALUES
(1, 'รับสมัคร TA รายวิชา Internet Programing', 'รายละเอียดงาน: เรากำลังมองหาผู้ช่วยสอน (TA) ที่มีความสามารถในด้านการพัฒนาเว็บไซต์และการเขียนโปรแกรมเว็บเพื่อตอบสนองความต้องการในรายวิชา Internet Programming สำหรับภาคการศึกษานี้ หากคุณมีความรู้พื้นฐานเกี่ยวกับการเขียนโปรแกรมเว็บและต้องการมีประสบการณ์ในการสอนและช่วยเหลือนักศึกษา เราต้องการคุณ!\r\n\r\nคุณสมบัติ:\r\n\r\nจบการศึกษาระดับปริญญาตรีหรือปริญญาโทในสาขาวิทยาศาสตร์คอมพิวเตอร์ หรือสาขาที่เกี่ยวข้อง\r\nมีความรู้ในการเขียนโปรแกรมเว็บ เช่น HTML, CSS, JavaScript, PHP, หรือภาษาอื่นๆ ที่เกี่ยวข้องกับการพัฒนาเว็บไซต์\r\nมีความเข้าใจในหลักการพื้นฐานของการพัฒนาเว็บไซต์และการใช้งานเครื่องมือในการพัฒนา\r\nมีทักษะในการสื่อสารและทำงานเป็นทีมได้ดี\r\nมีประสบการณ์ในการทำงานร่วมกับนักศึกษาหรือเคยทำงานในลักษณะผู้ช่วยสอนจะได้รับการพิจารณาเป็นพิเศษ\r\nหน้าที่และความรับผิดชอบ:\r\n\r\nช่วยอาจารย์ในการเตรียมและสอนเนื้อหาในห้องเรียน\r\nช่วยในการตรวจการบ้านและโปรเจกต์ของนักศึกษา\r\nให้คำปรึกษาแก่นักศึกษาในห้องเรียนและออนไลน์\r\nร่วมสนับสนุนการจัดกิจกรรมและการสอบภายในวิชา\r\nช่วยในการแก้ไขปัญหาทางเทคนิคที่เกิดขึ้นในห้องเรียน', '1,2,3,11,13,21,9', '2024-11-01 11:39:12', '2024-02-01 11:39:12', 1, 1, 3000, 6, 20, 'CSIT0132', 2, 'images/img2.jpg', '2024-09-01 11:39:12'),
(2, 'ทำแอปพลิเคชันจองคิวร้านอาหาร', '📌 รายละเอียดงาน\r\nเรากำลังมองหานักพัฒนาแอปพลิเคชันที่มีความสามารถและความคิดสร้างสรรค์ มาร่วมทีมพัฒนา แอปพลิเคชันจองคิวร้านอาหาร ที่ช่วยให้ลูกค้าสามารถจองโต๊ะล่วงหน้า ตรวจสอบเวลารอคิวแบบเรียลไทม์ และรับการแจ้งเตือนเมื่อถึงคิว ช่วยเพิ่มประสิทธิภาพในการจัดการคิวและลดเวลารอของลูกค้า\r\n\r\n🎯 หน้าที่และความรับผิดชอบ\r\n\r\nออกแบบและพัฒนาแอปพลิเคชัน (Mobile/Web App) สำหรับจองคิวร้านอาหาร\r\nพัฒนาระบบ จองโต๊ะออนไลน์ พร้อมฟีเจอร์แจ้งเตือนเมื่อถึงคิว\r\nสร้าง Dashboard สำหรับร้านอาหาร เพื่อจัดการคิวและสถานะโต๊ะ\r\nพัฒนาและเชื่อมต่อ API กับระบบฐานข้อมูล\r\nทดสอบและปรับปรุงแอปพลิเคชันเพื่อให้ทำงานได้อย่างราบรื่น\r\nทำงานร่วมกับทีม UX/UI เพื่อออกแบบแอปให้ใช้งานง่าย', '6,7,8,11,12,24,17', '2025-02-22 13:18:28', '2025-04-22 10:48:50', 1, 1, 40000, 3, 7, 'CSIT0132', 2, 'images/img1.jpg', '2025-02-15 10:48:50'),
(3, 'ทำเกมสำหรับฝึกภาษาญี่ปุ่น', 'รายละเอียดงาน\r\nเรากำลังมองหานักพัฒนาเกมที่มีความสามารถและความคิดสร้างสรรค์มาร่วมทีม เพื่อสร้างเกมที่ช่วยให้ผู้เล่นฝึกฝนและพัฒนาทักษะภาษาญี่ปุ่นผ่านการเล่นเกมที่สนุกและมีประสิทธิภาพ\r\n\r\nหน้าที่และความรับผิดชอบ:\r\n\r\nออกแบบและพัฒนาเกมเพื่อการฝึกภาษาญี่ปุ่นให้เหมาะสมกับผู้เรียนทุกระดับ\r\nใช้เครื่องมือพัฒนาเกม เช่น Unity, Unreal Engine หรือ GameMaker Studio\r\nออกแบบระบบเกมที่ช่วยส่งเสริมการเรียนรู้ เช่น มินิเกม คำศัพท์ ไวยากรณ์ และบทสนทนา\r\nทำงานร่วมกับนักออกแบบกราฟิก นักเขียนเนื้อหา และผู้เชี่ยวชาญด้านภาษาญี่ปุ่น\r\nทดสอบ แก้ไข และปรับปรุงเกมให้มีประสิทธิภาพและประสบการณ์การใช้งานที่ดี\r\nพัฒนาเกมให้สามารถเล่นได้บนแพลตฟอร์มต่าง ๆ เช่น PC, Mobile (iOS, Android) หรือ Web', '37,38,36,104,105,106', '2025-02-02 04:30:00', '2025-04-03 11:39:12', 4, 1, 45000, 1, 5, 'CSIT0133', 1, 'images/img2.jpg', '2025-01-02 04:30:00'),
(4, 'พัฒนาเว็บไซต์จองคิวร้านอาหาร', 'โครงการนี้เป็นการพัฒนาเว็บไซต์สำหรับร้านอาหารที่ต้องการระบบจองคิวออนไลน์ ลูกค้าสามารถจองโต๊ะล่วงหน้าผ่านเว็บได้ และสามารถตรวจสอบเวลาคิวเรียลไทม์ได้ ฟีเจอร์หลักประกอบด้วย:\r\n\r\n✅ ระบบจองโต๊ะออนไลน์ที่ใช้งานง่ายและสะดวก\r\n\r\n✅ แสดงสถานะคิวแบบเรียลไทม์ โดยใช้ WebSocket หรือ Firebase Realtime Database\r\n\r\n✅ รองรับการแจ้งเตือนผ่านอีเมลหรือ Line Notify เมื่อลูกค้าใกล้ถึงคิว\r\n\r\n✅ มี Dashboard สำหรับร้านอาหารเพื่อจัดการโต๊ะและสถานะการจอง\r\n\r\n✅ รองรับการสมัครสมาชิกและการล็อกอินสำหรับลูกค้าเพื่อบันทึกประวัติการจอง\r\n\r\n✅ ออกแบบให้รองรับมือถือ (Responsive Design)', '1,2,3,4,5,6,7,8,21,24,17', '2025-02-22 12:02:20', '2025-06-30 10:00:00', 2, 1, 35000, 1, 1, 'CSIT0134', 1, 'images/img1.jpg', '2025-02-20 03:30:00'),
(5, 'สร้างระบบแจ้งเตือนอัตโนมัติ', 'เรากำลังมองหานักพัฒนาซอฟต์แวร์ที่สามารถพัฒนาระบบแจ้งเตือนอัตโนมัติสำหรับร้านอาหารเพื่อให้ลูกค้าทราบเมื่อถึงคิว ระบบจะใช้ API และ Webhook ในการแจ้งเตือนผ่านช่องทางต่างๆ เช่น Line, Email, และ SMS ฟีเจอร์ที่ต้องพัฒนา:\r\n\r\n✅ ใช้ Line API และ Email API ในการส่งการแจ้งเตือน\r\n\r\n✅ ระบบตั้งค่าแจ้งเตือนให้ลูกค้าเลือกระยะเวลาการแจ้งเตือนเองได้ (เช่น ก่อนถึงคิว 10 นาที)\r\n\r\n✅ รองรับหลายภาษาสำหรับลูกค้าต่างชาติ\r\n\r\n✅ ออกแบบให้สามารถขยายระบบให้รองรับร้านอาหารหลายแห่งได้\r\n\r\n✅ พัฒนาด้วย Node.js หรือ Python (FastAPI) พร้อมรองรับฐานข้อมูล MySQL หรือ Firebase', '11,14,17,24,19,39,41', '2025-02-22 13:18:28', '2025-07-31 11:00:00', 3, 2, 20000, 3, 7, 'CSIT0135', 1, 'images/img2.jpg', '2025-02-21 04:45:00'),
(6, 'ออกแบบ Dashboard สำหรับร้านอาหาร', 'เรากำลังพัฒนา Dashboard สำหรับผู้ดูแลร้านอาหารเพื่อให้สามารถจัดการคิวลูกค้าได้อย่างมีประสิทธิภาพ โดยระบบต้องรองรับการจัดการโต๊ะและการออกรายงานการจอง ฟีเจอร์สำคัญของระบบนี้ได้แก่:\r\n\r\n✅ ระบบแสดงข้อมูลโต๊ะและคิวในรูปแบบตารางหรือกราฟิกที่ใช้งานง่าย\r\n\r\n✅ การเพิ่ม/ลบ/แก้ไขการจองโดยพนักงาน\r\n\r\n✅ รายงานสถิติการใช้งานโต๊ะ แสดงแนวโน้มการจองในช่วงเวลาต่างๆ\r\n\r\n✅ รองรับการใช้งานบนเว็บเบราว์เซอร์และแท็บเล็ต\r\n\r\n✅ ใช้ React หรือ Vue.js สำหรับ Frontend และ Node.js/Express หรือ Django สำหรับ Backend\r\n\r\n✅ ออกแบบ API ที่รองรับ RESTful หรือ GraphQL', '6,7,101,102,103,24,17', '2025-02-22 13:18:28', '2025-08-31 09:00:00', 2, 1, 40000, 1, 11, 'CSIT0136', 1, 'images/img1.jpg', '2025-02-22 05:15:00'),
(7, 'พัฒนา Mobile App สำหรับร้านอาหาร', 'แอปพลิเคชันจองโต๊ะร้านอาหารที่รองรับทั้ง iOS และ Android พัฒนาโดยใช้ Flutter หรือ React Native เพื่อให้ผู้ใช้สามารถจองโต๊ะจากมือถือได้โดยง่าย ฟีเจอร์ที่ต้องพัฒนา:\r\n\r\n✅ รองรับการจองโต๊ะผ่านแอป และแสดงเวลารอคิวเรียลไทม์\r\n\r\n✅ ระบบแจ้งเตือนแบบ Push Notification ผ่าน Firebase Cloud Messaging (FCM)\r\n\r\n✅ UI/UX ที่ออกแบบมาให้ใช้งานง่าย รองรับ Dark Mode\r\n\r\n✅ ระบบจัดการบัญชีลูกค้า สามารถบันทึกประวัติการจองได้\r\n\r\n✅ รองรับการเชื่อมต่อกับ API ระบบหลักที่ใช้ในการจองโต๊ะร้านอาหาร', '57,58,56,55,24,17,6', '2025-02-22 13:18:28', '2025-06-15 10:00:00', 1, 1, 45000, 3, 7, 'CSIT0137', 2, 'images/img2.jpg', '2025-02-23 07:20:00'),
(8, 'พัฒนา API สำหรับระบบจองโต๊ะ', 'เรากำลังพัฒนา API สำหรับรองรับการจองโต๊ะออนไลน์ โดยจะพัฒนาเป็น REST API ที่สามารถใช้งานร่วมกับแอปพลิเคชันมือถือและเว็บไซต์ได้ ฟีเจอร์หลัก:\r\n\r\n✅ รองรับการสร้าง/อัปเดต/ยกเลิกการจองผ่าน API\r\n\r\n✅ ระบบ Authentication ด้วย JWT หรือ OAuth2\r\n\r\n✅ ระบบจัดการสิทธิ์ของผู้ใช้ (Admin, Customer, Staff)\r\n\r\n✅ รองรับการทำ Load Balancing และ Scaling บน Cloud เช่น AWS หรือ GCP\r\n\r\n✅ พัฒนาโดยใช้ Node.js (Express.js) หรือ Python (Django/FastAPI)', '11,12,13,14,21,22,19,20,17', '2025-02-22 13:18:28', '2025-09-10 10:30:00', 1, 2, 35000, 1, 1, 'CSIT0138', 2, 'images/img1.jpg', '2025-02-24 02:50:00'),
(9, 'พัฒนาแอปพลิเคชันจองโต๊ะร้านอาหาร (เวอร์ชันขั้นสูง)', 'โครงการนี้เป็นการขยายและพัฒนาแอปพลิเคชันจองโต๊ะร้านอาหารให้มีฟีเจอร์ที่ครอบคลุมมากขึ้น รวมถึงการเชื่อมต่อกับระบบ CRM และระบบบริหารจัดการลูกค้า ฟีเจอร์ที่เพิ่มเข้ามาคือ:\r\n\r\n✅ ระบบวิเคราะห์พฤติกรรมลูกค้า เพื่อนำเสนอโปรโมชั่นเฉพาะบุคคล\r\n\r\n✅ รองรับการจองโต๊ะล่วงหน้าเป็นรอบสัปดาห์หรือรายเดือน\r\n\r\n✅ ระบบรีวิวร้านอาหารหลังจากลูกค้าใช้งานเสร็จ\r\n\r\n✅ ระบบแจ้งเตือนการจองซ้ำอัตโนมัติสำหรับลูกค้าประจำ\r\n\r\n✅ ใช้ AI คาดการณ์เวลารอคิว โดยพิจารณาจากข้อมูลการจองก่อนหน้า\r\n\r\n✅ ออกแบบให้สามารถทำงานร่วมกับ POS (Point of Sale) ของร้านอาหารได้', '6,7,11,17,24,57,58', '2025-02-22 12:13:45', '2025-06-30 10:00:00', 3, 2, 30, 3, 7, 'CSIT0138', 1, 'images/img1.jpg', '2025-02-20 03:30:00'),
(10, 'ระบบ AI Chatbot สำหรับร้านอาหาร', 'โครงการนี้ต้องการพัฒนาระบบ AI Chatbot สำหรับร้านอาหารเพื่อช่วยลูกค้าทำการจองโต๊ะและสอบถามข้อมูลเมนูของร้านแบบอัตโนมัติ โดยมีฟีเจอร์ดังนี้:\r\n\r\n✅ ใช้ AI NLP (Natural Language Processing) เพื่อทำความเข้าใจข้อความของลูกค้า\r\n\r\n✅ รองรับการสื่อสารผ่าน Line Chatbot และ Facebook Messenger\r\n\r\n✅ สามารถเชื่อมต่อกับระบบจองโต๊ะและแจ้งเตือนคิวได้\r\n\r\n✅ สามารถแนะนำเมนูที่เหมาะสมให้กับลูกค้า โดยอิงจากประวัติการสั่งซื้อ\r\n\r\n✅ พัฒนาโดยใช้ Python (Dialogflow / Rasa) หรือ Node.js\r\n\r\n✅ มีระบบเรียนรู้และปรับปรุงโมเดล AI โดยอัตโนมัติ', '33,34,35,36,37,38,105,106', '2025-02-22 13:18:28', '2025-07-31 11:00:00', 1, 2, 30000, 1, 4, 'CSIT0139', 2, 'images/img1.jpg', '2025-02-21 04:45:00'),
(11, 'พัฒนา Dashboard วิเคราะห์ข้อมูลร้านอาหาร', 'Dashboard นี้จะช่วยร้านอาหารวิเคราะห์ข้อมูลลูกค้าและยอดขายเพื่อให้สามารถปรับกลยุทธ์ทางธุรกิจได้ดีขึ้น โดยจะมีฟีเจอร์ดังนี้:\r\n\r\n✅ ระบบแสดงสถิติยอดขาย และจำนวนลูกค้าที่เข้าร้านรายวัน/รายเดือน\r\n\r\n✅ วิเคราะห์แนวโน้มของลูกค้า เช่น เวลาที่มีลูกค้าเยอะที่สุด\r\n\r\n✅ ใช้ Machine Learning เพื่อคาดการณ์ยอดขายล่วงหน้า\r\n\r\n✅ รองรับการเชื่อมต่อกับฐานข้อมูล POS และระบบจองโต๊ะ\r\n\r\n✅ ออกแบบ UI ที่เรียบง่ายและใช้งานได้ง่ายโดยใช้ React หรือ Vue.js\r\n\r\n✅ ใช้ Python (Pandas, Matplotlib) สำหรับการวิเคราะห์ข้อมูล', '99,100,101,102,103,104', '2025-02-22 13:18:28', '2025-08-31 09:00:00', 2, 2, 0, 5, 15, 'CSIT0140', 1, 'images/img1.jpg', '0000-00-00 00:00:00'),
(12, 'พัฒนา Mobile App สำหรับสั่งอาหารและจองโต๊ะ', 'โครงการนี้เป็นการรวมระบบจองโต๊ะและระบบสั่งอาหารล่วงหน้าเข้าด้วยกัน เพื่อให้ลูกค้าสามารถสั่งอาหารล่วงหน้าและเลือกโต๊ะที่ต้องการได้ โดยมีฟีเจอร์:\r\n\r\n✅ ลูกค้าสามารถสั่งอาหารล่วงหน้าได้ผ่านแอป\r\n\r\n✅ สามารถเลือกโต๊ะก่อนเดินทางไปถึงร้าน\r\n\r\n✅ ระบบแจ้งเตือนเมื่ออาหารพร้อมเสิร์ฟ\r\n\r\n✅ รองรับระบบชำระเงินผ่าน Mobile Banking หรือ e-Wallet\r\n\r\n✅ รองรับการแสดงเมนูเป็นหลายภาษา (Thai, English, Chinese)\r\n\r\n✅ พัฒนาโดยใช้ Flutter หรือ React Native', '57,58,6,24,17', '2025-03-15 02:00:00', '2025-06-15 10:00:00', 3, 1, 45000, 3, 7, 'CSIT0140', 1, 'images/food_ordering_app.jpg', '2025-02-23 07:20:00'),
(13, 'พัฒนา API สำหรับเชื่อมต่อร้านอาหารและระบบเดลิเวอรี', 'เราต้องการพัฒนา API ที่ช่วยให้ร้านอาหารสามารถเชื่อมต่อกับแพลตฟอร์มเดลิเวอรี เช่น Grab, LINE MAN และ Foodpanda ได้อย่างราบรื่น โดยมีคุณสมบัติดังนี้:\r\n\r\n✅ รองรับการเชื่อมต่อกับระบบ POS ของร้านอาหาร\r\n\r\n✅ API สำหรับจัดการออเดอร์อาหาร (รับคำสั่ง, อัปเดตสถานะ, ยืนยันการจัดส่ง)\r\n\r\n✅ รองรับ OAuth2 Authentication เพื่อให้แพลตฟอร์มภายนอกเข้าถึงข้อมูลได้อย่างปลอดภัย\r\n\r\n✅ มีระบบ Webhook สำหรับแจ้งเตือนการอัปเดตสถานะคำสั่งซื้อ\r\n\r\n✅ ออกแบบให้รองรับการใช้งานกับร้านอาหารหลายแห่ง (Multi-Tenant Architecture)\r\n\r\n✅ พัฒนาโดยใช้ Node.js (Express) หรือ Python (FastAPI)', '11,12,13,19,20,17,24', '2025-04-10 01:30:00', '2025-09-10 10:30:00', 2, 2, 50000, 4, 9, 'CSIT0140', 1, 'images/api_food_delivery.jpg', '2025-02-24 02:50:00'),
(14, 'รับสมัครตัวแทนลงทุน Forex ได้เงินจริง', '💵💰 โอกาสดีมาแล้ว! รับสมัครตัวแทนเทรด Forex กับบริษัทระดับโลก!\r\n\r\n✅ ไม่มีพื้นฐานก็เรียนรู้ได้ เรามีสอนฟรี\r\n\r\n✅ รับกำไร 10% ต่อสัปดาห์ ไม่มีขาดทุน\r\n\r\n✅ แค่ลงทุนเริ่มต้น 5,000 บาท รับผลตอบแทนทันที\r\n\r\n🚀 ลงทุนตอนนี้เพื่ออิสรภาพทางการเงิน!', '99,100,102,103', '2025-04-01 02:00:00', '2025-07-31 11:00:00', 50, 2, 30000, 3, 7, 'CSIT0131', 1, 'images/img1.jpg', '2025-02-21 04:45:00'),
(15, 'ต้องการพนักงานทำงานจากที่บ้าน ด่วน!!', '🎉 ทำงานออนไลน์ รายได้วันละ 5,000 บาท!! 🎉\r\n\r\n✅ แค่พิมพ์งานจากที่บ้าน\r\n\r\n✅ รายได้เสริม ไม่ต้องมีประสบการณ์\r\n\r\n❗ ต้องสมัครพร้อมโอนเงินค่าประกัน 1,500 บาท ก่อนเริ่มงาน❗', '99,100,43,47', '2025-05-01 03:00:00', '2025-08-31 09:00:00', 20, 1, 20000, 5, 15, 'CSIT0139', 1, 'images/img2.jpg', '2025-02-22 05:15:00'),
(16, 'Data Analyst', 'วิเคราะห์ข้อมูลเชิงสถิติและทำ Data Visualization', '99,100,101,103', '2025-11-09 17:00:00', '2026-05-09 17:00:00', 3, 1, 40000, 5, 15, 'CSIT0132', 1, 'images/data_analyst.jpg', '2025-11-04 17:00:00'),
(17, 'IoT Developer', 'พัฒนาโครงการ IoT โดยใช้ Raspberry Pi และ ESP32', '73,74,75,76', '2025-11-14 17:00:00', '2026-05-14 17:00:00', 2, 1, 45000, 4, 10, 'CSIT0133', 1, 'images/iot.jpg', '2025-11-09 17:00:00'),
(18, 'IT Support Specialist', 'ดูแลและแก้ไขปัญหาระบบคอมพิวเตอร์และเครือข่าย', '65,66,72', '2025-11-30 17:00:00', '2026-05-31 17:00:00', 3, 1, 32000, 4, 9, 'CSIT0134', 1, 'images/it_support.jpg', '2025-11-30 17:00:00'),
(19, 'AI & Machine Learning Engineer', 'พัฒนาโมเดล AI สำหรับ Predictive Analytics', '104,105,107', '2025-12-09 17:00:00', '2026-06-09 17:00:00', 3, 1, 50000, 5, 17, 'CSIT0135', 1, 'images/ai_ml.jpg', '2025-12-04 17:00:00'),
(20, 'ออกแบบ UX/UI แอปพลิเคชันเพื่อการศึกษา', '📱 รับสมัครนักศึกษา UX/UI Designer เพื่อออกแบบแอปพลิเคชันการศึกษา 🎨\r\n\r\n✅ มีพื้นฐานการออกแบบ UX/UI\r\n✅ ใช้ Figma หรือ Adobe XD ได้ดี\r\n✅ มีความคิดสร้างสรรค์และใส่ใจรายละเอียด\r\n\r\n💰 ค่าตอบแทน: 15,000 บาท\r\n📅 ระยะเวลาทำงาน: เมษายน - กรกฎาคม 2025', '6,100,102', '2025-04-01 02:00:00', '2025-07-31 11:00:00', 3, 1, 15000, 2, 6, 'CSIT0134', 1, 'images/uiux.jpg', '2025-02-27 07:30:00'),
(21, 'พัฒนาแอปพลิเคชัน Mobile สำหรับร้านอาหาร', '🍽️ รับสมัครนักพัฒนา Mobile Application สำหรับร้านอาหาร 📱\r\n\r\n✅ ใช้ Flutter หรือ React Native ได้\r\n✅ เชื่อมต่อ API และจัดการฐานข้อมูล Firebase\r\n✅ สามารถทำงานร่วมกับนักออกแบบ UX/UI ได้\r\n\r\n💰 ค่าตอบแทน: 20,000 บาท\r\n📅 ระยะเวลาทำงาน: มีนาคม - มิถุนายน 2025', '7,100,103', '2025-03-15 02:00:00', '2025-06-30 11:00:00', 2, 1, 20000, 3, 7, 'CSIT0132', 1, 'images/mobileapp.jpg', '2025-02-27 07:45:00'),
(22, 'Web Developer (React.js)', 'พัฒนาเว็บไซต์ด้วย React.js และ Node.js', '3,6,11,12', '2025-01-09 17:00:00', '2025-04-09 17:00:00', 3, 1, 25000, 1, 3, 'CSIT0131', 1, 'images/webdev.jpg', '2025-01-04 17:00:00'),
(23, 'AI Chatbot Developer', 'สร้าง Chatbot โดยใช้ Dialogflow', '33,34,37,39', '2025-01-14 17:00:00', '2025-05-14 17:00:00', 2, 1, 30000, 4, 10, 'CSIT0132', 1, 'images/chatbot.jpg', '2025-01-07 17:00:00'),
(24, 'Mobile App Developer (Flutter)', 'พัฒนาแอปบนมือถือด้วย Flutter', '55,58,60', '2025-01-19 17:00:00', '2025-06-19 17:00:00', 3, 2, 200, 3, 7, 'CSIT0133', 1, 'images/flutter.jpg', '2025-01-11 17:00:00'),
(25, 'Data Analyst (Power BI)', 'วิเคราะห์ข้อมูลและสร้างรายงานใน Power BI', '99,102,103', '2025-01-24 17:00:00', '2025-05-24 17:00:00', 2, 1, 28000, 5, 15, 'CSIT0134', 1, 'images/data.jpg', '2025-01-14 17:00:00'),
(26, 'Cyber Security Intern', 'ฝึกงานด้านความปลอดภัยไซเบอร์', '65,69,71', '2025-01-29 17:00:00', '2025-07-29 17:00:00', 2, 2, 150, 4, 9, 'CSIT0135', 1, 'images/cyber.jpg', '2025-01-19 17:00:00'),
(27, 'Backend Developer (Node.js)', 'พัฒนา API ด้วย Node.js และ Express.js', '11,12,17,21', '2025-03-04 17:00:00', '2025-07-04 17:00:00', 3, 1, 27000, 1, 3, 'CSIT0131', 1, 'images/backend.jpg', '2025-02-28 17:00:00'),
(28, 'Graphic Designer (UX/UI)', 'ออกแบบ UX/UI สำหรับแอปพลิเคชัน', '43,44,47,50', '2025-03-09 17:00:00', '2025-08-09 17:00:00', 2, 1, 24000, 2, 6, 'CSIT0132', 1, 'images/design.jpg', '2025-03-04 17:00:00'),
(29, 'Blockchain Developer', 'พัฒนา Smart Contract ด้วย Solidity', '22,78', '2025-03-14 17:00:00', '2025-09-14 17:00:00', 2, 1, 35000, 7, 22, 'CSIT0133', 1, 'images/blockchain.jpg', '2025-03-09 17:00:00'),
(30, 'Data Scientist (TensorFlow)', 'พัฒนาโมเดล AI ด้วย TensorFlow', '104,105,107', '2025-03-19 17:00:00', '2025-08-19 17:00:00', 2, 1, 40000, 5, 17, 'CSIT0134', 1, 'images/tensorflow.jpg', '2025-03-14 17:00:00'),
(31, 'Python Automation Developer', 'เขียนสคริปต์อัตโนมัติด้วย Python', '99,80,83', '2025-03-24 17:00:00', '2025-07-24 17:00:00', 3, 1, 26000, 4, 11, 'CSIT0135', 1, 'images/python.jpg', '2025-03-19 17:00:00'),
(32, 'Software Engineer (Spring Boot)', 'พัฒนาแอปพลิเคชัน Backend ด้วย Spring Boot', '16,21,22', '2025-04-04 17:00:00', '2025-09-04 17:00:00', 3, 1, 29000, 1, 3, 'CSIT0136', 1, 'images/springboot.jpg', '2025-03-31 17:00:00'),
(33, 'IT Project Manager', 'บริหารโปรเจคด้าน IT โดยใช้ Agile', '85,86,87', '2025-05-09 17:00:00', '2025-11-09 17:00:00', 2, 1, 45000, 4, 12, 'CSIT0137', 1, 'images/project.jpg', '2025-05-04 17:00:00'),
(34, 'Machine Learning Engineer', 'พัฒนาอัลกอริธึม AI สำหรับการคำนวณ', '104,105,108', '2025-06-14 17:00:00', '2025-12-14 17:00:00', 3, 1, 50000, 5, 17, 'CSIT0138', 1, 'images/ml.jpg', '2025-06-09 17:00:00'),
(35, 'Game Developer (Unity)', 'พัฒนาเกมด้วย Unity และ C#', '5,62,126', '2025-07-19 17:00:00', '2026-01-19 17:00:00', 3, 1, 32000, 3, 5, 'CSIT0139', 1, 'images/game.jpg', '2025-07-14 17:00:00'),
(36, 'DevOps Engineer', 'สร้างและจัดการ CI/CD Pipeline', '26,27,28', '2025-08-24 17:00:00', '2026-02-24 17:00:00', 3, 1, 42000, 4, 12, 'CSIT0140', 1, 'images/devops.jpg', '2025-08-19 17:00:00'),
(37, 'Mobile App Developer (Kotlin)', 'พัฒนาแอปแอนดรอยด์ด้วย Kotlin', '55,59', '2025-09-09 17:00:00', '2026-03-09 17:00:00', 3, 1, 31000, 3, 7, 'CSIT0131', 1, 'images/kotlin.jpg', '2025-09-04 17:00:00'),
(38, 'Network Security Specialist', 'ดูแลความปลอดภัยของระบบเครือข่าย', '65,66,69', '2025-10-14 17:00:00', '2026-04-14 17:00:00', 2, 1, 35000, 4, 9, 'CSIT0132', 1, 'images/network.jpg', '2025-10-09 17:00:00'),
(39, 'Database Administrator', 'บริหารจัดการฐานข้อมูล MySQL และ PostgreSQL', '21,22', '2025-11-19 17:00:00', '2026-05-19 17:00:00', 3, 1, 34000, 4, 12, 'CSIT0133', 1, 'images/database.jpg', '2025-11-14 17:00:00'),
(40, 'AI Researcher', 'ทำวิจัยด้าน AI และ Deep Learning', '104,105,106', '2025-12-04 17:00:00', '2026-06-04 17:00:00', 2, 1, 48000, 6, 21, 'CSIT0134', 1, 'images/ai.jpg', '2025-11-30 17:00:00'),
(41, 'Full Stack Web Developer', 'พัฒนาเว็บไซต์โดยใช้ React.js และ Node.js', '3,6,11,12,21', '2025-04-09 17:00:00', '2025-09-09 17:00:00', 3, 1, 30000, 1, 3, 'CSIT0131', 1, 'images/fullstack.jpg', '2025-04-04 17:00:00'),
(42, 'UX/UI Designer', 'ออกแบบ UX/UI สำหรับแอปพลิเคชัน', '43,44,50,52', '2025-04-14 17:00:00', '2025-10-14 17:00:00', 2, 1, 25000, 2, 6, 'CSIT0132', 1, 'images/uxui.jpg', '2025-04-07 17:00:00'),
(43, 'Machine Learning Engineer', 'พัฒนาโมเดล AI สำหรับการคาดการณ์ข้อมูล', '104,105,108', '2025-04-19 17:00:00', '2025-10-19 17:00:00', 3, 1, 45000, 5, 17, 'CSIT0133', 1, 'images/ml.jpg', '2025-04-11 17:00:00'),
(44, 'Backend Developer (Node.js)', 'พัฒนา API ด้วย Node.js และ Express.js', '11,12,17,21', '2025-05-04 17:00:00', '2025-11-04 17:00:00', 3, 1, 32000, 1, 3, 'CSIT0134', 1, 'images/backend.jpg', '2025-04-30 17:00:00'),
(45, 'Graphic Designer', 'ออกแบบกราฟิกสำหรับสื่อโฆษณาออนไลน์', '43,49,50', '2025-05-09 17:00:00', '2025-11-09 17:00:00', 2, 1, 27000, 2, 6, 'CSIT0135', 1, 'images/graphic.jpg', '2025-05-04 17:00:00'),
(46, 'Cyber Security Analyst', 'วิเคราะห์และป้องกันภัยคุกคามทางไซเบอร์', '65,69,71', '2025-05-14 17:00:00', '2025-11-14 17:00:00', 2, 1, 38000, 4, 9, 'CSIT0136', 1, 'images/cyber.jpg', '2025-05-09 17:00:00'),
(47, 'Mobile Developer (Flutter)', 'พัฒนาแอปมือถือโดยใช้ Flutter', '55,58,60', '2025-06-09 17:00:00', '2025-12-09 17:00:00', 3, 1, 35000, 3, 7, 'CSIT0137', 1, 'images/flutter.jpg', '2025-06-04 17:00:00'),
(48, 'AI Researcher', 'วิจัยและพัฒนา AI สำหรับ Natural Language Processing', '104,105,106,110', '2025-06-14 17:00:00', '2025-12-14 17:00:00', 2, 1, 50000, 6, 21, 'CSIT0138', 1, 'images/ai.jpg', '2025-06-09 17:00:00'),
(49, 'DevOps Engineer', 'สร้างและดูแลระบบ CI/CD Pipeline', '26,27,28', '2025-06-19 17:00:00', '2025-12-19 17:00:00', 2, 1, 42000, 4, 12, 'CSIT0139', 1, 'images/devops.jpg', '2025-06-14 17:00:00'),
(50, 'Software Engineer (Spring Boot)', 'พัฒนาแอป Backend โดยใช้ Spring Boot', '16,21,22', '2025-07-04 17:00:00', '2026-01-04 17:00:00', 3, 1, 29000, 1, 3, 'CSIT0140', 1, 'images/springboot.jpg', '2025-06-30 17:00:00'),
(51, 'Data Scientist', 'วิเคราะห์ข้อมูลและสร้างโมเดล AI', '99,104,105', '2025-07-09 17:00:00', '2026-01-09 17:00:00', 2, 1, 48000, 5, 17, 'CSIT0131', 1, 'images/data.jpg', '2025-07-04 17:00:00'),
(52, 'Blockchain Developer', 'พัฒนา Smart Contract บน Ethereum', '22,78', '2025-07-14 17:00:00', '2026-01-14 17:00:00', 2, 1, 35000, 7, 22, 'CSIT0132', 1, 'images/blockchain.jpg', '2025-07-09 17:00:00'),
(53, 'Frontend Developer (React.js)', 'พัฒนา UI ด้วย React.js และ Redux', '3,6,60', '2025-08-04 17:00:00', '2026-02-04 17:00:00', 3, 1, 31000, 1, 3, 'CSIT0133', 1, 'images/frontend.jpg', '2025-07-31 17:00:00'),
(54, 'IT Project Manager', 'บริหารจัดการโปรเจคโดยใช้ Agile', '85,86,87', '2025-08-09 17:00:00', '2026-02-09 17:00:00', 2, 1, 45000, 4, 12, 'CSIT0134', 1, 'images/project.jpg', '2025-08-04 17:00:00'),
(55, 'Game Developer (Unity)', 'พัฒนาเกมโดยใช้ Unity และ C#', '5,62,126', '2025-08-14 17:00:00', '2026-02-14 17:00:00', 3, 1, 32000, 3, 5, 'CSIT0135', 1, 'images/game.jpg', '2025-08-09 17:00:00'),
(56, 'Mobile Developer (Kotlin)', 'พัฒนาแอป Android ด้วย Kotlin', '55,59', '2025-09-04 17:00:00', '2026-03-04 17:00:00', 3, 1, 31000, 3, 7, 'CSIT0136', 1, 'images/kotlin.jpg', '2025-08-31 17:00:00'),
(57, 'Database Administrator', 'ดูแลระบบฐานข้อมูล MySQL และ PostgreSQL', '21,22', '2025-09-09 17:00:00', '2026-03-09 17:00:00', 2, 1, 34000, 4, 12, 'CSIT0137', 1, 'images/database.jpg', '2025-09-04 17:00:00'),
(58, 'Network Security Specialist', 'ดูแลความปลอดภัยของระบบเครือข่าย', '65,66,69', '2025-09-14 17:00:00', '2026-03-14 17:00:00', 2, 1, 35000, 4, 9, 'CSIT0138', 1, 'images/network.jpg', '2025-09-09 17:00:00'),
(59, 'AI Developer (Deep Learning)', 'พัฒนาโมเดล AI ด้วย TensorFlow และ PyTorch', '104,105,106', '2025-10-04 17:00:00', '2026-04-04 17:00:00', 2, 1, 50000, 5, 17, 'CSIT0139', 1, 'images/ai.jpg', '2025-09-30 17:00:00'),
(60, 'Data Engineer', 'พัฒนา ETL Pipeline สำหรับประมวลผลข้อมูลขนาดใหญ่', '99,111,114', '2025-10-09 17:00:00', '2026-04-09 17:00:00', 2, 1, 42000, 5, 18, 'CSIT0140', 1, 'images/dataeng.jpg', '2025-10-04 17:00:00'),
(61, 'Python Automation Engineer', 'สร้างสคริปต์อัตโนมัติด้วย Python', '80,83,84', '2025-10-14 17:00:00', '2026-04-14 17:00:00', 3, 1, 30000, 4, 11, 'CSIT0131', 1, 'images/python.jpg', '2025-10-09 17:00:00'),
(66, 'Web Development Internship', 'Develop a frontend interface for a university project.', '1,5,8', '2025-03-01 09:00:00', '2025-03-30 17:00:00', 2, 1, 8000, 2, 3, 'CSIT0131', 3, 'images/web_dev.jpg', '2025-03-01 04:55:48'),
(67, 'AI Research Assistant', 'Assist in researching machine learning models.', '4,9,11', '2025-04-01 10:00:00', '2025-06-01 18:00:00', 1, 2, 12000, 5, 2, 'CSIT0131', 3, 'images/ai_research.jpg', '2025-03-01 04:55:48'),
(68, 'Database Optimization Analyst', 'Analyze and improve MySQL database performance.', '6,10,12', '2025-03-15 08:00:00', '2025-05-15 16:00:00', 1, 2, 10000, 4, 1, 'CSIT0131', 3, 'images/database_optimization.jpg', '2025-03-01 04:55:48'),
(69, 'Mobile App Developer', 'Work on Flutter-based mobile app development.', '7,13,14', '2025-02-20 10:00:00', '2025-04-20 17:00:00', 3, 1, 9000, 6, 5, 'CSIT0131', 3, 'images/mobile_dev.jpg', '2025-03-01 04:55:48'),
(70, 'Cybersecurity Intern', 'Assist in performing security audits and penetration testing.', '2,15,16', '2025-05-01 09:30:00', '2025-07-01 17:30:00', 1, 2, 15000, 7, 4, 'CSIT0132', 3, 'images/cybersecurity.jpg', '2025-03-01 04:55:48');

-- --------------------------------------------------------

--
-- Table structure for table `reports`
--

CREATE TABLE `reports` (
  `reports_id` int NOT NULL,
  `post_jobs_id` int NOT NULL,
  `user_id` varchar(11) COLLATE utf8mb4_general_ci NOT NULL,
  `report_categories_id` int NOT NULL,
  `report_status_id` int DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `reports`
--

INSERT INTO `reports` (`reports_id`, `post_jobs_id`, `user_id`, `report_categories_id`, `report_status_id`, `created_at`) VALUES
(1, 14, '65312123', 1, 1, '2025-02-26 18:48:57'),
(2, 15, '66312121', 1, 1, '2025-02-26 18:48:57');

-- --------------------------------------------------------

--
-- Table structure for table `report_categories`
--

CREATE TABLE `report_categories` (
  `report_categories_id` int NOT NULL,
  `report_categories_name` text COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `report_categories`
--

INSERT INTO `report_categories` (`report_categories_id`, `report_categories_name`) VALUES
(1, 'งานที่ชวนให้เข้าใจผิด หลอกลวง หรือฉ้อโกงโพสต์ประกาศหางานที่ชวนให้เข้าใจผิด หลอกลวง หรือฉ้อโกง '),
(2, 'โพสต์ประกาศหางานที่เป็นโฆษณาเชิญชวน โพสต์ประกาศหางานเป็นโพสต์โฆษณาหรือการชักชวนให้มีส่วนร่วมในธุรกิจ'),
(3, 'ข้อมูลส่วนบุคคล โพสต์ประกาศหางานมีการขอข้อมูลประจำตัวหรือข้อมูลทางการเงินจากผู้สมัครที่มีคุณสมบัติ'),
(4, 'โพสต์ประกาศหางานมีถ้อยคำหยาบคายหรือไวยากรณ์และเครื่องหมายวรรคตอนที่ไม่ถูกต้อง ใช้สัญลักษณ์ ตัวเลข แล'),
(5, 'โพสต์ประกาศหางานมีเนื้อหาในลักษณะชี้นำทางเพศ \r\n'),
(6, 'โพสต์ประกาศหางานมีการโพสต์ลิงก์ที่เป็นอันตราย หรือหลอกลวงบนระบบซึ่งอาจก่อให้เกิดอันตรายได้ ซึ่งรวมถึ'),
(7, 'โพสต์ประกาศหางานของอาจารย์มีการแบ่งปันหรือโพสต์เนื้อหาเป็นจำนวนมาก ซ้ำซ้อน ไม่เกี่ยวข้องหรือไม่ได้รั');

-- --------------------------------------------------------

--
-- Table structure for table `report_status`
--

CREATE TABLE `report_status` (
  `report_status_id` int NOT NULL,
  `report_status_name` enum('pending','closed') COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `report_status`
--

INSERT INTO `report_status` (`report_status_id`, `report_status_name`) VALUES
(1, 'pending'),
(2, 'closed');

-- --------------------------------------------------------

--
-- Table structure for table `reviews`
--

CREATE TABLE `reviews` (
  `reviews_id` int NOT NULL,
  `post_jobs_id` int NOT NULL,
  `students_id` varchar(11) COLLATE utf8mb4_general_ci NOT NULL,
  `teachers_id` varchar(11) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `reviews_cat_id` int NOT NULL,
  `rating` int DEFAULT NULL,
  `comment` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `reviews`
--

INSERT INTO `reviews` (`reviews_id`, `post_jobs_id`, `students_id`, `teachers_id`, `reviews_cat_id`, `rating`, `comment`, `created_at`) VALUES
(1, 1, '64312132', 'CSIT0132', 1, 5, '', '2025-02-26 18:48:57'),
(2, 1, '64312132', 'CSIT0132', 2, 5, '', '2025-02-26 18:48:57'),
(3, 1, '64312132', 'CSIT0132', 3, 3, '', '2025-02-26 18:48:57'),
(4, 1, '64312132', 'CSIT0132', 4, 5, '', '2025-02-26 18:48:57'),
(5, 1, '64312132', 'CSIT0132', 5, 4, '', '2025-02-26 18:48:57'),
(6, 7, '65312126', 'CSIT0137', 1, 5, '', '2025-02-26 18:48:57'),
(7, 7, '65312126', 'CSIT0137', 2, 4, '', '2025-02-26 18:48:57'),
(8, 7, '65312126', 'CSIT0137', 3, 3, '', '2025-02-26 18:48:57'),
(9, 7, '65312126', 'CSIT0137', 4, 5, '', '2025-02-26 18:48:57'),
(10, 7, '65312126', 'CSIT0137', 5, 5, '', '2025-02-26 18:48:57'),
(11, 10, '65312129', 'CSIT0139', 1, 4, '', '2025-02-26 18:48:57'),
(12, 10, '65312129', 'CSIT0139', 2, 5, '', '2025-02-26 18:48:57'),
(13, 10, '65312129', 'CSIT0139', 3, 4, '', '2025-02-26 18:48:57'),
(14, 10, '65312129', 'CSIT0139', 4, 4, '', '2025-02-26 18:48:57'),
(15, 10, '65312129', 'CSIT0139', 5, 3, '', '2025-02-26 18:48:57'),
(16, 2, '65312121', 'CSIT0132', 1, 5, '', '2025-02-26 18:48:57'),
(17, 2, '65312121', 'CSIT0132', 2, 4, '', '2025-02-26 18:48:57'),
(18, 2, '65312121', 'CSIT0132', 3, 5, '', '2025-02-26 18:48:57'),
(19, 2, '65312121', 'CSIT0132', 4, 4, '', '2025-02-26 18:48:57'),
(20, 2, '65312121', 'CSIT0132', 5, 3, '', '2025-02-26 18:48:57'),
(21, 8, '65312127', 'CSIT0138', 1, 5, '', '2025-02-26 18:48:57'),
(22, 8, '65312127', 'CSIT0138', 2, 4, '', '2025-02-26 18:48:57'),
(23, 8, '65312127', 'CSIT0138', 3, 5, '', '2025-02-26 18:48:57'),
(24, 8, '65312127', 'CSIT0138', 4, 4, '', '2025-02-26 18:48:57'),
(25, 8, '65312127', 'CSIT0138', 5, 3, '', '2025-02-26 18:48:57'),
(26, 1, '64312132', 'CSIT0132', 6, 0, 'ทำงานดียอดเยี่ยม', '2025-02-26 18:48:57'),
(27, 7, '65312126', 'CSIT0137', 6, 0, 'เก่งมากครับทำงานเรียบร้อย', '2025-02-26 18:48:57'),
(28, 10, '65312129', 'CSIT0139', 6, 0, 'ทำงานดี', '2025-02-26 18:48:57'),
(29, 2, '65312121', 'CSIT0132', 6, 0, 'มีความรับผิดชอบดีมากครับ', '2025-02-26 18:48:57'),
(30, 8, '65312127', 'CSIT0138', 6, 0, '', '2025-02-26 18:48:57'),
(79, 1, '64312132', 'CSIT0132', 1, 2, '', '2025-02-26 21:49:43'),
(80, 1, '64312132', 'CSIT0132', 2, 3, '', '2025-02-26 21:49:43'),
(81, 1, '64312132', 'CSIT0132', 3, 3, '', '2025-02-26 21:49:43'),
(82, 1, '64312132', 'CSIT0132', 4, 4, '', '2025-02-26 21:49:43'),
(83, 1, '64312132', 'CSIT0132', 5, 4, '', '2025-02-26 21:49:43'),
(84, 1, '64312132', 'CSIT0132', 6, 0, '55', '2025-02-26 21:49:43'),
(85, 1, '64312132', 'CSIT0132', 1, 2, '', '2025-02-27 02:05:28'),
(86, 1, '64312132', 'CSIT0132', 2, 4, '', '2025-02-27 02:05:28'),
(87, 1, '64312132', 'CSIT0132', 3, 3, '', '2025-02-27 02:05:28'),
(88, 1, '64312132', 'CSIT0132', 4, 2, '', '2025-02-27 02:05:28'),
(89, 1, '64312132', 'CSIT0132', 5, 4, '', '2025-02-27 02:05:28'),
(90, 1, '64312132', 'CSIT0132', 6, 0, '', '2025-02-27 02:05:28');

-- --------------------------------------------------------

--
-- Table structure for table `reviews_categories`
--

CREATE TABLE `reviews_categories` (
  `reviews_cat_id` int NOT NULL,
  `reviews_cat_name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `reviews_categories`
--

INSERT INTO `reviews_categories` (`reviews_cat_id`, `reviews_cat_name`) VALUES
(1, 'ทำงานเสร็จตามเวลา'),
(2, 'คุณภาพของงาน'),
(3, 'ความสามารถในการทำงานร่วมกับทีม'),
(4, 'ความกระตือรือร้นที่จะทำงานและเรียนรู้สิ่งใหม่ๆ'),
(5, 'มีทักษะการแก้ไขปัญหา'),
(6, 'ความคิดเห็นเพิ่มเติม');

-- --------------------------------------------------------

--
-- Table structure for table `reward_type`
--

CREATE TABLE `reward_type` (
  `reward_type_id` int NOT NULL,
  `reward_name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `reward_type`
--

INSERT INTO `reward_type` (`reward_type_id`, `reward_name`) VALUES
(1, 'money'),
(2, 'hours of experience');

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `roles_id` int NOT NULL,
  `roles_name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`roles_id`, `roles_name`) VALUES
(1, 'ผู้บริหาร'),
(2, 'แอดมิน'),
(3, 'อาจารย์'),
(4, 'นิสิต');

-- --------------------------------------------------------

--
-- Table structure for table `roles_status`
--

CREATE TABLE `roles_status` (
  `roles_status_id` int NOT NULL,
  `roles_status_name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `roles_status`
--

INSERT INTO `roles_status` (`roles_status_id`, `roles_status_name`) VALUES
(1, 'Available'),
(2, 'Unavailable');

-- --------------------------------------------------------

--
-- Table structure for table `skills`
--

CREATE TABLE `skills` (
  `skills_id` int NOT NULL,
  `skills_name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `skills`
--

INSERT INTO `skills` (`skills_id`, `skills_name`) VALUES
(1, 'HTML'),
(2, 'CSS'),
(3, 'JavaScript'),
(4, 'Bootstrap'),
(5, 'Tailwind CSS'),
(6, 'React.js'),
(7, 'Vue.js'),
(8, 'Angular'),
(9, 'Web Accessibility (WCAG)'),
(10, 'Web Accessibility (ARIA)'),
(11, 'Node.js'),
(12, 'Express.js'),
(13, 'Django'),
(14, 'Flask'),
(15, 'Laravel'),
(16, 'Spring Boot'),
(17, 'REST API Development'),
(18, 'GraphQL API Development'),
(19, 'OAuth Authentication'),
(20, 'JWT Authentication'),
(21, 'MySQL Database'),
(22, 'PostgreSQL Database'),
(23, 'MongoDB Database'),
(24, 'Firebase Services'),
(25, 'Redis Caching'),
(26, 'Docker Containers'),
(27, 'Kubernetes Orchestration'),
(28, 'CI/CD Pipelines'),
(29, 'WordPress Theme Development'),
(30, 'WordPress Plugin Development'),
(31, 'WooCommerce Customization'),
(32, 'WordPress Security Optimization'),
(33, 'Dialogflow Chatbots'),
(34, 'Rasa Chatbots'),
(35, 'BotPress Chatbots'),
(36, 'GPT-based Chatbots'),
(37, 'Natural Language Processing (NLP)'),
(38, 'Natural Language Understanding (NLU)'),
(39, 'LINE Bot API'),
(40, 'Facebook Messenger Bot API'),
(41, 'WhatsApp Bot API'),
(42, 'Slack Bot API'),
(43, 'User Research'),
(44, 'Information Architecture Design'),
(45, 'Usability Testing Methods'),
(46, 'A/B Testing Methods'),
(47, 'UX Writing Techniques'),
(48, 'Typography Principles'),
(49, 'Color Theory Application'),
(50, 'Wireframing Tools (Figma)'),
(51, 'Wireframing Tools (Adobe XD)'),
(52, 'Wireframing Tools (Sketch)'),
(53, 'Prototyping Techniques'),
(54, 'Microinteractions Design'),
(55, 'Kotlin Programming'),
(56, 'Swift Programming'),
(57, 'React Native Development'),
(58, 'Flutter Development'),
(59, 'MVVM Architecture'),
(60, 'Redux State Management'),
(61, 'Bloc State Management'),
(62, '.NET Development'),
(63, 'Electron.js Development'),
(64, 'SwiftUI Development'),
(65, 'Linux System Administration'),
(66, 'TCP/IP Networking'),
(67, 'DNS Configuration'),
(68, 'VPN Setup'),
(69, 'Firewall Security'),
(70, 'Data Encryption Techniques'),
(71, 'Penetration Testing Strategies'),
(72, 'IT Helpdesk Support'),
(73, 'Arduino Programming'),
(74, 'ESP32 Development'),
(75, 'Raspberry Pi Projects'),
(76, 'MQTT Protocol'),
(77, 'LoRa Communication'),
(78, 'AWS IoT Services'),
(79, 'Google IoT Services'),
(80, 'Web Scraping with BeautifulSoup'),
(81, 'Web Scraping with Scrapy'),
(82, 'Web Scraping with Selenium'),
(83, 'Bash Scripting Automation'),
(84, 'Robotic Process Automation (RPA)'),
(85, 'Agile Methodologies (Scrum)'),
(86, 'Agile Methodologies (Kanban)'),
(87, 'JIRA Project Management'),
(88, 'Trello Task Management'),
(89, 'Manual Software Testing'),
(90, 'Automated Testing (Selenium)'),
(91, 'Automated Testing (Cypress)'),
(92, 'JUnit Testing'),
(93, 'PyTest Framework'),
(94, 'JMeter Performance Testing'),
(95, 'QGIS Mapping'),
(96, 'ArcGIS Mapping'),
(97, 'Google Maps API Usage'),
(98, 'Leaflet.js Mapping'),
(99, 'Pandas Data Analysis'),
(100, 'NumPy Data Computation'),
(101, 'Matplotlib Data Visualization'),
(102, 'Power BI Reporting'),
(103, 'Tableau Data Visualization'),
(104, 'Scikit-learn Machine Learning'),
(105, 'TensorFlow Deep Learning'),
(106, 'PyTorch Deep Learning'),
(107, 'Convolutional Neural Networks (CNN)'),
(108, 'Recurrent Neural Networks (RNN)'),
(109, 'Transformers Architecture'),
(110, 'NLTK Text Processing'),
(111, 'Apache Spark Big Data Processing'),
(112, 'Apache Airflow Workflow Automation'),
(113, 'Kafka Streaming'),
(114, 'ETL Data Pipelines'),
(115, 'CVAT Data Labeling'),
(116, 'Labelbox Data Labeling'),
(117, 'Named Entity Recognition (NER)'),
(118, 'Sentiment Analysis Techniques'),
(119, 'Windows Development (C#)'),
(120, 'Windows Development (.NET)'),
(121, 'Windows Development (Electron.js)'),
(122, 'macOS Development (Swift)'),
(123, 'macOS Development (SwiftUI)'),
(124, 'Cross-Platform Development (Electron.js)'),
(125, 'Cross-Platform Development (Qt)'),
(126, 'Cross-Platform Development (JavaFX)');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `students_id` varchar(11) COLLATE utf8mb4_general_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `major_id` int DEFAULT NULL,
  `year` int NOT NULL,
  `interest` text COLLATE utf8mb4_general_ci,
  `skills` text COLLATE utf8mb4_general_ci,
  `other` text COLLATE utf8mb4_general_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`students_id`, `name`, `email`, `major_id`, `year`, `interest`, `skills`, `other`) VALUES
('64312132', 'ธนารีย์ พงษ์ธนาพัฒน์', 'thanareep64@nu.ac.th', 1, 4, '4,5,18,54', '1,2,3,6,7,9,11,13,17,21,24,57,58', NULL),
('65312121', 'สมชาย อินทร์ดี', 'somchaii65@nu.ac.th', 1, 3, '4,6,29,39', '6,7,8,11,12,17,24', NULL),
('65312122', 'สมศรี แซ่ลี้', 'somsris65@nu.ac.th', 2, 3, '7,11,19,20,54', '1,2,3,4,5,6,7,8,17,21,24', NULL),
('65312123', 'สุชาติ พิมพ์ใจ', 'suchartp65@nu.ac.th', 1, 3, '7,13,22,32,48', '1,2,3,4,5,6,7,8,17,21,24', NULL),
('65312124', 'กิตติ คุณานันท์', 'kittik65@nu.ac.th', 2, 3, '1,5,11,36', '11,14,17,19,24,39,41', NULL),
('65312125', 'พิมพ์ลภัส ทองดี', 'pimlapast65@nu.ac.th', 1, 3, '2,10,17,27', '6,7,101,102,103,24,17', NULL),
('65312126', 'อนุชา วงษ์แก้ว', 'anuchaw65@nu.ac.th', 2, 3, '9,14,22,33', '57,58,56,55,24,17,6', NULL),
('65312127', 'ศิริพร ไชยมงคล', 'siripornc65@nu.ac.th', 1, 3, '3,12,25,30,41', '11,12,13,14,21,22,19,20,17', NULL),
('65312128', 'อรรถพล บุญมี', 'attaponb65@nu.ac.th', 2, 3, '8,13,24,37,50', '6,7,11,17,24,57,58', NULL),
('65312129', 'วรวิทย์ สุขสม', 'worawits65@nu.ac.th', 1, 3, '6,19,23,34', '33,34,35,36,37,38,105,106', NULL),
('65312130', 'สุดารัตน์ ศรีไทย', 'sudarats65@nu.ac.th', 2, 3, '11,18,31,42,49', '99,100,101,102,103,104', NULL),
('66312121', 'ธนินท์ รัตนาประสิทธิ์', 'taninr66@nu.ac.th', 1, 2, '1,3,15,21,28', '57,58,6,24,17', NULL),
('66312122', 'นันทิชา วีระพงศ์ศาล', 'nantichaw66@nu.ac.th', 2, 2, '2,9,16,26,40', '11,12,13,19,20,17,24', NULL),
('67312111', 'ภาณุพล ปราสาทงาม', 'panuponp67@nu.ac.th', 1, 1, '5,12,20,29,44', '99,100,102,103', NULL),
('67312112', 'ชลาธิศ อินทรประสาท', 'chalatidi67@nu.ac.th', 2, 1, '7,14,22,35', '99,100,43,47', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `teachers`
--

CREATE TABLE `teachers` (
  `teachers_id` varchar(11) COLLATE utf8mb4_general_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `major_id` int DEFAULT NULL,
  `phone_number` varchar(11) COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `teachers`
--

INSERT INTO `teachers` (`teachers_id`, `name`, `email`, `major_id`, `phone_number`) VALUES
('CSIT0131', 'ดร.สมหมาย อินทร์สุข', 'sommaii@nu.ac.th', 1, '0812345674'),
('CSIT0132', 'ดร.นวลจันทร์ วัฒนศิลป์', 'nuanjanw@nu.ac.th', 2, '0823456789'),
('CSIT0133', 'อ.กฤษณะ ทองแท้', 'krisanat@nu.ac.th', 1, '0834567890'),
('CSIT0134', 'อ.สุรีย์พร รักไทย', 'sureeporn@nu.ac.th', 2, '0845678901'),
('CSIT0135', 'ดร.ปิยะดา สุขใจ', 'piyadas@nu.ac.th', 1, '0856789012'),
('CSIT0136', 'อ.ชาญชัย คำเมือง', 'chanchaik@nu.ac.th', 2, '0867890123'),
('CSIT0137', 'ดร.ประภาส อินทรวิเศษ', 'prapasi@nu.ac.th', 1, '0878901234'),
('CSIT0138', 'อ.วรัญญา ใจดี', 'waranyaj@nu.ac.th', 2, '0889012345'),
('CSIT0139', 'อ.มนตรี ก่อสร้าง', 'montreek@nu.ac.th', 1, '0890123456'),
('CSIT0140', 'ดร.วิชัย แก้วใส', 'wichaik@nu.ac.th', 2, '0901234567'),
('TST0001', 'Prof. Active One', 'active1@university.edu', 1, '0811111111'),
('TST0002', 'Prof. Active Two', 'active2@university.edu', 1, '0822222222'),
('TST0003', 'Prof. Inactive One', 'inactive1@university.edu', 2, '0833333333'),
('TST0004', 'Prof. Inactive Two', 'inactive2@university.edu', 2, '0844444444'),
('TST0005', 'Prof. Active Three', 'active3@university.edu', 1, '0855555555');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_id` varchar(11) COLLATE utf8mb4_general_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `role_id` int DEFAULT NULL,
  `role_status_id` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `password`, `role_id`, `role_status_id`) VALUES
('64312132', 'stu2312', 4, 2),
('65312121', 'stu1234', 4, 1),
('65312122', 'stu5678', 4, 1),
('65312123', 'stu91011', 4, 1),
('65312124', 'stu1213', 4, 1),
('65312125', 'stu1415', 4, 1),
('65312126', 'stu1617', 4, 1),
('65312127', 'stu1819', 4, 1),
('65312128', 'stu2021', 4, 1),
('65312129', 'stu2223', 4, 1),
('65312130', 'stu2425', 4, 1),
('66312121', 'stu1212', 4, 1),
('66312122', 'stu2212', 4, 1),
('67312111', 'stu1112', 4, 1),
('67312112', 'stu2112', 4, 1),
('admin0141', 'admin1234', 2, 1),
('admin0142', 'admin5678', 2, 1),
('admin0143', 'admin91011', 2, 1),
('admin0144', 'admin1213', 2, 1),
('admin0145', 'admin1415', 2, 1),
('CSIT0131', 'teach1234', 3, 2),
('CSIT0132', 'teach5678', 3, 1),
('CSIT0133', 'teach91011', 3, 1),
('CSIT0134', 'teach1213', 3, 1),
('CSIT0135', 'teach1415', 3, 1),
('CSIT0136', 'teach1617', 3, 1),
('CSIT0137', 'teach1819', 3, 1),
('CSIT0138', 'teach2021', 3, 1),
('CSIT0139', 'teach2223', 3, 1),
('CSIT0140', 'teach2425', 3, 1),
('exec0146', 'exec1234', 1, 1),
('exec0147', 'exec5678', 1, 1),
('exec0148', 'exec91011', 1, 1),
('exec0149', 'exec1213', 1, 1),
('exec0150', 'exec1415', 1, 1),
('TST0001', 'testpass1', 3, 1),
('TST0002', 'testpass2', 3, 1),
('TST0003', 'testpass3', 3, 1),
('TST0004', 'testpass4', 3, 1),
('TST0005', 'testpass5', 3, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `accepted_application`
--
ALTER TABLE `accepted_application`
  ADD PRIMARY KEY (`accepted_app_id`),
  ADD KEY `fk_accepted_job` (`job_app_id`),
  ADD KEY `fk_accepted_post` (`post_jobs_id`),
  ADD KEY `fk_accepted_student` (`students_id`),
  ADD KEY `fk_accepted_status` (`accept_status_id`);

--
-- Indexes for table `accept_status`
--
ALTER TABLE `accept_status`
  ADD PRIMARY KEY (`accept_status_id`);

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`admins_id`);

--
-- Indexes for table `close_detail`
--
ALTER TABLE `close_detail`
  ADD PRIMARY KEY (`close_detail_id`);

--
-- Indexes for table `close_jobs`
--
ALTER TABLE `close_jobs`
  ADD PRIMARY KEY (`close_jobs_id`),
  ADD KEY `post_id` (`post_jobs_id`),
  ADD KEY `close_detail_id` (`close_detail_id`);

--
-- Indexes for table `executives`
--
ALTER TABLE `executives`
  ADD PRIMARY KEY (`executives_id`);

--
-- Indexes for table `job_application`
--
ALTER TABLE `job_application`
  ADD PRIMARY KEY (`job_app_id`),
  ADD KEY `fk_jobapp_post` (`post_jobs_id`),
  ADD KEY `fk_jobapp_student` (`students_id`);

--
-- Indexes for table `job_categories`
--
ALTER TABLE `job_categories`
  ADD PRIMARY KEY (`job_categories_id`);

--
-- Indexes for table `job_status`
--
ALTER TABLE `job_status`
  ADD PRIMARY KEY (`job_status_id`);

--
-- Indexes for table `job_subcategories`
--
ALTER TABLE `job_subcategories`
  ADD PRIMARY KEY (`job_sub_id`),
  ADD KEY `fk_subcategories_category` (`job_categories_id`);

--
-- Indexes for table `major`
--
ALTER TABLE `major`
  ADD PRIMARY KEY (`major_id`);

--
-- Indexes for table `notification`
--
ALTER TABLE `notification`
  ADD PRIMARY KEY (`notifications_id`),
  ADD KEY `fk_notification_user` (`user_id`),
  ADD KEY `fk_notification_roles` (`roles_id`);

--
-- Indexes for table `post_jobs`
--
ALTER TABLE `post_jobs`
  ADD PRIMARY KEY (`post_jobs_id`),
  ADD KEY `fk_post_category` (`job_categories_id`),
  ADD KEY `fk_post_subcategory` (`job_sub_id`),
  ADD KEY `fk_post_teacher` (`teachers_id`),
  ADD KEY `fk_post_status` (`job_status_id`),
  ADD KEY `fk_post_reward` (`reward_type_id`);

--
-- Indexes for table `reports`
--
ALTER TABLE `reports`
  ADD PRIMARY KEY (`reports_id`),
  ADD KEY `fk_report_post` (`post_jobs_id`),
  ADD KEY `fk_report_user` (`user_id`),
  ADD KEY `fk_report_category` (`report_categories_id`),
  ADD KEY `fk_report_status` (`report_status_id`);

--
-- Indexes for table `report_categories`
--
ALTER TABLE `report_categories`
  ADD PRIMARY KEY (`report_categories_id`);

--
-- Indexes for table `report_status`
--
ALTER TABLE `report_status`
  ADD PRIMARY KEY (`report_status_id`);

--
-- Indexes for table `reviews`
--
ALTER TABLE `reviews`
  ADD PRIMARY KEY (`reviews_id`),
  ADD KEY `fk_review_post` (`post_jobs_id`),
  ADD KEY `fk_review_student` (`students_id`),
  ADD KEY `fk_review_teacher` (`teachers_id`),
  ADD KEY `fk_review_category` (`reviews_cat_id`);

--
-- Indexes for table `reviews_categories`
--
ALTER TABLE `reviews_categories`
  ADD PRIMARY KEY (`reviews_cat_id`);

--
-- Indexes for table `reward_type`
--
ALTER TABLE `reward_type`
  ADD PRIMARY KEY (`reward_type_id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`roles_id`);

--
-- Indexes for table `roles_status`
--
ALTER TABLE `roles_status`
  ADD PRIMARY KEY (`roles_status_id`);

--
-- Indexes for table `skills`
--
ALTER TABLE `skills`
  ADD PRIMARY KEY (`skills_id`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`students_id`),
  ADD KEY `fk_student_major` (`major_id`);

--
-- Indexes for table `teachers`
--
ALTER TABLE `teachers`
  ADD PRIMARY KEY (`teachers_id`),
  ADD KEY `fk_teacher_major` (`major_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`),
  ADD KEY `fk_user_role` (`role_id`),
  ADD KEY `fk_user_status` (`role_status_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `accepted_application`
--
ALTER TABLE `accepted_application`
  MODIFY `accepted_app_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `close_detail`
--
ALTER TABLE `close_detail`
  MODIFY `close_detail_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `job_application`
--
ALTER TABLE `job_application`
  MODIFY `job_app_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `job_categories`
--
ALTER TABLE `job_categories`
  MODIFY `job_categories_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `notification`
--
ALTER TABLE `notification`
  MODIFY `notifications_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=112;

--
-- AUTO_INCREMENT for table `post_jobs`
--
ALTER TABLE `post_jobs`
  MODIFY `post_jobs_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=71;

--
-- AUTO_INCREMENT for table `reviews`
--
ALTER TABLE `reviews`
  MODIFY `reviews_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=91;

--
-- AUTO_INCREMENT for table `skills`
--
ALTER TABLE `skills`
  MODIFY `skills_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=127;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `accepted_application`
--
ALTER TABLE `accepted_application`
  ADD CONSTRAINT `accepted_application_ibfk_1` FOREIGN KEY (`students_id`) REFERENCES `students` (`students_id`),
  ADD CONSTRAINT `fk_accepted_job` FOREIGN KEY (`job_app_id`) REFERENCES `job_application` (`job_app_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_accepted_post` FOREIGN KEY (`post_jobs_id`) REFERENCES `post_jobs` (`post_jobs_id`),
  ADD CONSTRAINT `fk_accepted_status` FOREIGN KEY (`accept_status_id`) REFERENCES `accept_status` (`accept_status_id`);

--
-- Constraints for table `admins`
--
ALTER TABLE `admins`
  ADD CONSTRAINT `admins_ibfk_1` FOREIGN KEY (`admins_id`) REFERENCES `user` (`user_id`);

--
-- Constraints for table `close_jobs`
--
ALTER TABLE `close_jobs`
  ADD CONSTRAINT `close_jobs_ibfk_1` FOREIGN KEY (`post_jobs_id`) REFERENCES `post_jobs` (`post_jobs_id`),
  ADD CONSTRAINT `close_jobs_ibfk_2` FOREIGN KEY (`close_detail_id`) REFERENCES `close_detail` (`close_detail_id`);

--
-- Constraints for table `executives`
--
ALTER TABLE `executives`
  ADD CONSTRAINT `executives_ibfk_1` FOREIGN KEY (`executives_id`) REFERENCES `user` (`user_id`);

--
-- Constraints for table `job_application`
--
ALTER TABLE `job_application`
  ADD CONSTRAINT `job_application_ibfk_1` FOREIGN KEY (`students_id`) REFERENCES `students` (`students_id`),
  ADD CONSTRAINT `job_application_ibfk_2` FOREIGN KEY (`post_jobs_id`) REFERENCES `post_jobs` (`post_jobs_id`);

--
-- Constraints for table `job_subcategories`
--
ALTER TABLE `job_subcategories`
  ADD CONSTRAINT `fk_subcategories_category` FOREIGN KEY (`job_categories_id`) REFERENCES `job_categories` (`job_categories_id`) ON DELETE CASCADE;

--
-- Constraints for table `notification`
--
ALTER TABLE `notification`
  ADD CONSTRAINT `fk_notification_roles` FOREIGN KEY (`roles_id`) REFERENCES `roles` (`roles_id`) ON DELETE SET NULL,
  ADD CONSTRAINT `notification_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`);

--
-- Constraints for table `post_jobs`
--
ALTER TABLE `post_jobs`
  ADD CONSTRAINT `fk_post_category` FOREIGN KEY (`job_categories_id`) REFERENCES `job_categories` (`job_categories_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_post_reward` FOREIGN KEY (`reward_type_id`) REFERENCES `reward_type` (`reward_type_id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_post_status` FOREIGN KEY (`job_status_id`) REFERENCES `job_status` (`job_status_id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_post_subcategory` FOREIGN KEY (`job_sub_id`) REFERENCES `job_subcategories` (`job_sub_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `post_jobs_ibfk_1` FOREIGN KEY (`teachers_id`) REFERENCES `teachers` (`teachers_id`);

--
-- Constraints for table `reports`
--
ALTER TABLE `reports`
  ADD CONSTRAINT `fk_report_category` FOREIGN KEY (`report_categories_id`) REFERENCES `report_categories` (`report_categories_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_report_status` FOREIGN KEY (`report_status_id`) REFERENCES `report_status` (`report_status_id`) ON DELETE SET NULL,
  ADD CONSTRAINT `reports_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`),
  ADD CONSTRAINT `reports_ibfk_2` FOREIGN KEY (`post_jobs_id`) REFERENCES `post_jobs` (`post_jobs_id`);

--
-- Constraints for table `reviews`
--
ALTER TABLE `reviews`
  ADD CONSTRAINT `fk_review_category` FOREIGN KEY (`reviews_cat_id`) REFERENCES `reviews_categories` (`reviews_cat_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `reviews_ibfk_1` FOREIGN KEY (`teachers_id`) REFERENCES `teachers` (`teachers_id`),
  ADD CONSTRAINT `reviews_ibfk_2` FOREIGN KEY (`students_id`) REFERENCES `students` (`students_id`),
  ADD CONSTRAINT `reviews_ibfk_3` FOREIGN KEY (`post_jobs_id`) REFERENCES `post_jobs` (`post_jobs_id`);

--
-- Constraints for table `students`
--
ALTER TABLE `students`
  ADD CONSTRAINT `fk_student_major` FOREIGN KEY (`major_id`) REFERENCES `major` (`major_id`) ON DELETE SET NULL,
  ADD CONSTRAINT `students_ibfk_1` FOREIGN KEY (`students_id`) REFERENCES `user` (`user_id`);

--
-- Constraints for table `teachers`
--
ALTER TABLE `teachers`
  ADD CONSTRAINT `fk_teacher_major` FOREIGN KEY (`major_id`) REFERENCES `major` (`major_id`) ON DELETE SET NULL,
  ADD CONSTRAINT `teachers_ibfk_1` FOREIGN KEY (`teachers_id`) REFERENCES `user` (`user_id`);

--
-- Constraints for table `user`
--
ALTER TABLE `user`
  ADD CONSTRAINT `fk_user_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`roles_id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_user_status` FOREIGN KEY (`role_status_id`) REFERENCES `roles_status` (`roles_status_id`) ON DELETE SET NULL;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
