const chartInstances = {};
const profAnalyticsChartFilters = {
    activeProfs: {},
    jobPosts: {},
    topPaidJobPosts: {},
    profRating: {}
};

// รอให้โหลด global filter controls (filter.html) และตัวเลือกฟิลเตอร์อื่นๆ ก่อน
document.addEventListener("DOMContentLoaded", function () {
    Promise.all([
        loadFilterSection(),  // โหลด global filters จาก filter.html
        loadCategoryOptions(),
        loadStatusOptions(),
        loadRewardOptions(),
        loadTeacherOptions(),
        loadMajorOptions(),
        loadYearOptions(),
        loadGenderOptions(),
        loadSkillOptions(),
        loadSubcategoryOptions(),
        loadHobbyOptions(),
        loadTopPaidJobPostsCategoryOptions()
    ]).then(() => {
        // Set up event listeners for dependent dropdowns
        setupDependentDropdowns();
        loadProfessorAnalytics();
    }).catch(err => {
        console.error("Error loading filter options:", err);
        loadProfessorAnalytics();
    });
});

function setupDependentDropdowns() {
    // When category changes, update subcategory
    const categorySelect = document.getElementById("category");
    if (categorySelect) {
        categorySelect.addEventListener('change', function() {
            loadSubcategoryOptions(this.value);
        });
    }
    
    // When mainSkill changes, update subskill
    const mainSkillSelect = document.getElementById("mainSkill");
    if (mainSkillSelect) {
        mainSkillSelect.addEventListener('change', function() {
            loadSubskillOptions(this.value);
        });
    }
    
    // When hobby changes, update subhobby
    const hobbySelect = document.getElementById("hobby");
    if (hobbySelect) {
        hobbySelect.addEventListener('change', function() {
            loadSubhobbyOptions(this.value);
        });
    }
}

async function loadFilterSection() {
    try {
        const response = await fetch('filter.html');
        if (!response.ok) throw new Error('Failed to load filter section');
        const filterHTML = await response.text();
        document.getElementById('filter-placeholder').innerHTML = filterHTML;
        // reinitialize collapse elements
        document.querySelectorAll('.collapse').forEach(el => new bootstrap.Collapse(el, { toggle: false }));
    } catch (error) {
        console.error('Error loading filter section:', error);
    }
}

function loadCategoryOptions() {
    return fetch("api/api.php?endpoint=categories-list")
        .then(res => res.json())
        .then(data => {
            // Global filter (id="category")
            const categorySelect = document.getElementById("category");
            if (categorySelect) {
                categorySelect.innerHTML = '<option value="">All</option>';
                data.forEach(item => {
                    const opt = document.createElement("option");
                    opt.value = item.job_category_id;
                    opt.textContent = item.job_category_name;
                    categorySelect.appendChild(opt);
                });
            }
            // For individual filters (selects ที่มี id ลงท้ายด้วย _category)
            document.querySelectorAll("select[id$='_category']").forEach(select => {
                select.innerHTML = '<option value="">All</option>';
                data.forEach(item => {
                    const opt = document.createElement("option");
                    opt.value = item.job_category_id;
                    opt.textContent = item.job_category_name;
                    select.appendChild(opt);
                });
            });
        });
}

function loadStatusOptions() {
    return fetch("api/api.php?endpoint=status-list")
        .then(res => res.json())
        .then(data => {
            const statusSelect = document.getElementById("status");
            if (statusSelect) {
                statusSelect.innerHTML = '<option value="">All</option>';
                data.forEach(item => {
                    const opt = document.createElement("option");
                    opt.value = item.job_status_id;
                    opt.textContent = item.job_status_name;
                    statusSelect.appendChild(opt);
                });
            }
            document.querySelectorAll("select[id$='_status']").forEach(select => {
                select.innerHTML = '<option value="">All</option>';
                data.forEach(item => {
                    const opt = document.createElement("option");
                    opt.value = item.job_status_id;
                    opt.textContent = item.job_status_name;
                    select.appendChild(opt);
                });
            });
        });
}

function loadRewardOptions() {
    return fetch("api/api.php?endpoint=reward-list")
        .then(res => res.json())
        .then(data => {
            const rewardSelect = document.getElementById("reward");
            if (rewardSelect) {
                rewardSelect.innerHTML = '<option value="">All</option>';
                data.forEach(item => {
                    const opt = document.createElement("option");
                    opt.value = item.reward_type_id;
                    opt.textContent = item.reward_type_name;
                    rewardSelect.appendChild(opt);
                });
            }
            document.querySelectorAll("select[id$='_reward']").forEach(select => {
                select.innerHTML = '<option value="">All</option>';
                data.forEach(item => {
                    const opt = document.createElement("option");
                    opt.value = item.reward_type_id;
                    opt.textContent = item.reward_type_name;
                    select.appendChild(opt);
                });
            });
        });
}

function loadTeacherOptions() {
    return fetch("api/api.php?endpoint=teacher-list")
        .then(res => res.json())
        .then(data => {
            const teacherSelect = document.getElementById("teacher");
            if (teacherSelect) {
                teacherSelect.innerHTML = '<option value="">All</option>';
                data.forEach(item => {
                    const opt = document.createElement("option");
                    opt.value = item.teacher_id;
                    opt.textContent = item.teach_name;
                    teacherSelect.appendChild(opt);
                });
            }
            document.querySelectorAll("select[id$='_teacher']").forEach(select => {
                select.innerHTML = '<option value="">All</option>';
                data.forEach(item => {
                    const opt = document.createElement("option");
                    opt.value = item.teacher_id;
                    opt.textContent = item.teach_name;
                    select.appendChild(opt);
                });
            });
        });
}

function loadMajorOptions() {
    return fetch("api/api.php?endpoint=major-list")
        .then(res => res.json())
        .then(data => {
            // เติมข้อมูลลงใน select ทั้ง major และ professorMajor
            const majorSelects = [
                document.getElementById("major"),
                document.getElementById("professorMajor")
            ];
            
            majorSelects.forEach(select => {
                if (select) {
                    select.innerHTML = '<option value="">All</option>';
                    data.forEach(item => {
                        const opt = document.createElement("option");
                        opt.value = item.major_id;
                        opt.textContent = item.major_name;
                        select.appendChild(opt);
                    });
                }
            });
        });
}

function loadYearOptions() {
    return fetch("api/api.php?endpoint=year-list")
        .then(res => res.json())
        .then(data => {
            const yearSelect = document.getElementById("year");
            if (yearSelect) {
                yearSelect.innerHTML = '<option value="">All</option>';
                data.forEach(item => {
                    const opt = document.createElement("option");
                    opt.value = item.year;
                    opt.textContent = item.year;
                    yearSelect.appendChild(opt);
                });
            }
        });
}

function loadGenderOptions() {
    return fetch("api/api.php?endpoint=gender-list")
        .then(res => res.json())
        .then(data => {
            const genderSelects = [
                document.getElementById("gender"),
                document.getElementById("teacherGender")
            ];
            
            genderSelects.forEach(select => {
                if (select) {
                    select.innerHTML = '<option value="">All</option>';
                    data.forEach(item => {
                        const opt = document.createElement("option");
                        opt.value = item.gender_id;
                        opt.textContent = item.gender_name;
                        select.appendChild(opt);
                    });
                }
            });
        });
}

function loadSkillOptions() {
    return fetch("api/api.php?endpoint=skill-list")
        .then(res => res.json())
        .then(data => {
            const skillSelects = [
                document.getElementById("skillFilter"),
                document.getElementById("mainSkill")
            ];
            
            skillSelects.forEach(select => {
                if (select) {
                    select.innerHTML = '<option value="">All</option>';
                    data.forEach(item => {
                        const opt = document.createElement("option");
                        opt.value = item.skill_id;
                        opt.textContent = item.skill_name;
                        select.appendChild(opt);
                    });
                }
            });
        });
}

function loadSubcategoryOptions(categoryId) {
    let url = "api/api.php?endpoint=subcategory-list";
    if (categoryId) {
        url += `&category=${categoryId}`;
    }
    
    return fetch(url)
        .then(res => res.json())
        .then(data => {
            const subcategorySelect = document.getElementById("subcategory");
            if (subcategorySelect) {
                subcategorySelect.innerHTML = '<option value="">All</option>';
                data.forEach(item => {
                    const opt = document.createElement("option");
                    opt.value = item.job_subcategory_id;
                    opt.textContent = item.job_subcategory_name;
                    subcategorySelect.appendChild(opt);
                });
            }
        });
}

function loadSubskillOptions(skillId) {
    let url = "api/api.php?endpoint=subskill-list";
    if (skillId) {
        url += `&skill=${skillId}`;
    }
    
    return fetch(url)
        .then(res => res.json())
        .then(data => {
            const subskillSelect = document.getElementById("subSkill");
            if (subskillSelect) {
                subskillSelect.innerHTML = '<option value="">All</option>';
                data.forEach(item => {
                    const opt = document.createElement("option");
                    opt.value = item.subskill_id;
                    opt.textContent = item.subskill_name;
                    select.appendChild(opt);
                });
            }
        });
}

function loadHobbyOptions() {
    return fetch("api/api.php?endpoint=hobby-list")
        .then(res => res.json())
        .then(data => {
            const hobbySelect = document.getElementById("hobby");
            if (hobbySelect) {
                hobbySelect.innerHTML = '<option value="">All</option>';
                data.forEach(item => {
                    const opt = document.createElement("option");
                    opt.value = item.hobby_id;
                    opt.textContent = item.hobby_name;
                    hobbySelect.appendChild(opt);
                });
            }
        });
}

function loadSubhobbyOptions(hobbyId) {
    let url = "api/api.php?endpoint=subhobby-list";
    if (hobbyId) {
        url += `&hobby=${hobbyId}`;
    }
    
    return fetch(url)
        .then(res => res.json())
        .then(data => {
            const subhobbySelect = document.getElementById("subHobby");
            if (subhobbySelect) {
                subhobbySelect.innerHTML = '<option value="">All</option>';
                data.forEach(item => {
                    const opt = document.createElement("option");
                    opt.value = item.subhobby_id;
                    opt.textContent = item.subhobby_name;
                    subhobbySelect.appendChild(opt);
                });
            }
        });
}

function getFilterValues() {
    const container = document.getElementById('filter-placeholder');
    const filters = {
        start: container.querySelector('#startDate')?.value || '',
        end: container.querySelector('#endDate')?.value || '',
        category: container.querySelector('#category')?.value || '',
        status: container.querySelector('#status')?.value || '',
        reward: container.querySelector('#reward')?.value || '',
        teacher: container.querySelector('#teacher')?.value || '',
        major: container.querySelector('#major')?.value || '',
        year: container.querySelector('#year')?.value || '',
        gender: container.querySelector('#gender')?.value || '',
        subcategory: container.querySelector('#subcategory')?.value || '',
        mainSkill: container.querySelector('#mainSkill')?.value || '',
        subSkill: container.querySelector('#subSkill')?.value || '',
        hobby: container.querySelector('#hobby')?.value || '',
        subHobby: container.querySelector('#subHobby')?.value || ''
    };
    console.log("Current filter values:", filters);
    return filters;
}

function buildParams(endpoint, filters) {
    const p = new URLSearchParams({ endpoint });
    
    // Add all possible filters
    if (filters.start) p.set('start', filters.start);
    if (filters.end) p.set('end', filters.end);
    if (filters.category) p.set('category', filters.category);
    if (filters.status) p.set('status', filters.status);
    if (filters.reward) p.set('reward', filters.reward);
    if (filters.teacher) p.set('teacher', filters.teacher);
    if (filters.major) p.set('major', filters.major);
    if (filters.year) p.set('year', filters.year);
    if (filters.gender) p.set('gender', filters.gender);
    if (filters.subcategory) p.set('subcategory', filters.subcategory);
    if (filters.mainSkill) p.set('skill', filters.mainSkill);
    if (filters.subSkill) p.set('subskill', filters.subSkill);
    if (filters.hobby) p.set('hobby', filters.hobby);
    if (filters.subHobby) p.set('subhobby', filters.subHobby);

    console.log("Built parameters:", p.toString());
    return p;
}

// ดึงค่าฟิลเตอร์สำหรับแต่ละกราฟใน profanaly
function getProfFilters(chartId) {
    const filters = {};
    const prefix = chartId + '_';
    const start = document.getElementById(prefix + 'startDate');
    if (start) filters.start = start.value || '';
    const end = document.getElementById(prefix + 'endDate');
    if (end) filters.end = end.value || '';
    const category = document.getElementById(prefix + 'category');
    if (category) filters.category = category.value || '';
    const status = document.getElementById(prefix + 'status');
    if (status) filters.status = status.value || '';
    const reward = document.getElementById(prefix + 'reward');
    if (reward) filters.reward = reward.value || '';
    const teacher = document.getElementById(prefix + 'teacher');
    if (teacher) filters.teacher = teacher.value || '';
    const major = document.getElementById(prefix + 'major');
    if (major) filters.major = major.value || '';
    const year = document.getElementById(prefix + 'year');
    if (year) filters.year = year.value || '';
    const gender = document.getElementById(prefix + 'gender');
    if (gender) filters.gender = gender.value || '';
    const mainSkill = document.getElementById(prefix + 'mainSkill');
    if (mainSkill) filters.mainSkill = mainSkill.value || '';
    const subSkill = document.getElementById(prefix + 'subSkill');
    if (subSkill) filters.subSkill = subSkill.value || '';
    
    return filters;
}

function applyFilterToProfAnalytics(chartId) {
    const filters = getProfFilters(chartId);
    profAnalyticsChartFilters[chartId] = { ...filters };
    switch (chartId) {
        case 'activeProfs':
            loadActiveProfessorsChart(filters);
            break;
        case 'jobPosts':
            loadJobPostsChart(filters);
            break;
        case 'topPaidJobPosts':
            loadTopPaidJobPostsChart(filters);
            break;
        case 'profRating':
            loadProfessorRatingChart(filters);
            break;
        default:
            console.warn("Unknown chart ID: " + chartId);
    }
}

function resetFilterForProfAnalytics(chartId) {
    const prefix = chartId + '_';
    document.querySelectorAll(`select[id^="${prefix}"]`).forEach(el => el.value = '');
    document.querySelectorAll(`input[type="date"][id^="${prefix}"]`).forEach(el => el.value = '');
    applyFilterToProfAnalytics(chartId);
}

// โหลดข้อมูลกราฟ (UPDATED)
function loadActiveProfessorsChart(filters = {}) {
    const globalFilters = getFilterValues();
    const merged = { ...globalFilters, ...filters };
    // Updated: Using new buildParams that accepts a filters object
    let paramsActive = buildParams("active-professors", merged);
    fetch("api/api.php?" + paramsActive.toString())
        .then(res => res.json())
        .then(data => {
            if (data && data[0]) {
                const total = Number(data[0].total_professors);
                const active = Number(data[0].active_professors);
                const inactive = total - active;
                document.getElementById("activeProfessors").textContent = active;
                renderBarChart("activeProfsChart", ["กำลังทำงาน", "ไม่ได้ทำงาน"], [active, inactive], "อาจารย์ตามสถานะการทำงาน", "#FF6B00");
            }
        })
        .catch(err => console.error("Error fetching active professors:", err));
}

function loadJobPostsChart(filters = {}) {
    const globalFilters = getFilterValues();
    const merged = { ...globalFilters, ...filters };
    // Updated: Using new buildParams that accepts a filters object
    let paramsPosts = buildParams("job-posts", merged);

    fetch("api/api.php?" + paramsPosts.toString())
        .then(res => res.json())
        .then(data => {
            console.log(data); // ตรวจสอบข้อมูลที่ได้รับจาก API

            // ตรวจสอบว่าข้อมูลมีอยู่และเป็น Array
            if (data && Array.isArray(data)) {
                const total = data.reduce((acc, row) => acc + Number(row.total_jobs), 0);
                document.getElementById("totalJobPosts").textContent = total;

                // เปลี่ยนชื่อ field จาก categories_name เป็น job_category_name
                const labels = data.map(d => d.job_category_name);
                const values = data.map(d => Number(d.total_jobs));

                // ตรวจสอบให้แน่ใจว่า values ไม่มี NaN ก่อนที่จะแสดงกราฟ
                const numericValues = values.map(val => {
                    const num = Number(val);
                    return isNaN(num) ? 0 : num;
                });

                renderBarChart("jobPostsChart", labels, numericValues, "จำนวนงานทั้งหมด", "#4B0082");
            } else {
                console.error("Invalid data format:", data);
            }
        })
        .catch(err => console.error("Error fetching job posts:", err));
}

function loadTopPaidJobPostsChart(filters = {}) {
    const globalFilters = getFilterValues();
    const merged = { ...globalFilters, ...filters };
    // Updated: Using new buildParams that accepts a filters object
    let paramsTopPaid = buildParams("top-paid-jobs", merged);
    fetch("api/api.php?" + paramsTopPaid.toString())
        .then(res => res.json())
        .then(data => {
            if (data && data.length > 0) {
                const titles = data.map(d => d.title);
                const salaries = data.map(d => Number(d.salary));
                renderBarChart("topPaidJobPostsChart", titles, salaries, "งานที่ได้ค่าตอบแทนสูงสุด", "#FF5733", true);
            } else {
                renderBarChart("topPaidJobPostsChart", [], [], "งานที่ได้ค่าตอบแทนสูงสุด", "#FF5733", true);
            }
        })
        .catch(err => console.error("Error fetching top paid job posts:", err));
}

function loadProfessorRatingChart(filters = {}) {
    const globalFilters = getFilterValues();
    const merged = { ...globalFilters, ...filters };
    // Updated: Using new buildParams that accepts a filters object
    let paramsRating = buildParams("professor-rating", merged);
    fetch("api/api.php?" + paramsRating.toString())
        .then(res => res.json())
        .then(data => {
            if (data && data.length > 0) {
                const best = data[0];
                document.getElementById("profRating").textContent = `อาจารย์ที่ดีที่สุด: ${best.name} (${best.total_closings})`;
                renderBarChart("profRatingChart", data.map(d => d.name), data.map(d => Number(d.total_closings) || 0), "การประเมินอาจารย์", "#66BB6A");
            }
        })
        .catch(err => console.error("Error fetching professor rating:", err));
}

function renderBarChart(canvasId, labels, values, labelText, bgColor, showValueOnBar = false) {
    const numericValues = values.map(val => {
        const num = Number(val);
        return isNaN(num) ? 0 : num;  // ถ้าค่าไม่ใช่ตัวเลข จะใช้ค่าเป็น 0
    });

    if (chartInstances[canvasId]) {
        chartInstances[canvasId].destroy();
    }

    chartInstances[canvasId] = new Chart(document.getElementById(canvasId), {
        type: "bar",
        data: {
            labels,
            datasets: [{
                label: labelText,
                data: numericValues,
                backgroundColor: bgColor,
                barPercentage: 1,
                categoryPercentage: 0.5
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                datalabels: {
                    display: function (context) {
                        return showValueOnBar && context.dataset.data[context.dataIndex] > 0;
                    },
                    anchor: 'end',
                    align: 'top',
                    offset: -4,
                    formatter: function (value, context) {
                        if (showValueOnBar) {
                            return `฿${value.toLocaleString()}`;
                        }
                        const jobTitle = context.chart.data.labels[context.dataIndex];
                        const shortTitle = jobTitle.length > 7 ? jobTitle.slice(0, 11) + '...' : jobTitle;
                        return shortTitle + ": " + value;
                    },
                    font: {
                        weight: 'bold',
                        size: 12
                    }
                }
            },
            scales: {
                x: {
                    ticks: {
                        autoSkip: false
                    }
                },
                y: {
                    beginAtZero: true
                }
            }
        },
        plugins: [ChartDataLabels]
    });
}

function renderPieChart(canvasId, labels, values, colorsArray) {
    if (chartInstances[canvasId]) {
        chartInstances[canvasId].destroy();
    }
    chartInstances[canvasId] = new Chart(document.getElementById(canvasId), {
        type: "pie",
        data: { labels, datasets: [{ data: values, backgroundColor: colorsArray }] },
        options: { responsive: true, maintainAspectRatio: false }
    });
}

function renderLineChart(canvasId, labels, values, labelText, color) {
    if (chartInstances[canvasId]) {
        chartInstances[canvasId].destroy();
    }
    chartInstances[canvasId] = new Chart(document.getElementById(canvasId), {
        type: "line",
        data: {
            labels,
            datasets: [{
                label: labelText,
                data: values,
                borderColor: color,
                fill: false
            }]
        },
        options: { responsive: true, maintainAspectRatio: false }
    });
}

function loadProfessorAnalytics() {
    loadActiveProfessorsChart(profAnalyticsChartFilters.activeProfs || {});
    loadJobPostsChart(profAnalyticsChartFilters.jobPosts || {});
    loadTopPaidJobPostsChart(profAnalyticsChartFilters.topPaidJobPosts || {});
    loadProfessorRatingChart(profAnalyticsChartFilters.profRating || {});
}

function applyGlobalFilters() {
    const globalFilters = getFilterValues();
    loadActiveProfessorsChart(profAnalyticsChartFilters.activeProfs ? { ...globalFilters, ...profAnalyticsChartFilters.activeProfs } : globalFilters);
    loadJobPostsChart(profAnalyticsChartFilters.jobPosts ? { ...globalFilters, ...profAnalyticsChartFilters.jobPosts } : globalFilters);
    loadTopPaidJobPostsChart(profAnalyticsChartFilters.topPaidJobPosts ? { ...globalFilters, ...profAnalyticsChartFilters.topPaidJobPosts } : globalFilters);
    loadProfessorRatingChart(profAnalyticsChartFilters.profRating ? { ...globalFilters, ...profAnalyticsChartFilters.profRating } : globalFilters);
}

function resetGlobalFilters() {
    const container = document.getElementById('filter-placeholder');
    if (!container) return;
    
    const fields = [
        'startDate', 'endDate', 'category', 'status', 'reward', 'teacher', 
        'major', 'year', 'gender', 'subcategory', 'mainSkill', 'subSkill',
        'hobby', 'subHobby', 'skillFilter'
    ];
    
    fields.forEach(id => {
        const el = container.querySelector('#' + id);
        if (el) el.value = '';
    });
    
    applyGlobalFilters();
}

function loadTopPaidJobPostsCategoryOptions() {
    fetch("api/api.php?endpoint=categories-list")
        .then(res => res.json())
        .then(data => {
            const selects = document.querySelectorAll("select[id^='topPaidJobPosts_'][id$='_category']");
            selects.forEach(select => {
                select.innerHTML = '<option value="">All</option>';
                data.forEach(item => {
                    const opt = document.createElement("option");
                    opt.value = item.job_category_id;
                    opt.textContent = item.job_category_name;
                    select.appendChild(opt);
                });
            });
        });
}