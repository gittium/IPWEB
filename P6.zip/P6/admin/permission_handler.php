<?php
class PermissionManager {
    private $db;
    
    public function __construct($db) {
        $this->db = $db;
    }
    
    public function getPermissionsByRole($role) {
        $stmt = $this->db->prepare("
            SELECT * FROM permissions 
            WHERE role_type = ? 
            ORDER BY category, name
        ");
        $stmt->bind_param("s", $role);
        $stmt->execute();
        return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    }
    public function updatePermissionStatus($permissionId, $status, $adminId) {
        $this->db->begin_transaction();
        try {
            // อัพเดทสถานะ
            $stmt = $this->db->prepare("
                UPDATE permissions 
                SET is_active = ? 
                WHERE id = ?
            ");
            $stmt->bind_param("ii", $status, $permissionId);
            $stmt->execute();
            
            // บันทึก log
            $action = $status ? 'enable' : 'disable';
            $stmt = $this->db->prepare("
                INSERT INTO permission_logs 
                (permission_id, admin_id, action) 
                VALUES (?, ?, ?)
            ");
            $stmt->bind_param("iis", $permissionId, $adminId, $action);
            $stmt->execute();
            
            $this->db->commit();
            return true;
        } catch (Exception $e) {
            $this->db->rollback();
            return false;
        }
    }


    public function renderPermissions($role) {
        $permissions = $this->getPermissionsByRole($role);
        $currentCategory = '';
        $html = '';

        foreach ($permissions as $permission) {
            if ($currentCategory !== $permission['category']) {
                if ($currentCategory !== '') {
                    $html .= '</div></div>';
                }
                $currentCategory = $permission['category'];
                $html .= $this->renderCategoryGroup($permission['category']);
            }
            $html .= $this->renderPermissionItem($permission);
        }

        if ($currentCategory !== '') {
            $html .= '</div></div>';
        }

        return $html;
    }

    private function renderCategoryGroup($category) {
        $translatedCategory = $this->translateCategory($category);
        return "
            <div class='permission-group'>
                <h2 class='group-title'>{$translatedCategory}</h2>
                <div class='permission-list'>
        ";
    }

    private function renderPermissionItem($permission) {
        return "
            <div class='permission-item'>
                <span class='permission-name'>{$permission['description']}</span>
                <label class='toggle-switch'>
                    <input type='checkbox' 
                           data-id='{$permission['id']}' 
                           " . ($permission['is_active'] ? 'checked' : '') . ">
                    <span class='toggle-slider'></span>
                </label>
            </div>
        ";
    }

    private function translateCategory($category) {
        $translations = [
            'job_posting' => 'จัดการโพสงาน (Jobs Posting Management)',
            'applications' => 'จัดการการสมัครงาน (Applications Management)',
            'profile' => 'แก้ไขโปรไฟล์ (Profile Management)',
            'job_application' => 'จัดการการสมัครงาน (Job Application Management)'
        ];
        return $translations[$category] ?? $category;
    }
    public function getUserPermissions($userId) {
        $stmt = $this->db->prepare("
            SELECT 
                p.*,
                COALESCE(up.is_active, true) as is_active
            FROM permissions p
            LEFT JOIN user_permissions up 
                ON p.id = up.permission_id 
                AND up.user_id = ?
            WHERE p.role_type = (
                SELECT CASE 
                    WHEN EXISTS (SELECT 1 FROM teachers WHERE id = ?) THEN 'teacher'
                    WHEN EXISTS (SELECT 1 FROM students WHERE id = ?) THEN 'student'
                    ELSE NULL
                END
            )
            ORDER BY p.category, p.name
        ");
        $stmt->bind_param("iii", $userId, $userId, $userId);
        $stmt->execute();
        return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    }

    // อัพเดทสิทธิ์รายบุคคล
    public function updateUserPermission($userId, $permissionId, $status, $adminId, $reason = '') {
        $this->db->begin_transaction();
        try {
            // อัพเดทหรือเพิ่มการตั้งค่าสิทธิ์
            $stmt = $this->db->prepare("
                INSERT INTO user_permissions 
                    (user_id, permission_id, is_active, modified_by) 
                VALUES (?, ?, ?, ?)
                ON DUPLICATE KEY UPDATE 
                    is_active = VALUES(is_active),
                    modified_by = VALUES(modified_by),
                    modified_at = CURRENT_TIMESTAMP
            ");
            $stmt->bind_param("iibi", $userId, $permissionId, $status, $adminId);
            $stmt->execute();

            // บันทึก log
            $action = $status ? 'enable' : 'disable';
            $stmt = $this->db->prepare("
                INSERT INTO user_permission_logs 
                    (user_id, permission_id, admin_id, action, reason)
                VALUES (?, ?, ?, ?, ?)
            ");
            $stmt->bind_param("iiiss", $userId, $permissionId, $adminId, $action, $reason);
            $stmt->execute();

            $this->db->commit();
            return true;
        } catch (Exception $e) {
            $this->db->rollback();
            return false;
        }
    }

    // ดึงประวัติการเปลี่ยนแปลงสิทธิ์ของผู้ใช้
    public function getUserPermissionLogs($userId) {
        $stmt = $this->db->prepare("
            SELECT 
                upl.*,
                p.name as permission_name,
                p.description as permission_description,
                a.name as admin_name
            FROM user_permission_logs upl
            JOIN permissions p ON upl.permission_id = p.id
            JOIN admins a ON upl.admin_id = a.id
            WHERE upl.user_id = ?
            ORDER BY upl.created_at DESC
        ");
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    }
    
    public function getAllUsers() {
        // This query pulls the name from the appropriate table based on the user's role.
        $query = "
            SELECT 
                u.id,
                CASE 
                    WHEN u.role_id = 3 THEN (SELECT t.name FROM teachers t WHERE t.id = u.id)
                    WHEN u.role_id = 4 THEN (SELECT s.name FROM students s WHERE s.id = u.id)
                    WHEN u.role_id = 2 THEN (SELECT a.name FROM admins a WHERE a.id = u.id)
                    WHEN u.role_id = 1 THEN (SELECT e.name FROM executives e WHERE e.id = u.id)
                    ELSE 'Unknown'
                END AS name,
                r.role_name AS role
            FROM users u
            JOIN roles r ON u.role_id = r.id
        ";
        
        $result = $this->db->query($query);
        return $result->fetch_all(MYSQLI_ASSOC);
    }
    

}
?>