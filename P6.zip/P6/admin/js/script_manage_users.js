document.addEventListener("DOMContentLoaded", function () {
    // เมื่อเลือก role ใน dropdown
    document.getElementById("roleSelect").addEventListener("change", function () {
        let role = this.value;
        window.location.href = "manage_users.php?role=" + role;
    });

    // ฟังก์ชันอัปเดตสถานะ (Disable/Activate)
    function updateStatus(userId, status) {
        fetch("manage_users.php", {
            method: "POST",
            headers: { "Content-Type": "application/x-www-form-urlencoded" },
            body: `user_id=${userId}&status=${status}`
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert("Status updated successfully!");
                location.reload(); // รีเฟรชหน้าใหม่
            } else {
                alert("Error updating status.");
            }
        })
        .catch(error => console.error("Error:", error));
    }

    // ใช้ Event Delegation เพื่อตรวจจับการคลิกที่ปุ่ม Disable / Activate
    document.body.addEventListener("click", function (event) {
        if (event.target.classList.contains("status-btn")) {
            let userId = event.target.getAttribute("data-id");
            let status = event.target.getAttribute("data-status");
            console.log("UserID:", userId, "Status:", status); // ตรวจสอบข้อมูลที่รับมา
            updateStatus(userId, status);
        }
    });

    // เพิ่มการจัดการ hover ให้กับปุ่ม
    document.querySelectorAll(".status-btn").forEach((btn) => {
        btn.addEventListener("mouseenter", function () {
            if (this.dataset.status === "2") {
                this.style.backgroundColor = "rgba(255, 0, 0, 0.9)"; // สีแดงเข้มขึ้น
            } else {
                this.style.backgroundColor = "rgba(0, 128, 0, 0.9)"; // สีเขียวเข้มขึ้น
            }
        });

        btn.addEventListener("mouseleave", function () {
            if (this.dataset.status === "2") {
                this.style.backgroundColor = "rgba(255, 0, 0, 0.7)"; // สีแดงโปร่งใสขึ้น
            } else {
                this.style.backgroundColor = "rgba(0, 128, 0, 0.7)"; // สีเขียวโปร่งใสขึ้น
            }
        });
    });
});
