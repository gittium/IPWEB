<?php
include 'siderbar.php';

// ตั้งค่าการเชื่อมต่อฐานข้อมูล
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "ipfinal";

// สร้างการเชื่อมต่อ
$conn = new mysqli($servername, $username, $password, $dbname);

// ตรวจสอบการเชื่อมต่อ
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// ดึงข้อมูลจากฐานข้อมูล
$user_count = $conn->query("SELECT COUNT(*) AS total FROM user")->fetch_assoc()['total'];
$report_count = $conn->query("SELECT COUNT(*) AS total FROM reports")->fetch_assoc()['total'];
$roles = $conn->query("SELECT roles_name FROM roles");

// ปิดการเชื่อมต่อหลังจากดึงข้อมูลเสร็จแล้ว
$conn->close();
?>

<!DOCTYPE html>
<html lang="th">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Home</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.gstatic.com" />
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&family=Montserrat:wght@600&display=swap" rel="stylesheet" />

    <!-- External CSS -->
    <link rel="stylesheet" href="style_home.css">
    <link rel="stylesheet" href="style_sidebar.css">
    <style>
        /* ตั้งค่าพื้นฐาน */
body {
    font-family: 'Roboto', sans-serif;
    background-color: #f4f7fc;
    color: #333;
    margin: 0;
    padding: 0;
}

/* จัดสไตล์เนื้อหาหลัก */
.main-content {
    max-width: 1200px;
    margin: auto;
    padding: 20px;
    text-align: center;
}

/* หัวข้อหลัก */
h1 {
    font-size: 2rem;
    color: #2c3e50;
}

p {
    font-size: 1.1rem;
    color: #555;
}

/* เส้นคั่น */
hr {
    width: 80%;
    border: 1px solid #ddd;
    margin: 20px auto;
}

/* กริดของ Dashboard */
.dashboard {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 20px;
    margin-top: 20px;
}

/* การ์ด */
.card {
    background: white;
    border-radius: 12px;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
    padding: 20px;
    text-align: center;
    transition: transform 0.3s ease, box-shadow 0.3s ease;
}

.card:hover {
    transform: translateY(-5px);
    box-shadow: 0 6px 15px rgba(0, 0, 0, 0.15);
}

.card h3 {
    font-size: 1.5rem;
    margin-bottom: 10px;
    color: #34495e;
}

.card p {
    font-size: 1.8rem;
    font-weight: bold;
    color: #3498db;
}

/* Container สำหรับบทบาท */
.role-container {
    display: flex;
    flex-direction: column;
    gap: 10px;
    margin-top: 15px;
}

/* รายการบทบาท */
.role-item {
    background: #3498db;
    color: white;
    padding: 10px;
    border-radius: 8px;
    font-size: 1rem;
    font-weight: bold;
    transition: background 0.3s ease;
}

.role-item:hover {
    background: #2980b9;
}

    </style>
</head>

<body>
    <!-- Main Content -->
    <div class="main-content">
        <h1>ระบบจัดหางานและพัฒนาทักษะ CSIT</h1>
        <p>ยินดีต้อนรับสู่ระบบจัดการข้อมูล</p>
        <hr class="my-4">

        <div class="dashboard">
            <!-- การ์ดแสดงจำนวนผู้ใช้งาน -->
            <div class="card" id="users-card">
                <h3>ผู้ใช้งาน</h3>
                <p id="user-count"><?php echo $user_count; ?></p>
            </div>

            <!-- การ์ดแสดงบทบาททั้งหมด -->
            <div class="card" id="roles-card">
                <h3>บทบาท</h3>
                <div class="role-container">
                    <?php while ($row = $roles->fetch_assoc()) : ?>
                        <div class="role-item"><?php echo htmlspecialchars($row['roles_name']); ?></div>
                    <?php endwhile; ?>
                </div>
            </div>

            <!-- การ์ดแสดงจำนวนรายงาน -->
            <div class="card" id="reports-card">
                <h3>รายงาน</h3>
                <p id="report-count"><?php echo $report_count; ?></p>
            </div>
        </div>
    </div>

    <!-- External JavaScript -->
    
    <script src="script_sidebar.js"></script>
</body>

</html>
