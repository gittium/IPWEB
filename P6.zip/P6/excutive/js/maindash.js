// maindash.js

// Dictionary to store chart instances
const chartInstances = {};

document.addEventListener("DOMContentLoaded", function () {
    Promise.all([
        loadCategoryOptions(), 
        loadStatusOptions(),
        loadRewardOptions(),
        loadTeacherOptions()
      ]).then(() => {
        // Now that we've loaded all filter options, we can do the main logic
        loadMainDashboard();
        loadJobComparisonChart()
      }).catch(err => {
        console.error("Error loading filter options:", err);
        // even if they fail, still attempt to load main logic
        loadMainDashboard();
        loadJobComparisonChart()
      });
    });


    function loadCategoryOptions() {
        return fetch("api/api.php?endpoint=categories-list")
          .then(res => res.json())
          .then(data => {
            const categorySelect = document.getElementById("category");
            categorySelect.innerHTML = '<option value="">All</option>';
            data.forEach(item => {
              const opt = document.createElement("option");
              opt.value = item.job_categories_id;
              opt.textContent = item.categories_name;
              categorySelect.appendChild(opt);
            });
          });
      }
      
      function loadStatusOptions() {
        return fetch("api/api.php?endpoint=status-list")
          .then(res => res.json())
          .then(data => {
            const statusSelect = document.getElementById("status");
            statusSelect.innerHTML = '<option value="">All</option>';
            data.forEach(item => {
              const opt = document.createElement("option");
              opt.value = item.job_status_id;
              opt.textContent = item.job_status_name;
              statusSelect.appendChild(opt);
            });
          });
      }
      
      function loadRewardOptions() {
        return fetch("api/api.php?endpoint=reward-list")
          .then(res => res.json())
          .then(data => {
            const rewardSelect = document.getElementById("reward");
            rewardSelect.innerHTML = '<option value="">All</option>';
            data.forEach(item => {
              const opt = document.createElement("option");
              opt.value = item.reward_type_id;
              opt.textContent = item.reward_name;
              rewardSelect.appendChild(opt);
            });
          });
      }
      
      function loadTeacherOptions() {
        return fetch("api/api.php?endpoint=teacher-list")
          .then(res => res.json())
          .then(data => {
            const teacherSelect = document.getElementById("teacher");
            teacherSelect.innerHTML = '<option value="">All</option>';
            data.forEach(item => {
              const opt = document.createElement("option");
              opt.value = item.teachers_id;
              opt.textContent = item.name;
              teacherSelect.appendChild(opt);
            });
          });
      }

// Called when the user clicks the "Apply" filter button
function applyFilters() {
    loadMainDashboard();
}
function applySemesterFilter() {
    const semester = document.getElementById("semester").value;
    const year = document.getElementById("year").value;
    
    // Get the corresponding start and end dates based on the semester and year.
    const { start, end } = getSemesterDateRange(semester, year);
    
    // For the job comparison chart, you can update the global filter or call a dedicated load function.
    // Here, we assume you want to pass these dates to the API.
    
    // You can update the start and end date inputs (if you're using them for your existing filters):
    document.getElementById("startDate").value = start;
    document.getElementById("endDate").value = end;
    
    // Then reload the chart (for example, your job comparison chart)
    loadJobComparisonChart();
  }
  
function getSemesterDateRange(semester, year) {
    // Adjust the dates as needed for your institution.
    // In this example:
    //   - First Semester: from June 25 of the given year to November 24 of the same year.
    //   - Second Semester: from November 25 of the given year to March 24 of the next year.
    //   - Third Semester (Summer): from March 25 of the given year to June 24 of the same year.
    if (!semester || !year) {
      return { start: '', end: '' };
    }
    
    let start, end;
    year = Number(year);
    
    if (semester === 'first') {
      start = `${year}-06-25`;
      end = `${year}-11-24`;
    } else if (semester === 'second') {
      start = `${year}-11-25`;
      // For second semester, the end is in the following year (e.g. from November 25, 2025 to March 24, 2026)
      end = `${year + 1}-03-24`;
    } else if (semester === 'third') {
      start = `${year}-03-25`;
      end = `${year}-06-24`;
    }
    
    return { start, end };
  }
  
function loadJobComparisonChart() {
    const { start, end, category, status, reward, teacher } = getFilterValues();
    const paramsOverTime = buildParams("jobs-over-time", start, end, category, status, reward, teacher);
    const paramsTakenOvertime = buildParams("jobs-taken-overtime", start, end, category, status, reward, teacher);
    
    Promise.all([
        fetch("api/api.php?" + paramsOverTime.toString()).then(res => res.json()),
        fetch("api/api.php?" + paramsTakenOvertime.toString()).then(res => res.json())
    ]).then(([dataOverTime, dataTakenOvertime]) => {
        // Build a combined data map by month
        const dataMap = {};
        // Fill in overall jobs posted (using creation date)
        dataOverTime.forEach(item => {
            dataMap[item.month] = { total: Number(item.total_posts), closed: 0 };
        });
        // Merge the closed jobs (using job_end date)
        dataTakenOvertime.forEach(item => {
            if (dataMap[item.month]) {
                dataMap[item.month].closed = Number(item.total_jobs_closed);
            } else {
                dataMap[item.month] = { total: 0, closed: Number(item.total_jobs_closed) };
            }
        });
        // Sort the months (assuming the month strings sort correctly)
        const months = Object.keys(dataMap).sort();
        const totalPosts = months.map(month => dataMap[month].total);
        const jobsClosed = months.map(month => dataMap[month].closed);
        
        // Render the multi-line chart with both datasets
        renderMultiLineChart("jobsOverTimeChart", months, totalPosts, jobsClosed);
    }).catch(err => console.error("Error fetching job comparison data:", err));
}

// Function to render a table with all job categories and counts
function renderJobCategoriesTable(labels, values) {
    let tableHTML = `<table class="table table-striped">
        <thead>
            <tr>
                <th>Category</th>
                <th>Job Count</th>
            </tr>
        </thead>
        <tbody>`;
    for (let i = 0; i < labels.length; i++) {
        tableHTML += `<tr>
            <td>${labels[i]}</td>
            <td>${values[i]}</td>
        </tr>`;
    }
    tableHTML += `</tbody></table>`;
    document.getElementById("jobCategoriesTableContainer").innerHTML = tableHTML;
}


function loadMainDashboard() {
    const { start, end, category, status, reward, teacher } = getFilterValues();

    // 1) job-market => Active Jobs
    const paramsMarket = buildParams("job-market", start, end, category, status, reward, teacher);
    fetch("api/api.php?" + paramsMarket.toString())
        .then(res => res.json())
        .then(data => {
            const totalJobs = data.reduce((acc, row) => acc + Number(row.total_jobs), 0);
            document.getElementById("activeJobs").textContent = totalJobs;

            const labels = data.map(d => d.category_name);
            const values = data.map(d => d.total_jobs);
            renderBarChart("activeJobsChart", labels, values, "Active Jobs", "#FF6B00");
        })
        .catch(err => console.error("Error fetching job-market:", err));

    // 2) active-students => Registered Students
    const paramsStud = buildParams("active-students", start, end, category, status, reward, teacher);
    // Updated Registered Students Comparison section
    fetch("api/api.php?endpoint=active-students")
        .then(res => res.json())
        .then(data => {
            if (data && data[0]) {
                // Parse the three metrics
                const total = Number(data[0].total_students);
                const accepted = Number(data[0].accepted_students);
                const notAccepted = Number(data[0].not_accepted_students);

                // Optionally update a text element for the total students
                document.getElementById("totalStudents").textContent = total;

                // Render a bar chart comparing all three metrics
                renderBarChart(
                    "studentsChart", 
                    ["Total Students", "Job Accepted", "No Job"], 
                    [total, accepted, notAccepted], 
                    "Student Comparison", 
                    "#4B0082"
                );
            }
        })
        .catch(err => console.error("Error fetching active-students:", err));


    // 3) job-market again => top job categories (pie)
    fetch("api/api.php?" + paramsMarket.toString())
    .then(res => res.json())
    .then(data => {
        const labels = data.map(d => d.category_name);
        const values = data.map(d => Number(d.total_jobs));
        const filteredData = labels.reduce((acc, label, index) => {
            if (values[index] > 0) {
                acc.labels.push(label);
                acc.values.push(values[index]);
            }
            return acc;
        }, { labels: [], values: [] });
        
        // Render the pie chart with only non-zero categories and a chart title
        renderPieChart("jobCategoriesChart", filteredData.labels, filteredData.values, [
            "#FF6B00", "#4B0082", "#FFA726", "#66BB6A", "#29B6F6"
        ], "Job Categories Distribution");
        
        renderJobCategoriesTable(labels, values);
    })
    .catch(err => console.error("Error fetching categories:", err));


    // 4) applications => Applications per Job
    //    (No date filters unless you modify the API to join post_jobs)
    fetch("api/api.php?endpoint=applications")
        .then(res => res.json())
        .then(data => {
            const labels = data.map(d => d.title);
            const values = data.map(d => Number(d.total_applications));
            renderBarChart("applicationsChart", labels, values, "Applications", "#4B0082");
        })
        .catch(err => console.error("Error fetching applications:", err));

    // 5) jobs-over-time => line chart
    // const paramsTime = buildParams("jobs-over-time", start, end, category, status, reward, teacher);
    // fetch("api/api.php?" + paramsTime.toString())
    //     .then(res => res.json())
    //     .then(data => {
    //         const labels = data.map(d => d.month);
    //         const values = data.map(d => Number(d.total_posts));
    //         renderLineChart("jobsOverTimeChart", labels, values, "Jobs Over Time", "#FF6B00");
    //     })
    //     .catch(err => console.error("Error fetching jobs-over-time:", err));
        
}

// ================= HELPER FUNCTIONS =================

// Gets filter values from the HTML controls
function getFilterValues() {
    return {
        start: document.getElementById("startDate")?.value || "",
        end: document.getElementById("endDate")?.value || "",
        category: document.getElementById("category")?.value || "",
        status: document.getElementById("status")?.value || "",
        reward: document.getElementById("reward")?.value || "",
        teacher: document.getElementById("teacher")?.value || ""
    };
}

// Builds a URLSearchParams for the API call
function buildParams(endpoint, start, end, category, status, reward, teacher) {
    const p = new URLSearchParams({ endpoint });
    if (start) p.set("start", start);
    if (end) p.set("end", end);
    if (category) p.set("category", category);
    if (status) p.set("status", status);
    if (reward) p.set("reward", reward);
    if (teacher) p.set("teacher", teacher);
    return p;
}

// Renders a Bar Chart
// Renders a Bar Chart with Data Labels Always Visible
function renderBarChart(canvasId, labels, values, labelText, bgColor) {
    if (chartInstances[canvasId]) {
        chartInstances[canvasId].destroy();
    }
    chartInstances[canvasId] = new Chart(document.getElementById(canvasId), {
        type: "bar",
        data: {
            labels,
            datasets: [{
                label: labelText,
                data: values,
                backgroundColor: bgColor,
                barPercentage: 1,  // Adjust bar width (smaller = more spacing)
                categoryPercentage: 0.5  // Adjust space between categories
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                datalabels: {
                    display: true,
                    anchor: 'end',
                    align: 'top',
                    offset: -4,  // Adjust this offset to lift labels further above the bar
                    formatter: function(value, context) {
                        const jobTitle = context.chart.data.labels[context.dataIndex];
                        // Shorten label if needed to avoid overlap
                        const shortTitle = jobTitle.length > 7 ? jobTitle.slice(0, 11) + '...' : jobTitle;
                        return shortTitle + ": " + value;
                    },
                    font: {
                        weight: 'bold',
                        size: 9  // Adjust font size as needed
                    }
                }
            },
            scales: {
                x: {
                    ticks: {
                        callback: function(val, index) {
                            const maxLen = 100;
                            const label = this.getLabelForValue(val);
                            return (label.length > maxLen)
                                ? label.slice(0, maxLen) + '...'
                                : label;
                        }
                    }
                },
                y: {
                    beginAtZero: true
                }
            }
        },
        plugins: [ChartDataLabels]
    });
}





// Renders a Pie Chart with Data Labels Always Visible
function renderPieChart(canvasId, labels, values, colorsArray) {
    // Calculate total sum of values
    const total = values.reduce((acc, cur) => acc + cur, 0);

    if (chartInstances[canvasId]) {
        chartInstances[canvasId].destroy();
    }
    chartInstances[canvasId] = new Chart(document.getElementById(canvasId), {
        type: "pie",
        data: {
            labels,
            datasets: [{
                data: values,
                backgroundColor: colorsArray
                
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                datalabels: {
                    display: true,
                    anchor: 'center',
                    align: 'end',
                    offset: 2,
                    formatter: function(value, context) {
                        const label = context.chart.data.labels[context.dataIndex];
                        // Calculate percentage and format to one decimal place
                        const percent = ((value / total) * 100).toFixed(1);
                        return label + "\n" +"     " + percent + '%';
                    },
                    color: '#fff',
                    font: {
                        weight: 'bold',
                        size: 12
                    },
                    padding: 6,
                    clip: true 
                }
            }
        },
        plugins: [ChartDataLabels]
    });
}





// Renders a Line Chart with Data Labels Always Visible
// function renderLineChart(canvasId, labels, values, labelText, color) {
//     if (chartInstances[canvasId]) {
//         chartInstances[canvasId].destroy();
//     }
//     chartInstances[canvasId] = new Chart(document.getElementById(canvasId), {
//         type: "line",
//         data: {
//             labels,
//             datasets: [{
//                 label: labelText,
//                 data: values,
//                 borderColor: color,
//                 fill: false
//             }]
//         },
//         options: {
//             responsive: true,
//             maintainAspectRatio: false,
//             plugins: {
//                 datalabels: {
//                     display: true,
//                     align: 'top',
//                     formatter: Math.round,
//                     font: {
//                         weight: 'bold'
//                     }
//                 }
//             }
//         },
//         plugins: [ChartDataLabels]
//     });
// }
function renderMultiLineChart(canvasId, labels, valuesTotal, valuesClosed) {
    if (chartInstances[canvasId]) {
        chartInstances[canvasId].destroy();
    }
    chartInstances[canvasId] = new Chart(document.getElementById(canvasId), {
        type: "line",
        data: {
            labels,
            datasets: [
                {
                    label: "Total Jobs Posted",
                    data: valuesTotal,
                    borderColor: "#FF6B00",
                    backgroundColor: "transparent",
                    fill: false,
                    tension: 0.1
                },
                {
                    label: "Jobs Completed (Closed)",
                    data: valuesClosed,
                    borderColor: "#4B0082",
                    backgroundColor: "transparent",
                    fill: false,
                    tension: 0.1
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                datalabels: {
                    display: true,
                    align: 'top',
                    formatter: Math.round,
                    font: {
                        weight: 'bold',
                        size: 10
                    }
                },
                tooltip: {
                    mode: 'index',
                    intersect: false
                }
            },
            interaction: {
                mode: 'index',
                intersect: false
            },
            scales: {
                y: { beginAtZero: true }
            }
        },
        plugins: [ChartDataLabels]
    });
}


