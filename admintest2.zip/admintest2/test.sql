select * from admins
WHERE role_id = 2;


ALTER TABLE permission_logs DROP FOREIGN KEY permission_logs_ibfk_1;
ALTER TABLE user_permission_logs DROP FOREIGN KEY user_permission_logs_ibfk_1;

select * from user_permission_logs