-- สร้างตาราง permissions
CREATE TABLE permissions (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    category VARCHAR(50) NOT NULL,
    role_type ENUM('teacher', 'student') NOT NULL,
    is_active BOOLEAN DEFAULT true
);



-- สร้างตารางบันทึกการเปลี่ยนแปลง permissions
-- CREATE TABLE permission_logs (
--     id INT PRIMARY KEY AUTO_INCREMENT,
--     permission_id INT,
--     admin_id INT,
--     action VARCHAR(20) NOT NULL,
--     created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
--     FOREIGN KEY (permission_id) REFERENCES permissions(id),
--     FOREIGN KEY (admin_id) REFERENCES admins(id)
-- );

-- ตารางเก็บสิทธิ์รายบุคคล
CREATE TABLE user_permissions (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    permission_id INT NOT NULL,
    is_active BOOLEAN DEFAULT true,
    modified_by INT,
    modified_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (permission_id) REFERENCES permissions(id),
    FOREIGN KEY (modified_by) REFERENCES admins(id)
);

-- ตารางเก็บประวัติการเปลี่ยนแปลงสิทธิ์รายบุคคล
-- CREATE TABLE user_permission_logs (
--     id INT PRIMARY KEY AUTO_INCREMENT,
--     user_id INT NOT NULL,
--     permission_id INT NOT NULL,
--     admin_id INT NOT NULL,
--     action VARCHAR(20) NOT NULL,
--     reason TEXT,
--     created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
--     FOREIGN KEY (user_id) REFERENCES users(id),
--     FOREIGN KEY (permission_id) REFERENCES permissions(id),
--     FOREIGN KEY (admin_id) REFERENCES admins(id)
-- );


-- เพิ่มข้อมูลสำหรับสิทธิ์อาจารย์
INSERT INTO permissions (name, description, category, role_type) VALUES
('create_job', 'สร้างโพสงานใหม่', 'job_posting', 'teacher'),
('edit_job', 'แก้ไขหรือลบโพสงานที่สร้าง', 'job_posting', 'teacher'),
('close_job', 'ปิดการรับสมัครงาน', 'job_posting', 'teacher'),
('view_applications', 'ดูรายชื่อนิสิตที่สมัครเข้าช่วยงาน', 'applications', 'teacher'),
('manage_applications', 'อนุมัติหรือปฏิเสธการสมัครของนิสิต', 'applications', 'teacher'),
('edit_profile', 'แก้ไขข้อมูลส่วนตัวและข้อมูลการติดต่อ', 'profile', 'teacher');

-- เพิ่มข้อมูลสำหรับสิทธิ์นิสิต
INSERT INTO permissions (name, description, category, role_type) VALUES
('view_jobs', 'ดูประกาศงานที่เปิดรับสมัคร', 'job_application', 'student'),
('apply_jobs', 'สมัครงานที่สนใจ', 'job_application', 'student'),
('cancel_application', 'ยกเลิกการสมัครงาน', 'job_application', 'student'),
('view_status', 'ดูสถานะใบสมัครของตนเอง', 'applications', 'student'),
('track_applications', 'ติดตามสถานะการสมัคร', 'applications', 'student'),
('edit_student_profile', 'แก้ไขข้อมูลส่วนตัวและข้อมูลการติดต่อ', 'profile', 'student'),
('update_resume', 'อัพเดทประวัติและเรซูเม่', 'profile', 'student');