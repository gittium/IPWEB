<?php
require_once 'config.php';
require_once 'permission_handler.php';

$role = $_GET['role'] ?? 'teacher';
$allowed_roles = ['teacher', 'student'];
if (!in_array($role, $allowed_roles)) {
    $role = 'teacher';
}