<?php
$host = 'db';
$username = 'laravel';
$password = 'laravel';
$database = 'ip_web2';

$db = new mysqli($host, $username, $password, $database);

if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
}

$db->set_charset("utf8mb4");
?>