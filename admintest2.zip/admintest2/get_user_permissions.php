<?php
// get_user_permissions.php
require_once 'config.php';
require_once 'permission_handler.php';

// Get the user ID from the query string (or default to 0)
$userId = isset($_GET['user_id']) ? intval($_GET['user_id']) : 0;

$permissionManager = new PermissionManager($db);
$permissions = $permissionManager->getUserPermissions($userId);

// Since the translateCategory() method in PermissionManager is private,
// we create our own helper here.
function translateCategory($category) {
    $translations = [
        'job_posting'    => 'จัดการโพสงาน (Jobs Posting Management)',
        'applications'   => 'จัดการการสมัครงาน (Applications Management)',
        'profile'        => 'แก้ไขโปรไฟล์ (Profile Management)',
        'job_application'=> 'จัดการการสมัครงาน (Job Application Management)'
    ];
    return isset($translations[$category]) ? $translations[$category] : $category;
}

$currentCategory = "";
$html = "";

// Build HTML output grouping permissions by category
foreach ($permissions as $permission) {
    if ($currentCategory !== $permission['category']) {
        if ($currentCategory !== "") {
            $html .= "</div></div>";
        }
        $currentCategory = $permission['category'];
        $translatedCategory = translateCategory($permission['category']);
        $html .= "<div class='permission-group'>
                    <h2 class='group-title'>{$translatedCategory}</h2>
                    <div class='permission-list'>";
    }
    // Determine if the toggle should be checked
    $checked = $permission['is_active'] ? "checked" : "";
    $html .= "<div class='permission-item'>
                <span class='permission-name'>{$permission['description']}</span>
                <label class='toggle-switch'>
                    <input type='checkbox' data-id='{$permission['id']}' {$checked}>
                    <span class='toggle-slider'></span>
                </label>
              </div>";
}

if ($currentCategory !== "") {
    $html .= "</div></div>";
}

echo $html;
?>
