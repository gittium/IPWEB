<?php
// get_permission_logs.php
require_once 'config.php';
require_once 'permission_handler.php';

$userId = isset($_GET['user_id']) ? intval($_GET['user_id']) : 0;
$permissionManager = new PermissionManager($db);
$logs = $permissionManager->getUserPermissionLogs($userId);

$html = "";
if (count($logs) > 0) {
    foreach ($logs as $log) {
        // Each log entry includes:
        // upl.*, p.name as permission_name, p.description as permission_description, a.name as admin_name, and created_at.
        $html .= "<div class='history-item'>";
        $html .= "<div>
                    <strong>{$log['admin_name']}</strong> " . ucfirst($log['action']) . " permission <strong>{$log['permission_name']}</strong>";
        if (!empty($log['reason'])) {
            $html .= " (Reason: {$log['reason']})";
        }
        $html .= "</div>";
        $html .= "<div><small>{$log['created_at']}</small></div>";
        $html .= "</div>";
    }
} else {
    $html .= "<p>No permission logs found for this user.</p>";
}

echo $html;
?>
