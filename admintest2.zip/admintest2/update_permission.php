<?php
session_start();
require_once 'config.php';
require_once 'permission_handler.php';


$_SESSION['admin_id'] = 65312142;
$response = ['success' => false, 'message' => ''];

// if (!isset($_SESSION['admin_id'])) {
//     $response['message'] = 'Unauthorized access';
//     echo json_encode($response);
//     exit;
// }

$permissionId = $_POST['permission_id'] ?? null;
$status = $_POST['status'] ?? null;

if ($permissionId === null || $status === null) {
    $response['message'] = 'Missing required parameters';
    echo json_encode($response);
    exit;
}

$permissionManager = new PermissionManager($db);
$result = $permissionManager->updatePermissionStatus($permissionId, $status, $_SESSION['admin_id']);

$response['success'] = $result;
$response['message'] = $result ? 'Permission updated successfully' : 'Failed to update permission';
echo json_encode($response);
?>