<!-- user_permissions.php -->
<?php
require_once 'config.php';
require_once 'permission_handler.php';
$permissionManager = new PermissionManager($db);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>User Permissions</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <link rel="stylesheet" href="style_permission.css">
    <link rel="stylesheet" href="style_sidebar&role.css">
</head>
<body>
    <div id="sidebar-container"></div>

    <main class="main-content">
        <div class="permission-container">
            <div class="permission-header">
                <h1 class="page-title">User Permissions</h1>
                <div class="user-selector">
                    <span class="role-label">User:</span>
                    <select class="role-select" id="userSelect">
                        <?php
                        // ดึงรายชื่อผู้ใช้ทั้งหมด
                        $users = $permissionManager->getAllUsers();
                        foreach ($users as $user) {
                            echo "<option value='{$user['id']}'>{$user['name']} ({$user['role']})</option>";
                        }
                        ?>
                    </select>
                </div>
            </div>

            <div id="userPermissionsContent">
                <!-- Permissions will be loaded here -->
            </div>

            <!-- Permission History -->
            <!-- <div class="permission-history">
                <h2>Permission History</h2>
                <div id="permissionLogs"> -->
                    <!-- Logs will be loaded here -->
                </div>
            </div>
        </div>
    </main>
    <script src="script_sidebar&role.js"></script>
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        loadSidebar();
        const userSelect = document.getElementById('userSelect');
        
        // โหลดข้อมูลสิทธิ์เมื่อเลือกผู้ใช้
        userSelect.addEventListener('change', async function() {
            const userId = this.value;
            await loadUserPermissions(userId);
            await loadPermissionLogs(userId);
        });

        // โหลดข้อมูลเริ่มต้น
        if (userSelect.value) {
            loadUserPermissions(userSelect.value);
            loadPermissionLogs(userSelect.value);
        }
    });

    async function loadUserPermissions(userId) {
        const response = await fetch(`get_user_permissions.php?user_id=${userId}`);
        const html = await response.text();
        document.getElementById('userPermissionsContent').innerHTML = html;
        setupToggleSwitches();
    }

    async function loadPermissionLogs(userId) {
        const response = await fetch(`get_permission_logs.php?user_id=${userId}`);
        const html = await response.text();
        document.getElementById('permissionLogs').innerHTML = html;
    }

    function setupToggleSwitches() {
            const toggles = document.querySelectorAll('.toggle-switch input');
            toggles.forEach(toggle => {
                toggle.addEventListener('change', async function() {
                    const permissionId = this.dataset.id;
                    const status = this.checked ? 1 : 0;
                    
                    try {
                        const response = await fetch('update_permission.php', {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/x-www-form-urlencoded',
                            },
                            body: `permission_id=${permissionId}&status=${status}`
                        });
                        
                        if (!response.ok) {
                            throw new Error('Failed to update permission');
                        }
                    } catch (error) {
                        console.error('Error updating permission:', error);
                        this.checked = !this.checked; // revert the toggle if update failed
                    }
                });
            });
        }
        setupToggleSwitches();
    </script>
</body>
</html>