document.addEventListener('DOMContentLoaded', function() {
    // Common chart configuration
    const chartConfig = {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: {
                position: 'right',
                labels: {
                    padding: 20,
                    font: { size: 12 }
                }
            },
            tooltip: {
                callbacks: {
                    label: function(context) {
                        const label = context.label || '';
                        const value = context.parsed || 0;
                        return `${label}: ${value} jobs`;
                    }
                }
            }
        }
    };

    // Doughnut specific configuration
    const doughnutConfig = {
        type: 'doughnut',
        options: {
            ...chartConfig,
            plugins: {
                ...chartConfig.plugins
            }
        }
    };

    // Color schemes
    const colors = {
        categories: [
            '#FF6384', '#36A2EB', '#FFCE56', '#4BC0C0', '#9966FF',
            '#FF9F40', '#4BC0C0', '#FF6384', '#36A2EB', '#FFCE56',
            '#9966FF', '#FF9F40', '#4BC0C0', '#FF6384', '#36A2EB',
            '#FFCE56', '#9966FF'  // Matching your 17 job categories
        ],
        status: ['#36A2EB', '#FF6384', '#FFCE56'],  // open, close, delete
        rewards: ['#4BC0C0', '#FF6384']  // money, hours of experience
    };

    // Active Jobs Overview
    fetch("api/api.php?endpoint=job-market")
        .then(response => response.json())
        .then(data => {
            if (!data || data.length === 0) {
                console.error("No job market data found.");
                return;
            }
            const totalJobs = data.reduce((sum, item) => sum + Number(item.total_jobs), 0);
            document.getElementById("activeJobsCount").textContent = totalJobs;

            const labels = data.map(item => item.category_name);
            const values = data.map(item => item.total_jobs);
            new Chart(document.getElementById("activeJobsChart"), {
                type: "bar",
                data: { 
                    labels: labels, 
                    datasets: [{ 
                        label: "Active Jobs", 
                        data: values, 
                        backgroundColor: "#FF6B00" 
                    }] 
                },
                options: chartConfig
            });
        })
        .catch(error => console.error("Error fetching active jobs:", error));

    // Job Categories Distribution
    fetch('api/api.php?endpoint=job-categories-stats')
        .then(response => response.json())
        .then(data => {
            const ctx = document.getElementById('jobCategoriesChart').getContext('2d');
            new Chart(ctx, {
                ...doughnutConfig,
                data: {
                    labels: data.map(item => `${item.category_name} (${item.percentage}%)`),
                    datasets: [{
                        data: data.map(item => item.total_jobs),
                        backgroundColor: colors.categories.slice(0, data.length)
                    }]
                }
            });
        })
        .catch(error => console.error('Error fetching categories data:', error));

    // Job Status Distribution
    fetch('api/api.php?endpoint=job-status-stats')
        .then(response => response.json())
        .then(data => {
            const ctx = document.getElementById('jobStatusChart').getContext('2d');
            new Chart(ctx, {
                ...doughnutConfig,
                data: {
                    labels: data.map(item => `${item.job_status_name} (${item.percentage}%)`),
                    datasets: [{
                        data: data.map(item => item.total_jobs),
                        backgroundColor: colors.status
                    }]
                }
            });
        })
        .catch(error => console.error('Error fetching status data:', error));

    // Reward Type Distribution
    fetch('api/api.php?endpoint=reward-type-stats')
        .then(response => response.json())
        .then(data => {
            const ctx = document.getElementById('rewardTypeChart').getContext('2d');
            new Chart(ctx, {
                ...doughnutConfig,
                data: {
                    labels: data.map(item => `${item.reward_name} (${item.percentage}%)`),
                    datasets: [{
                        data: data.map(item => item.total_jobs),
                        backgroundColor: colors.rewards
                    }]
                }
            });
        })
        .catch(error => console.error('Error fetching reward type data:', error));

    // Pay Rate Distribution
    fetch("api/api.php?endpoint=pay-rate")
        .then(response => response.json())
        .then(data => {
            if (data && data.length > 0) {
                const payRateStats = data[0];
                document.getElementById("averagePayRate").innerHTML = `
                    <div class="text-lg">
                        <div>Money: ${payRateStats.money_percentage}%</div>
                        <div>Experience: ${payRateStats.experience_percentage}%</div>
                    </div>
                `;
                
                const ctx = document.getElementById('payRateChart').getContext('2d');
                new Chart(ctx, {
                    ...doughnutConfig,
                    data: {
                        labels: ['Money Based', 'Experience Based'],
                        datasets: [{
                            data: [payRateStats.money_percentage, payRateStats.experience_percentage],
                            backgroundColor: ['#36A2EB', '#FF6384']
                        }]
                    }
                });
            }
        })
        .catch(error => {
            console.error("Error fetching pay rate:", error);
            document.getElementById("averagePayRate").textContent = "Error loading data";
        });

    // Completion Rate
    fetch("api/api.php?endpoint=completion-rate")
        .then(response => response.json())
        .then(data => {
            if (data && data.length > 0) {
                const completionStats = data[0];
                document.getElementById("completionRate").innerHTML = `
                    <div class="text-lg">
                        <div>${completionStats.completion_percentage}%</div>
                        <div class="text-sm">
                            (${completionStats.accepted_applications}/${completionStats.total_applications} applications)
                        </div>
                    </div>
                `;
                
                const ctx = document.getElementById('successRateChart').getContext('2d');
                new Chart(ctx, {
                    ...doughnutConfig,
                    data: {
                        labels: ['Accepted', 'Pending/Rejected'],
                        datasets: [{
                            data: [
                                completionStats.completion_percentage,
                                100 - completionStats.completion_percentage
                            ],
                            backgroundColor: ['#4BC0C0', '#FF6384']
                        }]
                    }
                });
            }
        })
        .catch(error => {
            console.error("Error fetching completion rate:", error);
            document.getElementById("completionRate").textContent = "Error loading data";
        });
        fetch("api/api.php?endpoint=job-market")
        .then(response => response.json())
        .then(data => {
            if (!data || data.length === 0) {
                console.error("No job market data found.");
                return;
            }
            const totalJobs = data.reduce((sum, item) => sum + Number(item.total_jobs), 0);
            document.getElementById("activeJobs").textContent = totalJobs;

            const labels = data.map(item => item.category_name);
            const values = data.map(item => item.total_jobs);
            new Chart(document.getElementById("activeJobsChart"), {
                type: "bar",
                data: { labels: labels, datasets: [{ label: "Active Jobs", data: values, backgroundColor: "#FF6B00" }] }
            });
        })
        .catch(error => console.error("Error fetching active jobs:", error));

});