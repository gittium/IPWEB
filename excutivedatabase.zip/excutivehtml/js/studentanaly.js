document.addEventListener("DOMContentLoaded", function () {
    console.log("Loading Student Performance Data...");

    // Fetch Active Students Count
    fetch("api/api.php?endpoint=active-students")
        .then(response => response.json())
        .then(data => {
            if (!data || data.length === 0) {
                console.error("No student data found.");
                return;
            }
            document.getElementById("activeStudents").textContent = data[0].active_students;

            new Chart(document.getElementById("activeStudentsChart"), {
                type: "bar",
                data: {
                    labels: ["Jan", "Feb", "Mar", "Apr", "May", "Jun"],
                    datasets: [{
                        label: "Active Students",
                        data: [100, 110, 115, 120, 125, 127],
                        backgroundColor: "#4B0082"
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: { position: "bottom" }
                    }
                }
            });
        })
        .catch(error => console.error("Error fetching active students:", error));

    // Fetch Student Ratings
    fetch("api/api.php?endpoint=student-performance")
        .then(response => response.json())
        .then(data => {
            console.log("API Response:", data); // Debugging Log
            if (!data || data.length === 0) {
                console.error("No student performance data found.");
                return;
            }

            // Update student rating count
            document.getElementById("studentRating").textContent = data.length;

             // Decode Unicode for student names
             const labels = data.map(item => decodeUnicode(item.name));
             const ratings = data.map(item => Number(item.avg_rating));

            // Update student rating count
            document.getElementById("studentRating").textContent = data.length;

            // Create Doughnut Chart for Student Ratings
            createDoughnutChart("studentRatingChart", labels, ratings, [
                "#4B0082", "#FF6B00", "#FFA726", "#FF7043", "#FF5722",
                "#66BB6A", "#26A69A", "#29B6F6", "#7E57C2", "#EC407A"
            ]);
        })
        .catch(error => console.error("Error fetching student performance data:", error));
});

// Function to Decode Unicode Characters
function decodeUnicode(str) {
    return str.replace(/\\u[\dA-Fa-f]{4}/g, function (match) {
        return String.fromCharCode(parseInt(match.replace("\\u", ""), 16));
    });
}


// Function to Create Doughnut Chart
// Function to Create Doughnut Chart
function createDoughnutChart(chartId, labels, values, colors) {
    let chartElement = document.getElementById(chartId);
    
    if (!chartElement) {
        console.error(`Chart element ${chartId} not found!`);
        return;
    }

    // Destroy only if the chart exists
    if (window[chartId] && typeof window[chartId].destroy === "function") {
        window[chartId].destroy();
    }

    window[chartId] = new Chart(chartElement, {
        type: "doughnut",
        data: {
            labels: labels,
            datasets: [{
                data: values,
                backgroundColor: colors.slice(0, values.length)
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            cutout: "70%",
            plugins: {
                legend: {
                    position: "bottom",
                    labels: { padding: 20, font: { size: 12 } }
                },
                title: {
                    display: true,
                    text: "Top 10 Student Ratings",
                    font: { size: 14, weight: "bold" }
                }
            }
        }
    });
}
