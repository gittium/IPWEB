document.addEventListener("DOMContentLoaded", function () {
    console.log("Loading Top 55 Dashboard Data...");

    // Fetch Students Performance Data
    fetch("api/api.php?endpoint=student-performance")
        .then(response => response.json())
        .then(data => {
            if (!data || data.length === 0) {
                console.error("No student performance data found.");
                return;
            }
            const labels = data.map(item => item.student_name);
            const values = data.map(item => item.completed_jobs);

            createChart("studentsChart", "bar", labels, values, "Job Completed", "#FF6B00");
        })
        .catch(error => console.error("Error fetching student performance:", error));

    // Fetch Professors Activity Data
    fetch("api/api.php?endpoint=top-professors")
        .then(response => response.json())
        .then(data => {
            if (!data || data.length === 0) {
                console.error("No professor activity data found.");
                return;
            }
            const labels = data.map(item => item.professor_name);
            const values = data.map(item => item.posted_jobs);

            createChart("professorsChart", "bar", labels, values, "Posted Jobs", "#4B0082");
        })
        .catch(error => console.error("Error fetching professor activity:", error));

    // Fetch Popular Jobs Data
    fetch("api/api.php?endpoint=job-market")
        .then(response => response.json())
        .then(data => {
            if (!data || data.length === 0) {
                console.error("No job market data found.");
                return;
            }
            const labels = data.map(item => item.category_name);
            const values = data.map(item => item.total_jobs);

            createChart("jobsChart", "doughnut", labels, values, "Popular Jobs Distribution", ["#FF6B00", "#4B0082", "#FFD700", "#C0C0C0", "#CD7F32"]);
        })
        .catch(error => console.error("Error fetching job market data:", error));
});

// Function to create and update charts
function createChart(chartId, type, labels, values, labelName, bgColor) {
    if (window[chartId]) {
        window[chartId].destroy();
    }
    window[chartId] = new Chart(document.getElementById(chartId), {
        type: type,
        data: {
            labels: labels,
            datasets: [{
                label: labelName,
                data: values,
                backgroundColor: Array.isArray(bgColor) ? bgColor : [bgColor]
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: { padding: 20, font: { size: 12 } }
                },
                title: {
                    display: type === "doughnut",
                    text: labelName,
                    font: { size: 16, weight: "bold" }
                }
            }
        }
    });
}

// Interactive Features
document.querySelectorAll(".ranking-item").forEach(item => {
    item.addEventListener("mouseover", () => {
        item.style.transform = "translateX(10px)";
    });
    item.addEventListener("mouseout", () => {
        item.style.transform = "translateX(0)";
    });
});

document.querySelectorAll(".ranking-card").forEach(card => {
    card.addEventListener("mouseover", () => {
        card.style.transform = "translateY(-5px)";
    });
    card.addEventListener("mouseout", () => {
        card.style.transform = "translateY(0)";
    });
});
