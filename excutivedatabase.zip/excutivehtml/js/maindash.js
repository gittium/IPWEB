document.addEventListener("DOMContentLoaded", function () {
    // Fetch Active Jobs Count
    fetch("api/api.php?endpoint=job-market")
        .then(response => response.json())
        .then(data => {
            if (!data || data.length === 0) {
                console.error("No job market data found.");
                return;
            }
            const totalJobs = data.reduce((sum, item) => sum + Number(item.total_jobs), 0);
            document.getElementById("activeJobs").textContent = totalJobs;

            const labels = data.map(item => item.category_name);
            const values = data.map(item => item.total_jobs);
            new Chart(document.getElementById("activeJobsChart"), {
                type: "bar",
                data: { labels: labels, datasets: [{ label: "Active Jobs", data: values, backgroundColor: "#FF6B00" }] }
            });
        })
        .catch(error => console.error("Error fetching active jobs:", error));

    // Fetch Registered Students Count
    fetch("api/api.php?endpoint=active-students")
        .then(response => response.json())
        .then(data => {
            document.getElementById("totalStudents").textContent = data[0].active_students;
        })
        .catch(error => console.error("Error fetching student count:", error));

    // Fetch Job Categories Distribution
    fetch("api/api.php?endpoint=job-market")
        .then(response => response.json())
        .then(data => {
            const labels = data.map(item => item.category_name);
            const values = data.map(item => item.total_jobs);
            new Chart(document.getElementById("jobCategoriesChart"), {
                type: "pie",
                data: { labels: labels, datasets: [{ data: values, backgroundColor: ["#FF6B00", "#4B0082", "#FFA726", "#66BB6A"] }] }
            });
        })
        .catch(error => console.error("Error fetching job categories:", error));

    // Fetch Applications Per Job
    fetch("api/api.php?endpoint=applications")
        .then(response => response.json())
        .then(data => {
            const labels = data.map(item => item.title);
            const values = data.map(item => item.total_applications);
            new Chart(document.getElementById("applicationsChart"), {
                type: "bar",
                data: { labels: labels, datasets: [{ label: "Applications", data: values, backgroundColor: "#4B0082" }] }
            });
        })
        .catch(error => console.error("Error fetching applications:", error));

    // Fetch Recent Activities
    fetch("api/api.php?endpoint=recent-activities")
        .then(response => response.json())
        .then(data => {
            const activityList = document.getElementById("recentActivitiesList");
            activityList.innerHTML = "";
            data.forEach(activity => {
                const listItem = document.createElement("li");
                listItem.textContent = `${activity.user_name} ${activity.activity_description}`;
                activityList.appendChild(listItem);
            });
        })
        .catch(error => console.error("Error fetching recent activities:", error));
});
