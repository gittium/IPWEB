document.addEventListener("DOMContentLoaded", function () {
    console.log("Loading Skills Analysis Data...");

    // Fetch Most Demanded Skills
    fetch("api/api.php?endpoint=most-demanded-skills")
        .then(response => response.json())
        .then(data => {
            if (!data || data.length === 0) {
                console.error("No demanded skills data found.");
                return;
            }
            const labels = data.map(item => item.skill_name);
            const values = data.map(item => item.demand_score);

            createChart("demandedSkillsChart", "bar", labels, values, "Demand Score", "#FF6B00");
        })
        .catch(error => console.error("Error fetching demanded skills:", error));

    // Fetch Skills Gap Analysis Data
    fetch("api/api.php?endpoint=skills-gap")
        .then(response => response.json())
        .then(data => {
            if (!data || data.length === 0) {
                console.error("No skills gap data found.");
                return;
            }
            const labels = data.map(item => item.skill_name);
            const requiredSkills = data.map(item => item.required_score);
            const studentSkills = data.map(item => item.current_score);

            createChart("skillsGapChart", "bar", labels, [requiredSkills, studentSkills], ["Required Skills", "Current Student Skills"], ["#4B0082", "#FF6B00"]);
        })
        .catch(error => console.error("Error fetching skills gap data:", error));

    // Fetch Skills Development Timeline
    fetch("api/api.php?endpoint=skills-timeline")
        .then(response => response.json())
        .then(data => {
            if (!data || data.length === 0) {
                console.error("No skills timeline data found.");
                return;
            }
            const labels = data.map(item => item.month);
            const webDev = data.map(item => item.web_development);
            const mobileDev = data.map(item => item.mobile_development);

            createChart("developmentTimeline", "line", labels, [webDev, mobileDev], ["Web Development", "Mobile Development"], ["#4B0082", "#FF6B00"]);
        })
        .catch(error => console.error("Error fetching skills timeline data:", error));
});

// Function to create and update charts
function createChart(chartId, type, labels, values, labelName, bgColor) {
    if (window[chartId]) {
        window[chartId].destroy();
    }
    window[chartId] = new Chart(document.getElementById(chartId), {
        type: type,
        data: {
            labels: labels,
            datasets: Array.isArray(values[0]) ? values.map((data, i) => ({
                label: labelName[i],
                data: data,
                backgroundColor: bgColor[i],
                borderRadius: 6
            })) : [{
                label: labelName,
                data: values,
                backgroundColor: bgColor,
                borderRadius: 6
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: { padding: 20, font: { size: 12 } }
                },
                title: {
                    display: type !== "line",
                    text: labelName,
                    font: { size: 14, weight: "bold" }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: { font: { size: 12 } },
                    grid: { color: "rgba(0, 0, 0, 0.1)" }
                },
                x: {
                    ticks: { font: { size: 12 } },
                    grid: { display: false }
                }
            }
        }
    });
}
