document.addEventListener("DOMContentLoaded", function () {
    console.log("Loading Professor Analytics...");

    // Fetch Active Professors Count
    fetch("api/api.php?endpoint=active-professors")
        .then(response => response.json())
        .then(data => {
            if (!data || data.length === 0) {
                console.error("No professor data found.");
                return;
            }
            document.getElementById("activeProfessors").textContent = data[0].active_professors;

            createChart("activeProfsChart", "line", ["Jan", "Feb", "Mar", "Apr", "May", "Jun"], 
                [12, 13, 14, 14, 15, 15], "Active Professors", "#FF6B00");
        })
        .catch(error => console.error("Error fetching active professors:", error));

    // Fetch Job Posts Count
    fetch("api/api.php?endpoint=job-posts")
        .then(response => response.json())
        .then(data => {
            if (!data || data.length === 0) {
                console.error("No job posts data found.");
                return;
            }
            document.getElementById("totalJobPosts").textContent = data[0].total_jobs;

            createChart("jobPostsChart", "bar", ["Jan", "Feb", "Mar", "Apr", "May", "Jun"], 
                [95, 102, 108, 115, 120, 124], "Total Job Posts", "#4B0082");
        })
        .catch(error => console.error("Error fetching job posts:", error));
});

// Function to Create Charts
function createChart(chartId, type, labels, values, labelName, bgColor) {
    if (window[chartId]) {
        window[chartId].destroy();
    }
    window[chartId] = new Chart(document.getElementById(chartId), {
        type: type,
        data: {
            labels: labels,
            datasets: [{
                label: labelName,
                data: values,
                backgroundColor: bgColor
            }]
        }
    });
}
