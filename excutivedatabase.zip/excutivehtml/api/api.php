<?php
// Database connection configuration
header('Content-Type: application/json');
$servername = "db";  
$username = "laravel";
$password = "laravel";
$database = "jobportal_db";

$conn = new mysqli($servername, $username, $password, $database);
if ($conn->connect_error) {
    die(json_encode(["error" => "Database connection failed"]));
}

// API Endpoints Implementation
$endpoint = $_GET['endpoint'] ?? '';

switch ($endpoint) {
    case 'job-market':
        $sql = "SELECT category_name, COUNT(*) AS total_jobs FROM job_categories GROUP BY category_name";
        break;
    case 'applications':
        $sql = "SELECT p.title, COUNT(a.id) AS total_applications FROM job_applications a LEFT JOIN post_jobs p ON a.post_jobs_id = p.id GROUP BY p.title";
        break;
    case 'top-skills':
        $sql = "SELECT reward_name, COUNT(*) AS demand_count FROM reward_type GROUP BY reward_name ORDER BY demand_count DESC LIMIT 10";
        break;
    case 'student-applications':
        $sql = "SELECT job_status_name, COUNT(*) AS total FROM job_status GROUP BY job_status_name";
        break;
    case 'active-professors':
        $sql = "SELECT COUNT(*) AS active_professors FROM teachers";
        break;
    case 'top-professors':
        $sql = "SELECT t.name, COUNT(p.id) AS job_count FROM teachers t LEFT JOIN post_jobs p ON t.id = p.teacher_id GROUP BY t.name ORDER BY job_count DESC LIMIT 5";
        break;
    case 'active-students':
        $sql = "SELECT COUNT(*) AS active_students FROM students";
        break;
    case 'student-performance':
        $sql = "SELECT s.name, AVG(r.rating) AS avg_rating FROM students s LEFT JOIN reviews r ON s.id = r.student_id GROUP BY s.name ORDER BY avg_rating DESC LIMIT 10";
        break;
    case 'top-jobs':
        $sql = "SELECT p.title, COUNT(a.id) AS total_applications FROM job_applications a LEFT JOIN post_jobs p ON a.post_jobs_id = p.id GROUP BY p.title ORDER BY total_applications DESC LIMIT 5";
        break;
    case 'job-posts':
        $sql = "SELECT category_name, COUNT(*) AS total_jobs FROM job_categories GROUP BY category_name";
        break;
    // Add these cases to your existing switch statement in api.php

    case 'job-categories-stats':
    // Get job distribution by categories
    $sql = "SELECT 
        jc.category_name,
        COUNT(pj.id) as total_jobs,
        ROUND((COUNT(pj.id) * 100.0) / NULLIF((SELECT COUNT(*) FROM post_jobs WHERE job_status_id != 3), 0), 1) as percentage
    FROM job_categories jc
    LEFT JOIN post_jobs pj ON jc.id = pj.category_id AND pj.job_status_id != 3
    GROUP BY jc.id, jc.category_name
    ORDER BY total_jobs DESC";
    break;

    case 'job-status-stats':
    // Get job distribution by status (open/close/delete)
    $sql = "SELECT 
        js.job_status_name,
        COUNT(pj.id) as total_jobs,
        ROUND((COUNT(pj.id) * 100.0) / (SELECT COUNT(*) FROM post_jobs), 1) as percentage
    FROM job_status js
    LEFT JOIN post_jobs pj ON js.id = pj.job_status_id
    GROUP BY js.id, js.job_status_name
    ORDER BY js.id";
    break;

    case 'reward-type-stats':
    // Get job distribution by reward type
    $sql = "SELECT 
        rt.reward_name,
        COUNT(pj.id) as total_jobs,
        ROUND((COUNT(pj.id) * 100.0) / NULLIF((SELECT COUNT(*) FROM post_jobs WHERE job_status_id != 3), 0), 1) as percentage
    FROM reward_type rt
    LEFT JOIN post_jobs pj ON rt.id = pj.reward_id AND pj.job_status_id != 3
    GROUP BY rt.id, rt.reward_name
    ORDER BY rt.id";
    break;
    case 'pay-rate':
        // Calculate statistics for jobs with monetary rewards (reward_id = 1 for money)
        $sql = "SELECT 
            COUNT(*) as total_jobs,
            ROUND(COUNT(CASE WHEN reward_id = 1 THEN 1 END) * 100.0 / COUNT(*), 2) as money_percentage,
            ROUND(COUNT(CASE WHEN reward_id = 2 THEN 1 END) * 100.0 / COUNT(*), 2) as experience_percentage
        FROM post_jobs 
        WHERE job_status_id != 3"; // Excluding deleted jobs
        break;
    
    case 'completion-rate':
        // Calculate completion rate based on accepted applications vs total applications
        $sql = "SELECT 
            COUNT(DISTINCT ja.id) as total_applications,
            COUNT(DISTINCT CASE WHEN aa.accept_status_id = 1 THEN aa.id END) as accepted_applications,
            ROUND(COUNT(DISTINCT CASE WHEN aa.accept_status_id = 1 THEN aa.id END) * 100.0 / 
                NULLIF(COUNT(DISTINCT ja.id), 0), 2) as completion_percentage
        FROM job_applications ja
        LEFT JOIN accepted_applications aa ON ja.id = aa.job_application_id";
        break;
    default:
        echo json_encode(["error" => "Invalid API endpoint"]);
        exit;
}

$result = $conn->query($sql);
$data = [];
while ($row = $result->fetch_assoc()) {
    $data[] = $row;
}

echo json_encode($data);
$conn->close();
