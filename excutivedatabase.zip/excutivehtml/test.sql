USE jobportal_db;

SELECT * FROM job_categories;