<?php

session_start();
include 'database.php'; // Include database connection

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  

    $id = $_POST['id']; // Get ID from the form
    $password = $_POST['password'];

    if (!$conn) {
        die("Database connection failed: " . mysqli_connect_error());
    }

    $query = "SELECT id, password, role_id FROM users WHERE id = ? LIMIT 1";
    $stmt = $conn->prepare($query);
    if (!$stmt) {
        die("SQL Error: " . $conn->error);
    }

    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();



    if ($user && $password === $user['password']) {
        $_SESSION['id'] = $user['id'];
        $_SESSION['role_id'] = $user['role_id'];

      

        header('Location: hometest.php');
        exit();
    } else {
        echo "<script>alert('Invalid Username or Password');</script>";
    }
}
?>




<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login | StepIntoCSIT</title>
    <link rel="stylesheet" href="css/login.css">
</head>

<body>
    <div class="container">
        <h1 class="title">เข้าสู่ระบบ</h1>
        <div class="login-box">
        <form method="POST" action="">
            <input type="text" placeholder="Username" name="id" required>
            <input type="password" placeholder="Password" name="password" required>
            <button type="submit">Login</button>
        </form>

        </div>
    </div>
</body>

</html>