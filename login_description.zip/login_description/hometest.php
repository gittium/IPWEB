<?php 
session_start();
include 'database.php';

// Check if the user is logged in and get their role_id
$role_id = isset($_SESSION['role_id']) ? $_SESSION['role_id'] : null;

$sql = "SELECT post_jobs.id, post_jobs.job_status_id, post_jobs.title, post_jobs.image, job_categories.category_name AS category, teachers.name AS teacher
        FROM post_jobs 
        JOIN teachers ON post_jobs.teacher_id = teachers.id
        JOIN job_categories ON post_jobs.category_id = job_categories.id
        ORDER BY job_categories.id";

$result = $conn->query($sql);
$jobs = [];
while ($row = $result->fetch_assoc()) {
    $jobs[$row["category"]][] = $row;
}
?>

<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CSIT Job Board</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <link rel="stylesheet" href="css/header-footerstyle.css">
    <link rel="stylesheet" href="css/styles.css">
    <link rel="stylesheet" href="css/navbar.css">
    <link rel="stylesheet" href="css/filter.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <header class="headerTop">
        <div class="headerTopImg">
            <img src="logo.png" alt="Naresuan University Logo">
            <a>Naresuan University</a>
        </div>
        <nav class="header-nav">
            <?php if ($role_id == 3): // Only show "Create Job" button for teachers ?>
                <a href="jobpost.php"><button type="button" class="btn btn-warning">สร้างประกาศงาน</button></a>
            <?php endif; ?>
            
            <!-- Redirect Profile Button to the Correct Profile Page -->
            <?php if ($role_id == 3): ?>
                <a href="TeacherProfile.html"><button type="button" class="btn btn-info">Profile</button></a>
            <?php elseif ($role_id == 4): ?>
                <a href="stupf.html"><button type="button" class="btn btn-info">Profile</button></a>
            <?php endif; ?>

            <a href="login.php"><button type="button" class="btn btn-danger">Logout</button></a>
        </nav>
    </header>

    <div id="navbar-placeholder"></div>
    <div id="filter-placeholder"></div>
    <div id="contentWrapper" class="content-wrapper"></div>
    <main class="main-content">
        <?php
        foreach ($jobs as $category => $jobList) {
            echo '<div class="section-title">
                <h2>' . htmlspecialchars($category) . '</h2>
                <a href="view_all_jobs.php?category=' . urlencode($category) . '" class="see-all-btn">See All</a>
            </div>';
        
            $filteredJobs = array_filter($jobList, function ($job) {
                return $job['job_status_id'] == 1;
            });

            if (empty($filteredJobs)) {
                echo '<p class="no-jobs">ไม่มีการประกาศงานประเภทนี้</p>';
            } else {
                echo '<div class="job-grid">';
                $count = 0;
                foreach ($filteredJobs as $job) {
                    if ($count >= 4) break;
                    echo '<a href="joinustest.php?id=' . htmlspecialchars($job['id']) . '&ip=' . $_SERVER['REMOTE_ADDR'] . '">
                        <div class="job-card">
                            <img class="job-image" src="' . htmlspecialchars($job['image'])  . '" alt="Job Image">
                            <div class="job-info">
                                <div class="job-title">' . htmlspecialchars($job["title"]) . '</div>
                                <div class="job-author">' . htmlspecialchars($job["teacher"]) . '</div>
                            </div>
                        </div>
                    </a>';
                    $count++;
                }
                echo '</div>';
            }
        }
        ?>
    </main>

    <footer class="footer">
        <p>© CSIT - Computer Science and Information Technology</p>
    </footer>

    <script src="js/main.js"></script>
    <script src="js/navbar.js"></script>
    <script src="js/filter.js"></script>
</body>
</html>

<?php $conn->close(); ?>
