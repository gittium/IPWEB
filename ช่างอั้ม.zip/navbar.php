<!-- components/navbar.html -->
<nav class="navbar">
  <div class="nav-container">
      <a href="hometest.php" class="nav-item">
          <i class="bi bi-house"></i>
          <span>Home</span>
      </a>
      <a href="view_all_jobs.php?category_id=1" class="nav-item">
          <i class="bi bi-person"></i>
          <span>Teaching Assistant</span>
      </a>
      <a href="view_all_jobs.php?category_id=6" class="nav-item">
          <i class="bi bi-people"></i>
          <span>Research Assistant</span>
      </a>
      <a href="view_all_jobs.php?category_id=5" class="nav-item">
          <i class="bi bi-laptop"></i>
          <span>Web Development</span>
      </a>
      <a href="view_all_jobs.php?category_id=7" class="nav-item">
          <i class="bi bi-pencil"></i>
          <span>Graphic Design</span>
      </a>
      <a href="#" class="nav-item" id="otherNavItem">
          <i>•••</i>
          <span>Other</span>
      </a>
  </div>
</nav>

<!-- Expanded Navbar -->
<div class="nav-expanded" id="expandedNav">
  <div class="expanded-container">
      <a href="view_all_jobs.php?category_id=11" class="expanded-item"><i class="bi bi-window-dock"></i><br><br>UX/UI</a>
      <a href="view_all_jobs.php?category_id=8" class="expanded-item"><i class="bi bi-bar-chart"></i><br><br>Data Science & AI</a>
      <a href="view_all_jobs.php?category_id=9" class="expanded-item"><i class="bi bi-browser-chrome"></i><br><br>Website Scraping</a>
      <a href="view_all_jobs.php?category_id=3" class="expanded-item"><i class="bi bi-controller"></i><br><br>Game Development</a>
      <a href="view_all_jobs.php?category_id=12" class="expanded-item"><i class="bi bi-robot"></i><br><br>IoT Project</a>
      <a href="view_all_jobs.php?category_id=13" class="expanded-item"><i class="bi bi-wrench"></i><br><br>IT Solution and Support</a>
      <a href="view_all_jobs.php?category_id=10" class="expanded-item"><i class="bi bi-pc-display"></i><br><br>Desktop Application</a>
      <a href="view_all_jobs.php?category_id=2" class="expanded-item"><i class="bi bi-phone"></i><br><br>Mobile Application</a>
      <a href="view_all_jobs.php?category_id=4" class="expanded-item"><i class="bi bi-chat-right-text"></i><br><br>Chatbot</a>
      <a href="view_all_jobs.php?category_id=15" class="expanded-item"><i class="bi bi-file-earmark-bar-graph"></i><br><br>Data Engineering</a>
      <a href="view_all_jobs.php?category_id=14" class="expanded-item"><i class="bi bi-database-fill"></i><br><br>Data Labelling</a>
      <a href="view_all_jobs.php?category_id=16" class="expanded-item"><i class="bi bi-wordpress"></i><br><br>Wordpress</a>
      <a href="view_all_jobs.php?category_id=17" class="expanded-item"><i class="bi bi-search"></i><br><br>Quality Assurance</a>
  </div>
</div>
