// components/navbar.js

// Ensure the namespace exists
var CSITJobBoard = CSITJobBoard || {};

// Navbar Module
CSITJobBoard.Navbar = (function() {
    // Private functions

    function toggleExpanded(event) {
        event.preventDefault();
        var expandedNav = document.getElementById('expandedNav');
        if (expandedNav) {
            expandedNav.classList.toggle('show');
        }
    }

    // Public API
    return {
        init: function() {
            var otherNavItem = document.getElementById('otherNavItem');
            if (otherNavItem) {
                otherNavItem.addEventListener('click', toggleExpanded);
            }
        }
    };
})();
