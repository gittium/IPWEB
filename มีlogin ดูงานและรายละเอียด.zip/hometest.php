<?php include 'database.php';
$sql = "SELECT post_jobs.id,post_jobs.job_status_id , post_jobs.title,post_jobs.image,job_categories.category_name AS category, teachers.name AS teacher
FROM post_jobs 
JOIN teachers ON post_jobs.teacher_id = teachers.id
JOIN job_categories ON post_jobs.category_id = job_categories.id
ORDER BY job_categories.id";

$result = $conn->query($sql);
// จัดกลุ่มข้อมูลตามหมวดหมู่
$jobs = [];
while ($row = $result->fetch_assoc()) {
    $jobs[$row["category"]][] = $row;
}

?>
<!-- index.html -->
<!DOCTYPE html>
<html lang="th">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CSIT Job Board</title>
    <!-- Bootstrap Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <!-- External CSS -->
    <link rel="stylesheet" href="css/header-footerstyle.css">
    <link rel="stylesheet" href="css/styles.css">
    <link rel="stylesheet" href="css/navbar.css">
    <link rel="stylesheet" href="css/filter.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
</head>

<body>
    <!-- Header -->
    <header class="headerTop">
        <div class="headerTopImg">
            <img src="logo.png" alt="Naresuan University Logo">
            <a>Naresuan University</a>
        </div>
        <nav class="header-nav">
            <a href="/meen final/stupf.html"><button type="button" class="btn btn-info">Profile</button></a>

            <a href="#"><button type="button" class="btn btn-danger">Logout</button></a>
        </nav>
    </header>

    <!-- Navbar Placeholder -->
    <div id="navbar-placeholder"></div>

    <!-- Filter Placeholder -->
    <div id="filter-placeholder"></div>


    <div id="contentWrapper" class="content-wrapper"></div>
    <main class="main-content">
    <?php
    foreach ($jobs as $category => $jobList) {
        echo '<div class="section-title">
            <h2>' . htmlspecialchars($category) . '</h2>
            <a href="view_all_jobs.php?category=' . urlencode($category) . '" class="see-all-btn">See All</a>
        </div>';
    
        // กรองเฉพาะงานที่ job_status_id เป็น 1
        $filteredJobs = array_filter($jobList, function ($job) {
            return $job['job_status_id'] == 1;
        });

        if (empty($filteredJobs)) {
            echo '<p class="no-jobs">ไม่มีการประกาศงานประเภทนี้</p>';
        } else {
            echo '<div class="job-grid">';
            $count = 0;
            foreach ($filteredJobs as $job) {
                if ($count >= 4) break;
                echo '<a href="joinustest.php?id=' . htmlspecialchars($job['id']) . '&ip=' . $_SERVER['REMOTE_ADDR'] . '">
                    <div class="job-card">
                        <img class="job-image" src="' . htmlspecialchars($job['image'])  . '" alt="Job Image">
                        <div class="job-info">
                            <div class="job-title">' . htmlspecialchars($job["title"]) . '</div>
                            <div class="job-author">' . htmlspecialchars($job["teacher"]) . '</div>
                        </div>
                    </div>
                </a>';
                $count++;
            }
            echo '</div>';
        }
    }
    ?>
</main>


    <footer class="footer">
        <p>© CSIT - Computer Science and Information Technology</p>
    </footer>

    <!-- External JS -->
    <script src="js/main.js"></script>
    <script src="js/navbar.js"></script>
    <script src="js/filter.js"></script>
</body>

</html>


<?php
$conn->close();
?>