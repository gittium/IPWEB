<?php
include 'database.php'; // เชื่อมต่อฐานข้อมูล

// ดึง job_id จาก URL
$job_id = isset($_GET['job_id']) ? intval($_GET['job_id']) : 0;

// ดึง major_id จาก URL (ถ้ามี)
$major_id = isset($_GET['major']) ? intval($_GET['major']) : 0;

// ดึงข้อมูลนิสิตที่สมัครงานในโพสต์นั้นๆ
if ($job_id > 0) {
    $sqlApplicants = "SELECT students.id, students.name, students.major_id, students.year 
                      FROM job_applications 
                      JOIN students ON job_applications.student_id = students.id 
                      WHERE job_applications.post_jobs_id = ?";
    
    // เพิ่มเงื่อนไขกรองตาม major_id (ถ้ามี)
    if ($major_id > 0) {
        $sqlApplicants .= " AND students.major_id = ?";
    }

    $stmtApplicants = $conn->prepare($sqlApplicants);
    
    if ($major_id > 0) {
        $stmtApplicants->bind_param("ii", $job_id, $major_id);
    } else {
        $stmtApplicants->bind_param("i", $job_id);
    }

    $stmtApplicants->execute();
    $resultApplicants = $stmtApplicants->get_result();
    $applicants = [];
    while ($row = $resultApplicants->fetch_assoc()) {
        $applicants[] = $row;
    }
    $stmtApplicants->close();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Teaching Assistant View Applications Page">
    <title>Teaching Assistant Applications</title>
    <!-- Google Fonts -->
    <link
        href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&family=Montserrat:wght@600&display=swap"
        rel="stylesheet">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <link rel="stylesheet" href="viewapply.css">
    <link rel="stylesheet" href="header-footerstyle.css">

</head>

<body>
    <!-- Header -->
    <header class="headerTop">
        <div class="headerTopImg">
            <img src="logo.png" alt="Naresuan University Logo">
            <a href="#">Naresuan University</a>
        </div>
        <nav class="header-nav">
            <a href="#">About Us</a>
            <a href="#">News</a>
            <a href="#">Logout</a>
        </nav>
    </header>

    <!-- ปุ่ม back -->
    <div>
        <a href="teacher_profile.php" class="back-arrow"></a>
    </div>

    <!-- Main Content -->
    <div class="container">
        <div class="title-container">
            <a href="#">View Applications</a> <!-- เพิ่ม href ที่นี่ -->
            <a href="#">Manage Job</a> <!-- เพิ่ม href ที่นี่ -->
        </div>
        <br>
        <div>
            <h1>Teaching Assistant</h1>
        </div>
        <br>
        <div class="bar">
            <a href="javascript:void(0)" onclick="filterApplicants()">ทั้งหมด</a>
            <a href="javascript:void(0)" onclick="filterApplicants(1)">วิทยาการคอมพิวเตอร์</a>
            <a href="javascript:void(0)" onclick="filterApplicants(2)">เทคโนโลยีสารสนเทศ</a>
            <!-- เพิ่มปุ่มฟิลเตอร์ -->
            <i class="bi bi-filter ms-auto" id="filter-btn" style="cursor: pointer;"></i>
        </div>

            <!-- ซ่อนข้อความ -->
            <div id="hidden-message" class="message-box">
                สาขา<br>
                <button class="branch-btn" data-major="1">วิทยาการคอมพิวเตอร์</button>
                <button class="branch-btn" data-major="2">เทคโนโลยีสารสนเทศ</button>

                <br><br>
                <p>ชั้นปี</p>
                <button class="year-btn" data-year="1">ปี 1</button>
                <button class="year-btn" data-year="2">ปี 2</button>
                <button class="year-btn" data-year="3">ปี 3</button>
                <button class="year-btn" data-year="4">ปี 4</button>

                <br><br>
                <button id="clear-btn">ล้าง</button>
                <button id="apply-btn">ตกลง</button>
            </div>

        </div>

        <div class="application-list">
            <?php if (!empty($applicants)): ?>
                <?php foreach ($applicants as $index => $applicant): ?>
                    <div class="application-card">
                        <div class="number"><?php echo $index + 1; ?></div>
                        <div class="profile-img"></div>
                        <div class="details">
                            <div class="name"><?php echo htmlspecialchars($applicant['name'], ENT_QUOTES, 'UTF-8'); ?></div>
                            <div class="department">สาขา <?php echo ($applicant['major_id'] == 1) ? 'วิทยาการคอมพิวเตอร์' : 'เทคโนโลยีสารสนเทศ'; ?></div>
                            <div class="year">ปี <?php echo $applicant['year']; ?></div>
                        </div>
                        <a href="viewapply2.php" class="chevron-link">
                            <i class="bi bi-chevron-right"></i>
                        </a>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <p>ไม่มีนิสิตที่สมัครงานในโพสต์นี้</p>
            <?php endif; ?>
        </div>

    
    </div> 

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-..." crossorigin="anonymous"></script>
       
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-..." crossorigin="anonymous"></script>

    <script src="viewapply.js"></script>

    <!-- Footer -->
    <footer class="footer">
        <p>© CSIT - Computer Science and Information Technology</p>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
