function filterApplicants(majorId) {
    const url = new URL(window.location.href);
    if (majorId) {
        url.searchParams.set('major', majorId); // เพิ่มพารามิเตอร์ major
    } else {
        url.searchParams.delete('major'); // ลบพารามิเตอร์ major ถ้าไม่มีการเลือกสาขา
    }
    window.location.href = url.toString(); // เปลี่ยน URL และรีเฟรชหน้าเว็บ
}

document.addEventListener('DOMContentLoaded', () => {
    let selectedMajor = ""; // เก็บค่าที่เลือกของสาขา
    let selectedYear = "";  // เก็บค่าที่เลือกของชั้นปี

    // เลือกปุ่มฟิลเตอร์โดยใช้ ID
    document.getElementById('filter-btn').addEventListener('click', function () {
        const message = document.getElementById('hidden-message');
        if (message.style.display === 'none' || message.style.display === '') {
            message.style.display = 'block'; // แสดงกรอบข้อความ
        } else {
            message.style.display = 'none'; // ซ่อนกรอบข้อความ
        }
    });

    // จัดการปุ่มสาขา
    const branchButtons = document.querySelectorAll('.branch-btn');
    branchButtons.forEach(button => {
        button.addEventListener('click', () => {
            branchButtons.forEach(btn => btn.classList.remove('active'));
            button.classList.add('active');
            selectedMajor = button.getAttribute("data-major");
        });
    });

    // จัดการปุ่มชั้นปี
    const yearButtons = document.querySelectorAll('.year-btn');
    yearButtons.forEach(button => {
        button.addEventListener('click', () => {
            yearButtons.forEach(btn => btn.classList.remove('active'));
            button.classList.add('active');
            selectedYear = button.getAttribute("data-year");
        });
    });

    // ปุ่ม Clear
    document.getElementById('clear-btn').addEventListener('click', () => {
        branchButtons.forEach(btn => btn.classList.remove('active'));
        yearButtons.forEach(btn => btn.classList.remove('active'));
        selectedMajor = "";
        selectedYear = "";
    });

    // ปุ่มตกลง
    document.getElementById('apply-btn').addEventListener('click', () => {
        if (selectedMajor && selectedYear) {
            window.location.href = `viewapply.php?major=${selectedMajor}&year=${selectedYear}`;
        } else {
            alert("กรุณาเลือกสาขาและชั้นปี");
        }
    });
});




//เส้นใต้ตรงแถบ bar ค้างอยู่
document.addEventListener("DOMContentLoaded", function() {
    const links = document.querySelectorAll(".bar a");

    links.forEach(link => {
        link.addEventListener("click", function() {
            // ลบคลาส active จากทุกลิงก์ก่อน
            links.forEach(el => el.classList.remove("active"));

            // เพิ่มคลาส active ให้ลิงก์ที่ถูกคลิก
            this.classList.add("active");
        });
    });
});