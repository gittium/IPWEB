<?php
session_start();
include 'database.php';
$_SESSION['teacher_id'] = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : 'CSIT0131';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    date_default_timezone_set('Asia/Bangkok'); // ตั้งค่า Timezone เป็นเวลาประเทศไทย
    $created_at = date('Y-m-d H:i:s');
    // รับค่าจากฟอร์ม (แก้ไขให้ตรงกัน)
    $title = $_POST['title'] ?? null;
    $description = $_POST['description'] ?? null;
    $post_job_skill = isset($_POST['skill_id']) ? $_POST['subskill_id'] : [];  // รับค่าทักษะที่เลือกจากฟอร์ม
    $start = $_POST['job_start'] ?? date('Y-m-d H:i:s');
    $end = $_POST['job_end'] ?? date('Y-m-d H:i:s');
    $number_student = isset($_POST['number_student']) && is_numeric($_POST['number_student']) ? intval($_POST['number_student']) : null;
    $reward_type_id = $_POST['reward_type_id'] ?? null;
    $time_and_wage = $_POST['time_and_wage'] ?? null;
    $category_id = $_POST['job_category_id'] ?? null;
    $subcategory_id = $_POST['job_subcategory_id'] ?? null;
    $job_status_id = 1;
    $teacher_id = $_SESSION['teacher_id'];
    $images = $_POST['image'] ?? null;
    $skill_id = $_POST['post_job__id'] ?? null; // จาก select skill หลัก
    $subskill_id = $_POST['subskill_id'] ?? null; // จาก select subskill

    // ตรวจสอบค่าที่จำเป็นก่อนบันทึก
    if (!$title || !$reward_type_id || !$number_student ) {
        echo "<script>alert('Error: Missing required fields.'); window.history.back();</script>";
        exit;
    }

    $post_job_skill = implode(",", $post_job_skill);  // แปลงเป็น string แบบ comma-separated

    // บันทึกข้อมูล
    // ใช้ Prepared Statement ป้องกัน SQL Injection
    $stmt = $conn->prepare("INSERT INTO post_job
    (title, reward_type_id, description, job_start, job_end, number_student, time_and_wage, job_category_id, job_subcategory_id, teacher_id, created_at, job_status_id, image) 
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

    $stmt->bind_param(
        "sisssiiiissis",  // แก้ไขเป็น string, int, string, string, int, int, int, int, string
        $title,
        $reward_type_id,
        $description,   
        $start,
        $end,
        $number_student,
        $time_and_wage,
        $category_id,
        $subcategory_id,
        $teacher_id,
        $created_at,
        $job_status_id,
        $images

    );

    if ($stmt->execute()) {
        $post_job_id = $conn->insert_id;

        // บันทึก skill
        if ($skill_id) {
            $stmtSkill = $conn->prepare("INSERT INTO post_job_skill (post_job_id, skill_id, subskill_id) VALUES (?, ?, ?)");
            $stmtSkill->bind_param("iii", $post_job_id, $skill_id, $subskill_id);
            $stmtSkill->execute();
            $stmtSkill->close();
        }

        echo "<script>alert('New job posted successfully'); window.location='teacher_profile.php';</script>";
    } else {
        echo "<script>alert('Error: {$stmt->error}'); window.history.back();</script>";
    }

    $stmt->close();

    // ตรวจสอบว่าเวลาสิ้นสุดมากกว่าเวลาเริ่มต้นหรือไม่
    if ($start && $end && $end <= $start) {
        echo "<script>alert('Error: เวลาสิ้นสุดต้องมากกว่าเวลาเริ่มต้น!'); window.history.back();</script>";
        exit;
    }

    // ตรวจสอบว่ากรอกค่าผลตอบแทนหรือไม่
    if ($rewardTypeId && !$time_and_wage) {
        echo "<script>alert('Error: กรุณากรอกค่าผลตอบแทน!'); window.history.back();</script>";
        exit;
    }

    // ตรวจสอบค่าที่กรอกให้ตรงกับประเภท
    if ($reward_type_id == "1" && (!is_numeric($time_and_wage) || $time_and_wage <= 0)) {
        echo "<script>alert('Error: กรุณากรอกจำนวนเงินที่ถูกต้อง!'); window.history.back();</script>";
        exit;
    } elseif ($reward_type_id == "2" && (!is_numeric($time_and_wage) || $time_and_wage <= 0)) {
        echo "<script>alert('Error: กรุณากรอกจำนวนชั่วโมงที่ถูกต้อง!'); window.history.back();</script>";
        exit;
    }
    
    

    $conn->close();
}



?>

<!DOCTYPE html>
<html lang="th">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Job Posting Form</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/jobpose.css">
    <link rel="stylesheet" href="css/header-footerstyle.css">
</head>
<style>
    .skills-container {
        width: 100%; /* ขนาดเต็มพื้นที่ */
        max-width: 800px; /* กำหนดความกว้างสูงสุด */
        max-height: 400px; /* กำหนดความสูงสูงสุดของกล่อง */
        border: 1px solid #E2E8F0;
        border-radius: 8px; /* มุมโค้ง */
        padding: 15px 28px;
        background: #fff;
        overflow-y: auto; /* ให้มีแถบเลื่อนแนวตั้ง */
        overflow-x: hidden; /* ป้องกันการเลื่อนแนวนอน */
        margin-bottom: 20px;
        }

    /* ปรับให้ Checkbox ไม่ชิดกันเกินไป */
    .form-check {
        padding: 5px;
    }

    .skills-container::-webkit-scrollbar {
        width: 8px;
    }

    .skills-container::-webkit-scrollbar-thumb {
        background: #888;
        border-radius: 4px;
    }

    .skills-container::-webkit-scrollbar-thumb:hover {
        background: #555;
    }


</style>

<body>
    <!-- Header -->
    <header class="headerTop">
        <div class="headerTopImg">
            <img src="logo.png" alt="Naresuan University Logo">
            <a href="#">Naresuan University</a>
        </div>
        <nav class="header-nav">
            <a href="#">About Us</a>
            <a href="#">News</a>
            <a href="#">Logout</a>
        </nav>
    </header>

    <!--เครื่องหมายย้อนกลับ-->
    <nav class="back-head">
        <a href="javascript:history.back()"> <i class="bi bi-chevron-left"></i></a>

    </nav>
    <!-- Main Content -->
    <main class="container">

        <!--ส่วนfromต่างๆ-->
        <div class="form-card">
            <h1 class="form-title">Job Posting</h1>
            <?php echo "DEBUG: teacher_id = " . $_SESSION['teacher_id']; ?>
            <form method="POST" action="jobpost.php">
                <!--ชื่องาน-->
                <div class="form-group">
                    <label class="form-label">Job Name/ชื่องาน</label>
                    <input type="text" class="form-input" name="title" required>
                </div>


                <!--ประเภทสกิล-->
                <?php
                $post_job_skill = [];
                $sql = "SELECT skill_id, skill_name 
                            FROM skill
                            ORDER BY skill.skill_id";
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        $post_job_skill[] = $row;
                    }
                }
                ?>
                <div class="form-group">
                    <label class="form-label">Skill Required / ทักษะที่ต้องการ</label>
                    <select class="form-select" name="post_job__id" id="skill-select" required>
                        <option value="">-- เลือกประเภทสกิล --</option>
                        <?php foreach ($post_job_skill as $skill) : ?>
                            <option value="<?php echo $skill['skill_id']; ?>">
                                <?php echo htmlspecialchars($skill['skill_name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>


                
                <div class="form-group" id="skill-sub-container" style="display: none;">
                    <label class="form-label">Subskill/สกิลย่อย</label>
                    <select class="form-select" name="subskill_id" id="sub-skill-select" required>
                        <option value="">-- เลือกสกิลย่อย --</option>
                        
                    </select>
                </div>




                <!--ประเภทงาน-->
                <?php
                $categories = [];
                $sql = "SELECT job_category_id, job_category_name 
                            FROM job_category
                            ORDER BY job_category.job_category_id";
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        $categories[] = $row;
                    }
                }
                ?>
                <div class="form-group">
                    <label class="form-label">Job Category/ประเภทงาน</label>
                    <select class="form-select" name="job_category_id" id="category-select" required>
                        <option value="">-- เลือกประเภทงาน --</option>
                        <?php foreach ($categories as $category_id) : ?>
                            <option value="<?php echo $category_id['job_category_id']; ?>">
                                <?php echo htmlspecialchars($category_id['job_category_name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>


                <!-- Dropdown สำหรับ Job Sub -->
                <div class="form-group" id="job-sub-container" style="display: none;">
                    <label class="form-label">Job Subcategory/งานย่อย</label>
                    <select class="form-select" name="job_subcategory_id" id="job-sub-select" required>
                        <option value="">-- เลือกงานย่อย --</option>
                        
                    </select>
                </div>

                <!--จำนวนนิสิตที่รับ-->
                <div class="form-group">
                    <label class="form-label">Student Count Required/จำนวนตำแหน่งที่ต้องการ</label>
                    <input type="number" id="vacancy" name="number_student" placeholder="" min="1">
                </div>

                <!--วันเริ่มงานกับจบงาน-->
                <div class="form-group">
                    <label class="form-label">Start Date & Time/เวลาเริ่มงาน</label>
                    <input type="datetime-local" class="form-input" name="job_start" id="job-start" required>
                </div>

                <div class="form-group">
                    <label class="form-label">End Date & Time/เวลาสิ้นสุดงาน</label>
                    <input type="datetime-local" class="form-input" name="job_end" id="job-end" required>
                </div>


                <div class="form-group">
                    <label class="form-label">Cover photo/ภาพหน้าปกงาน</label>
                    <div class="images">
                        <img src="images/img1.jpg" alt="Image 1" onclick="selectImage(this)">
                        <img src="images/img2.jpg" alt="Image 2" onclick="selectImage(this)">
                        <input type="hidden" name="image" id="selectedImagePath">
                    </div>
                </div>



                <!--ผลตอบแทน-->
                <?php
                $reward = [];
                $sql = "SELECT reward_type_id, reward_type_name 
                            FROM reward_type
                            ORDER BY reward_type.reward_type_id";
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        $reward[] = $row;
                    }
                }
                ?>

                <div class="form-group">
                    <label class="form-label">Job Category/ผลตอบแทน</label>
                    <select class="form-select" name="reward_type_id" id="reward-type-select"  required>
                        <option value="">-- เลือกประเภทผลตอบแทน --</option>
                        <?php foreach ($reward as $reward_type) : ?>
                            <option value="<?php echo $reward_type['reward_type_id']; ?>">
                                <?php echo htmlspecialchars($reward_type['reward_type_name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <!-- ช่องสำหรับกรอกค่าตามประเภท -->
                <div class="form-group" id="reward-input-container" style="display: none;">
                    <label class="form-label" id="reward-label">
                        <span id="reward-label-text"></span> <span id="reward-unit"></span>
                    </label>
                    <input type="number" class="form-input" name="time_and_wage" id="reward-input" min="1" required>
                </div>




                <div class="form-group">
                    <label class="form-label">Job Details/รายละเอียดงาน</label>
                    <textarea id="job-details" name="description" placeholder="" ></textarea>
                </div>

                <!--ปุ่มส่ง-->
                <div class="submit-group">
                    <button type="submit" class="submit-btn">Add Job</button>
                </div>
            </form>
            
        </div>
        </div>
    </main>
    <footer class="footer">
        <p>© CSIT - Computer Science and Information Technology</p>
    </footer>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script src="js/jobpost.js"></script>
    <script>
        function searchSkill() {
            let searchValue = document.getElementById("skillSearch").value.toLowerCase();
            let skills = document.querySelectorAll("#skillsList .skill-item");

                skills.forEach(function(skill) {
                    let skillText = skill.getAttribute("data-skill");
                        if (skillText.includes(searchValue)) {
                            skill.style.display = "block";  // ✅ แสดงเมื่อพบ
                        } else {
                            skill.style.display = "none";   // ❌ ซ่อนเมื่อไม่พบ
                        }
                    });
                }
    </script>
    <script>
        document.getElementById("reward-type-select").addEventListener("change", function () {
        const rewardType = this.value;
        const rewardInputContainer = document.getElementById("reward-input-container");
        const rewardLabelText = document.getElementById("reward-label-text");
        const rewardUnit = document.getElementById("reward-unit");
        const rewardInput = document.getElementById("reward-input");

        if (rewardType) {
            if (rewardType == "1") {
                rewardLabelText.textContent = "Hours/จำนวนชั่วโมง";
                rewardUnit.textContent = "ชั่วโมง";
                rewardInput.placeholder = "กรอกจำนวนชั่วโมงที่ต้องการให้ผู้สมัครทำงาน";
            } else if (rewardType == "2") {
                rewardLabelText.textContent = "Money/จำนวนเงิน";
                rewardUnit.textContent = "บาท";
                rewardInput.placeholder = "กรอกจำนวนเงินที่ต้องการให้ผู้สมัครทำงาน";
            } else if (rewardType == "3") {
                rewardLabelText.textContent = "Money/จำนวนเงิน";
                rewardUnit.textContent = "บาท";
                rewardInput.placeholder = "กรอกจำนวนเงินที่ต้องการให้ผู้สมัครทำงาน";
            }

            rewardInputContainer.style.display = "block";
        } else {
            rewardInputContainer.style.display = "none";
        }
    });
    </script>
    <script>
        document.addEventListener("DOMContentLoaded", function () {
    const skillSelect = document.getElementById("skill-select");
    const subskillContainer = document.getElementById("skill-sub-container");
    const subskillSelect = document.getElementById("sub-skill-select");

    skillSelect.addEventListener("change", function () {
        const skillId = this.value;

        // เคลียร์ค่าเดิม
        subskillSelect.innerHTML = '<option value="">-- เลือกสกิลย่อย --</option>';

        if (skillId) {
            fetch(`get_subskill.php?skill_id=${skillId}`)
                .then(response => response.json())
                .then(data => {
                    if (data.length > 0) {
                        data.forEach(subskill => {
                            const option = document.createElement("option");
                            option.value = subskill.id;
                            option.textContent = subskill.name;
                            subskillSelect.appendChild(option);
                        });
                        subskillContainer.style.display = "block";
                    } else {
                        subskillContainer.style.display = "none";
                    }
                })
                .catch(err => {
                    console.error("❌ Error loading subskill:", err);
                    subskillContainer.style.display = "none";
                });
        } else {
            subskillContainer.style.display = "none";
        }
    });
});
    </script>
        
</body>

</html>