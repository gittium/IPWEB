<?php
header('Content-Type: application/json');
include 'database.php'; // เชื่อมต่อฐานข้อมูล

// รับข้อมูลจาก AJAX
$data = json_decode(file_get_contents('php://input'), true);
$applicationId = $data['applicationId'] ?? null;
$action = $data['action'] ?? null; // "approve" หรือ "reject"

if (!$applicationId || !$action) {
    echo json_encode(['success' => false, 'message' => 'ข้อมูลไม่ครบถ้วน']);
    exit;
}

// ตรวจสอบว่าใบสมัครมีอยู่จริง
$sql = "SELECT job_application.job_app_id, job_application.students_id, 
        job_application.post_jobs_id, post_jobs.title 
        FROM job_application 
        JOIN post_jobs ON job_application.post_jobs_id = post_jobs.post_jobs_id 
        WHERE job_application.job_app_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $applicationId);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 0) {
    echo json_encode(['success' => false, 'message' => '❌ ไม่พบใบสมัครนี้ในระบบ กรุณาตรวจสอบอีกครั้ง!']);
    exit;
}

$job_application = $result->fetch_assoc();
$students_id = $job_application['students_id'];
$post_id = $job_application['post_jobs_id'];
$job_title = $job_application['title']; // ดึงชื่องาน

// ตรวจสอบว่ามีการดำเนินการ (approve/reject) ไปแล้วหรือไม่
$sql_check = "SELECT accept_status_id FROM accepted_application WHERE job_app_id = ?";
$stmt_check = $conn->prepare($sql_check);
$stmt_check->bind_param("i", $applicationId);
$stmt_check->execute();
$result_check = $stmt_check->get_result();

if ($result_check->num_rows > 0) {
    $existing_status = $result_check->fetch_assoc();
    $existing_status_id = $existing_status['accept_status_id'];

    if ($existing_status_id == 1) {
        echo json_encode(['success' => false, 'message' => '⚠️ ใบสมัครนี้ได้รับการอนุมัติไปแล้ว!']);
    } elseif ($existing_status_id == 2) {
        echo json_encode(['success' => false, 'message' => '⚠️ ใบสมัครนี้ได้รับการปฏิเสธไปแล้ว!']);
    }
    exit;
}

// ดำเนินการตาม action
date_default_timezone_set('Asia/Bangkok'); // ตั้งค่า Timezone เป็นเวลาประเทศไทย // เวลาปัจจุบัน
$created_at = date('Y-m-d H:i:s');

if ($action === "reject") {
    $accept_status_id = 2; // Rejected

    $sql = "INSERT INTO accepted_application (job_app_id, post_jobs_id, students_id, accept_status_id, created_at) 
            VALUES (?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("iiiis", $applicationId, $post_id, $students_id, $accept_status_id, $created_at);

    if ($stmt->execute()) {
        $reference_id = $conn->insert_id; // ดึง ID ที่บันทึกล่าสุด

        // เพิ่มข้อมูลการแจ้งเตือน
        $user_id = $students_id;
        $roles_id = 4; // roles_id = 4 สำหรับผู้สมัคร
        $event_type = 'job_accepted';
        $reference_table = 'accepted_application';
        $message = "❌ ใบสมัครของคุณสำหรับงาน '$job_title' ได้รับการปฏิเสธแล้ว!";
        $status = 'unread';

        $sql_notify = "INSERT INTO notification (user_id, roles_id, event_type, reference_table, reference_id, message, status, created_at) 
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt_notify = $conn->prepare($sql_notify);
        $stmt_notify->bind_param("iississs", $user_id, $roles_id, $event_type, $reference_table, $reference_id, $message, $status, $created_at);

        if ($stmt_notify->execute()) {
            echo json_encode(['success' => true, 'message' => "❌ ปฏิเสธใบสมัครสำหรับงาน '$job_title' เรียบร้อยแล้ว!"]);
        } else {
            echo json_encode(['success' => true, 'message' => '⚠️ ปฏิเสธสำเร็จ แต่ไม่สามารถส่งการแจ้งเตือนได้!']);
        }
    } else {
        echo json_encode(['success' => false, 'message' => '❌ เกิดข้อผิดพลาดในการปฏิเสธใบสมัคร กรุณาลองใหม่อีกครั้ง!']);
    }
} elseif ($action === "approve") {
    $accept_status_id = 1; // Approved

    $sql = "INSERT INTO accepted_application (job_app_id, post_jobs_id, students_id, accept_status_id, created_at) 
            VALUES (?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("iiiis", $applicationId, $post_id, $students_id, $accept_status_id, $created_at);

    if ($stmt->execute()) {
        $reference_id = $conn->insert_id; // ดึง ID ที่บันทึกล่าสุด

        // เพิ่มข้อมูลการแจ้งเตือน
        $user_id = $students_id;
        $roles_id = 4; // roles_id = 4 สำหรับผู้สมัคร
        $event_type = 'job_accepted';
        $reference_table = 'accepted_application';
        $message = "✅ ใบสมัครของคุณสำหรับงาน '$job_title' ได้รับการอนุมัติแล้ว!";
        $status = 'unread';

        $sql_notify = "INSERT INTO notification (user_id, roles_id, event_type, reference_table, reference_id, message, status, created_at) 
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt_notify = $conn->prepare($sql_notify);
        $stmt_notify->bind_param("iississs", $user_id, $roles_id, $event_type, $reference_table, $reference_id, $message, $status, $created_at);

        if ($stmt_notify->execute()) {
            echo json_encode(['success' => true, 'message' => "✅ อนุมัติใบสมัครสำหรับงาน '$job_title' เรียบร้อยแล้ว!"]);
        } else {
            echo json_encode(['success' => true, 'message' => '⚠️ อนุมัติสำเร็จ แต่ไม่สามารถส่งการแจ้งเตือนได้!']);
        }
    } else {
        echo json_encode(['success' => false, 'message' => '❌ เกิดข้อผิดพลาดในการบันทึกข้อมูล กรุณาลองใหม่อีกครั้ง!']);
    }
}

$stmt->close();
$conn->close();
?>