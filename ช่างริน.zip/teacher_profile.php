<?php
session_start();
include 'database.php';

/* ------------------------------------------------------------------
   (1) ตรวจจับ POST: อัปเดต Contact (teachers) + Job (post_jobs)
   ------------------------------------------------------------------ */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // 1. รับค่า phone_number, email (Contact)
    $user_id     = $_SESSION['user_id'] ?? 0;
    $phone_number = $_POST['phone_number'] ?? '';
    $email        = $_POST['email'] ?? '';

    // 2. อัปเดตข้อมูลตาราง teachers
    $sqlTeacher = "UPDATE teachers
                   SET Phone_number = ?,
                       email = ?
                   WHERE id = ?";
    $stmtT = $conn->prepare($sqlTeacher);
    $stmtT->bind_param("ssi", $phone_number, $email, $user_id);

    if (!$stmtT->execute()) {
        echo "error_teachers";
        exit();
    }
    $stmtT->close();

    // 3. รับ job_data ที่เป็น JSON => แปลงเป็น Array
    $jobDataJson = $_POST['job_data'] ?? '[]';
    $jobData = json_decode($jobDataJson, true);
    // จะเป็น array ของ jobs เช่น [ {id:1, title:'...', description:'...', number_student:'...'}, ... ]

    // 4. วนลูปอัปเดต post_jobs ทีละตัว
    //    สมมติฟิลด์ title, description, number_student
    foreach ($jobData as $job) {
        $job_id          = $job['id'] ?? 0;
        $title           = $job['title'] ?? '';
        $description     = $job['description'] ?? '';
        $number_student  = $job['number_student'] ?? 0;

        // UPDATE job เฉพาะของอาจารย์คนนี้ => ป้องกันแก้ไขงานของผู้อื่น
        $sqlJob = "UPDATE post_jobs
                   SET title = ?,
                       description = ?,
                       number_student = ?
                   WHERE id = ? 
                     AND teacher_id = ?";
        $stmtJ = $conn->prepare($sqlJob);
        $stmtJ->bind_param("ssiii", $title, $description, $number_student, $job_id, $user_id);

        if (!$stmtJ->execute()) {
            echo "error_jobs";
            exit();
        }
        $stmtJ->close();
    }

    // ถ้าไม่มีปัญหาใด ๆ
    $conn->close();
    echo "success";
    exit();
}

/* ------------------------------------------------------------------
   (2) ถ้าเป็น GET ?id=... => อัปเดต notifications.status = read
   ------------------------------------------------------------------ */
if (isset($_GET['id'])) {
    $notification_id = intval($_GET['id']);

    $update_sql = "UPDATE notifications SET status = 'read' WHERE id = ?";
    $stmt = $conn->prepare($update_sql);
    $stmt->bind_param("i", $notification_id);

    if ($stmt->execute()) {
        echo json_encode(["success" => true, "id" => $notification_id]);
    } else {
        echo json_encode(["success" => false, "error" => $conn->error]);
    }
    $stmt->close();
    $conn->close();
    exit();
}

/* ------------------------------------------------------------------
   (3) โหลดหน้าเว็บปกติ: ดึง Contact (teachers), jobs (post_jobs), etc.
   ------------------------------------------------------------------ */
$user_id = $_SESSION['user_id'] ?? 0;

// --3.1 ดึง Notifications--
$sql = "SELECT 
            n.id AS notification_id,
            n.message,
            n.created_at,
            n.status,
            a.accept_status_id,
            s.accept_name_status
        FROM notifications n
        JOIN accepted_applications a ON n.reference_id = a.id
        JOIN accept_status s ON a.accept_status_id = s.id
        WHERE n.user_id = ?
        ORDER BY n.created_at DESC";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$resNoti = $stmt->get_result();

$notifications = [];
$unread_count = 0;
while ($rowN = $resNoti->fetch_assoc()) {
    $notifications[] = [
        'id' => $rowN['notification_id'],
        'title' => $rowN['accept_name_status'],
        'message' => $rowN['message'],
        'time' => $rowN['created_at'],
        'status' => strtolower($rowN['status']),
        'accept_status_id' => $rowN['accept_status_id'] ?? null
    ];
    if (strtolower($rowN['status']) === 'unread') {
        $unread_count++;
    }
}
$stmt->close();

// --3.2 ดึงข้อมูลอาจารย์ (Contact)
$sqlTeacher = "SELECT 
                  t.id,
                  t.name,
                  t.email,
                  t.department_id,
                  t.Phone_number,
                  m.id AS mojor_id,
                  m.mojor_name AS department_name
               FROM teachers t
               JOIN mojor m ON t.department_id = m.id
               WHERE t.id = ?";
$stmtT = $conn->prepare($sqlTeacher);
$stmtT->bind_param("i", $user_id);
$stmtT->execute();
$resT = $stmtT->get_result();
$teacher = $resT->fetch_assoc();
$stmtT->close();

// --3.3 (ถ้ามี Review)
$sqlReview = "SELECT 
                AVG(rating) AS avg_rating,
                COUNT(*) AS review_count
              FROM reviews
              WHERE teacher_id = ?";
$stmtR = $conn->prepare($sqlReview);
$stmtR->bind_param("i", $user_id);
$stmtR->execute();
$resR = $stmtR->get_result();
$avg_rating = 0;
$review_count = 0;
if ($rowR = $resR->fetch_assoc()) {
    $avg_rating   = round($rowR['avg_rating']);
    $review_count = $rowR['review_count'];
}
$stmtR->close();

// --3.4 ดึง job ของอาจารย์ (post_jobs)
$sqlJobs = "SELECT * 
            FROM post_jobs
            WHERE teacher_id = ?
            ORDER BY created_at DESC";
$stmtJ = $conn->prepare($sqlJobs);
$stmtJ->bind_param("i", $user_id);
$stmtJ->execute();
$resJobs = $stmtJ->get_result();
$jobs = [];
while ($rowJob = $resJobs->fetch_assoc()) {
    $jobs[] = $rowJob;
}
$stmtJ->close();

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Teacher Profile</title>

    <!-- Bootstrap & Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
        rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH"
        crossorigin="anonymous">

    <!-- ปรับความกว้างการ์ดให้มากขึ้น: minmax(400px, 1fr) -->
    <style>
        /* จัด layout เป็นแบบ Grid */
        .grid {
    display: flex;           /* ใช้ Flexbox แทน Grid */
    flex-wrap: nowrap;       /* ไม่ให้ขึ้นบรรทัดใหม่ */
    overflow-x: auto;        /* เลื่อนในแนวนอนได้ */
    gap: 20px;               /* ระยะห่างระหว่างการ์ด */
    padding: 10px;
        }
        /* ปรับดีไซน์ของการ์ด */
        .card {
            background-color: #ffffff;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.15);
            overflow: hidden;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }

        .card-top {
            height: 150px; /* ความสูง fix ส่วนรูปภาพ */
            overflow: hidden;
        }

        .card-top img {
            width: 100%;
            height: 100%;
            object-fit: cover; /* จัดรูปภาพเต็มพื้นที่ card-top */
        }

        .card h3 {
            margin: 10px 0 5px;
            padding: 0 10px; 
        }

        /* จำกัดข้อความไม่ให้เกิน 3 บรรทัด (ถ้าไม่อยากตัดก็ลบได้) */
        .card p {
            margin: 0 0 5px;
            padding: 0 10px; 
            display: -webkit-box;
            -webkit-line-clamp: 3; 
            -webkit-box-orient: vertical;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        /* ส่วนโหมดแก้ไข (job_edit) */
        .job_edit {
            padding: 10px;
        }

        .job_edit label {
            font-weight: bold;
        }
    </style>

    <!-- ไฟล์ CSS ของคุณ -->
    <link rel="stylesheet" href="css/header-footer.html">
    <link rel="stylesheet" href="css/header-footerstyle.css">
    <link rel="stylesheet" href="css/TeacherProfileStyle.css">
    <link rel="stylesheet" href="css/header-footer.html">
</head>

<body>
    <div class="profile-container">

        <!-- Header -->
        <header class="headerTop">
            <div class="headerTopImg">
                <img src="logo.png" alt="Naresuan University Logo">
                <a href="#">Naresuan University</a>
            </div>
            <nav class="header-nav">
                <a href="/homeaj/index.html">Home</a>
                <a href="#">News</a>
                <nav class="header-nav">
                    <?php
                    if (isset($_SESSION['user_id'])) {
                        echo '<a href="logout.php">Logout</a>';
                    } else {
                        echo '<a href="login.php">Login</a>';
                    }
                    ?>
                </nav>
            </nav>
        </header>
        <!-- End Header -->

        <!-- โปรไฟล์ส่วนบน -->
        <div class="header">
            <div class="profile">
                <div class="profile-pic">
                    <?php echo strtoupper(mb_substr($teacher['name'], 0, 1, 'UTF-8')); ?>
                </div>
                <div class="detail-name">
                    <div class="name">
                        <?php echo htmlspecialchars($teacher['name'], ENT_QUOTES, 'UTF-8'); ?>
                    </div>
                    <div class="sub-title">
                        อาจารย์ภาควิชา <?php echo htmlspecialchars($teacher['department_name'], ENT_QUOTES, 'UTF-8'); ?>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Header Profile -->

        <!-- Content -->
        <div class="content">
            <div class="detail-head">
                <div class="review">
                    <div class="review-detail">
                        <!-- ถ้าจะแสดงคะแนน/รีวิว -->
                    </div>
                </div>
                <div>
                    <!-- Notification btn -->
                    <button class="notification-btn">
                        <i class="bi bi-bell"></i>
                        <span class="notification-badge"
                            <?php echo ($unread_count == 0) ? 'style="display:none;"' : ''; ?>>
                            <?php echo $unread_count; ?>
                        </span>
                    </button>

                    <!-- Notifications card -->
                    <div class="notifications-card" id="notifications">
                        <div class="headerNoti">
                            <h1 class="page-title">Notifications</h1>
                            <span class="notification-count"
                                <?php echo ($unread_count == 0) ? 'style="display:none;"' : ''; ?>>
                                <?php echo $unread_count; ?> new
                            </span>
                            <button class="close-button" id="close-notifications">&times;</button>
                        </div>
                        <div class="tabs">
                            <div class="tab active" data-filter="all">All</div>
                            <div class="tab" data-filter="unread">Unread</div>
                            <div class="tab" data-filter="accepted">Accepted</div>
                            <div class="tab" data-filter="reject">Rejected</div>
                        </div>
                        <div class="notification-list" id="notification-list">
                            <?php foreach ($notifications as $notification) { ?>
                                <div class="notification-item" data-status="<?php echo $notification['status']; ?>">
                                    <div class="notification-content">
                                        <h3 class="notification-title"><?php echo $notification['title']; ?></h3>
                                        <p class="notification-message"><?php echo $notification['message']; ?></p>
                                        <span class="notification-time"><?php echo $notification['time']; ?></span>
                                    </div>
                                </div>
                            <?php } ?>
                        </div>
                    </div>

                    <!-- Add Job -->
                    <a href="jobpost.php">
                        <button class="addJob-button">Add Job</button>
                    </a>

                    <!-- ปุ่ม Edit -->
                    <button class="edit-button" onclick="toggleEdit()">Edit</button>
                </div>
            </div>
        </div>

        <!-- Contact -->
        <div class="container">
            <h3>Contact</h3>
            <section class="Contact">
                <!-- โหมดแสดง -->
                <div id="contact_display">
                    <p>เบอร์โทร : <?php echo htmlspecialchars($teacher['Phone_number'], ENT_QUOTES, 'UTF-8'); ?></p>
                    <p>อีเมล : <?php echo htmlspecialchars($teacher['email'], ENT_QUOTES, 'UTF-8'); ?></p>
                </div>

                <!-- โหมดแก้ไข -->
                <div id="contact_edit" style="display:none;">
                    <label for="phone_number_input">เบอร์โทร :</label>
                    <input type="text" id="phone_number_input"
                        value="<?php echo htmlspecialchars($teacher['Phone_number'], ENT_QUOTES, 'UTF-8'); ?>">

                    <br><br>
                    <label for="email_input">อีเมล :</label>
                    <input type="email" id="email_input"
                        value="<?php echo htmlspecialchars($teacher['email'], ENT_QUOTES, 'UTF-8'); ?>">
                </div>
            </section>
        </div>

        <!-- Job -->
        <div class="container">
            <h3>Job</h3>
            <div class="content">
                <div class="grid" id="job_container">
                    <?php foreach ($jobs as $job) { ?>
                        <div class="card" data-job-id="<?php echo $job['id']; ?>">
                            <!-- โหมดแสดง -->
                            <div class="job_display" id="job_display_<?php echo $job['id']; ?>">
                                <div class="card-top" style="height:150px; overflow:hidden;">
                                    <img src="<?php echo htmlspecialchars($job['image'], ENT_QUOTES, 'UTF-8'); ?>"
                                        style="width:100%; height:100%; object-fit:cover;"
                                        alt="Job Image">
                                </div>
                                <h3><?php echo htmlspecialchars($job['title'], ENT_QUOTES, 'UTF-8'); ?></h3>
                                <p><?php echo htmlspecialchars($job['description'], ENT_QUOTES, 'UTF-8'); ?></p>
                                <p>รับจำนวน: <?php echo $job['number_student']; ?> คน</p>
                                <p>ประกาศเมื่อ: <?php echo $job['created_at']; ?></p>
                            </div>

                            <!-- โหมดแก้ไข -->
                            <div class="job_edit" id="job_edit_<?php echo $job['id']; ?>" style="display:none;">
                                <div class="card-top" style="height:150px; background:#eee; text-align:center;">
                                    <small>รูป: (แก้ไขในระบบ upload แยก)</small>
                                </div>
                                <label>Title:</label>
                                <input type="text" id="title_input_<?php echo $job['id']; ?>"
                                    value="<?php echo htmlspecialchars($job['title'], ENT_QUOTES, 'UTF-8'); ?>">

                                <br><br>
                                <label>Description:</label>
                                <textarea id="desc_input_<?php echo $job['id']; ?>" rows="3" style="width:100%;">
                                <?php echo htmlspecialchars($job['description'], ENT_QUOTES, 'UTF-8'); ?>
                            </textarea>

                                <br><br>
                                <label>Number Student:</label>
                                <input type="number" min="0" id="num_input_<?php echo $job['id']; ?>"
                                    value="<?php echo (int)$job['number_student']; ?>">
                            </div>
                        </div>
                    <?php } ?>
                </div>
            </div>
        </div>

        <!-- ปุ่ม Save อยู่ด้านล่าง job -->
        <div class="container">
            <button class="save-button" style="display:none;" onclick="saveChanges()">Save</button>
        </div>

        <!-- Footer -->
        <footer class="footer">
            <p>© CSIT - Computer Science and Information Technology</p>
        </footer>
    </div>

    <!-- Script: จัดการ Notifications -->
    <script>
        const notificationButton = document.querySelector('.notification-btn');
        const notificationsCard = document.getElementById('notifications');
        const closeButton = document.getElementById('close-notifications');

        notificationButton.addEventListener('click', () => {
            notificationsCard.style.display = 'block';
        });
        closeButton.addEventListener('click', () => {
            notificationsCard.style.display = 'none';
        });
        document.addEventListener('click', (event) => {
            if (!notificationsCard.contains(event.target) && !notificationButton.contains(event.target)) {
                notificationsCard.style.display = 'none';
            }
        });
    </script>

    <!-- Script: Tabs Filtering Notifications -->
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            const tabs = document.querySelectorAll(".tab");
            const notificationList = document.getElementById("notification-list");

            let notifications = <?php echo json_encode($notifications); ?> || [];

            function updateNotifications(filterType) {
                notificationList.innerHTML = "";
                notifications.forEach((notification, index) => {
                    if (
                        filterType === "all" ||
                        (filterType === "unread" && notification.status === "unread") ||
                        (filterType === "accepted" && notification.title === "Accepted") ||
                        (filterType === "reject" && notification.title === "Rejected")
                    ) {
                        const notificationItem = document.createElement("div");
                        notificationItem.classList.add("notification-item", notification.status);
                        notificationItem.dataset.status = notification.status;
                        notificationItem.innerHTML = `
                    <div class="notification-content">
                        <h3 class="notification-title">${notification.title}</h3>
                        <p class="notification-message">${notification.message}</p>
                        <span class="notification-time">${notification.time}</span>
                    </div>
                `;
                        if (notification.status === "unread") {
                            notificationItem.addEventListener("click", function() {
                                markAsRead(notification.id, index);
                            });
                        }
                        notificationList.appendChild(notificationItem);
                    }
                });
            }

            function markAsRead(notificationId, index) {
                fetch(`?id=${notificationId}`)
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            notifications[index].status = "read";
                            let badge = document.querySelector(".notification-badge");
                            let currentCount = parseInt(badge.innerText) || 0;
                            if (currentCount > 0) {
                                let newCount = currentCount - 1;
                                badge.innerText = newCount;
                                if (newCount === 0) {
                                    badge.style.display = "none";
                                }
                            }
                            const activeTab = document.querySelector(".tab.active");
                            updateNotifications(activeTab.getAttribute("data-filter"));
                        }
                    })
                    .catch(error => console.error("Error updating notification:", error));
            }

            tabs.forEach(tab => {
                tab.addEventListener("click", function() {
                    tabs.forEach(t => t.classList.remove("active"));
                    this.classList.add("active");
                    updateNotifications(this.getAttribute("data-filter"));
                });
            });

            updateNotifications("all");
        });
    </script>

    <!-- Script: toggleEdit (Contact + Job) + saveChanges -->
    <script>
        function toggleEdit() {
            // 1) Contact
            const cDisplay = document.getElementById('contact_display');
            const cEdit = document.getElementById('contact_edit');

            // 2) Job: วนลูป card .job_display / .job_edit
            const jobCards = document.querySelectorAll('.card[data-job-id]');

            // 3) ปุ่ม Save
            const saveBtn = document.querySelector('.save-button');

            // ถ้าปัจจุบันยังเป็นโหมดแสดง => ไปโหมดแก้ไข
            if (cDisplay.style.display !== 'none') {
                // Contact
                cDisplay.style.display = 'none';
                cEdit.style.display = 'block';

                // Job
                jobCards.forEach(card => {
                    const jobId = card.getAttribute('data-job-id');
                    const dispEl = document.getElementById('job_display_' + jobId);
                    const editEl = document.getElementById('job_edit_' + jobId);
                    if (dispEl && editEl) {
                        dispEl.style.display = 'none';
                        editEl.style.display = 'block';
                    }
                });

                // ปุ่ม Save
                saveBtn.style.display = 'inline-block';
            } else {
                // กลับไปโหมดแสดง
                cDisplay.style.display = 'block';
                cEdit.style.display = 'none';

                jobCards.forEach(card => {
                    const jobId = card.getAttribute('data-job-id');
                    const dispEl = document.getElementById('job_display_' + jobId);
                    const editEl = document.getElementById('job_edit_' + jobId);
                    if (dispEl && editEl) {
                        dispEl.style.display = 'block';
                        editEl.style.display = 'none';
                    }
                });

                saveBtn.style.display = 'none';
            }
        }

        function saveChanges() {
            // 1) Contact
            const newPhone = document.getElementById('phone_number_input').value.trim();
            const newEmail = document.getElementById('email_input').value.trim();

            // 2) Job => สร้าง array jobData
            let jobData = [];
            const jobCards = document.querySelectorAll('.card[data-job-id]');
            jobCards.forEach(card => {
                const jobId = card.getAttribute('data-job-id');
                // รับค่า input
                const titleVal = document.getElementById('title_input_' + jobId).value.trim();
                const descVal = document.getElementById('desc_input_' + jobId).value.trim();
                const numVal = parseInt(document.getElementById('num_input_' + jobId).value) || 0;

                jobData.push({
                    id: jobId,
                    title: titleVal,
                    description: descVal,
                    number_student: numVal
                });
            });

            // 3) AJAX
            let xhr = new XMLHttpRequest();
            xhr.open("POST", "teacher_profile.php", true);
            xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

            xhr.onreadystatechange = function() {
                if (xhr.readyState === 4 && xhr.status === 200) {
                    console.log("Response:", xhr.responseText);
                    if (xhr.responseText === "success") {
                        // อัปเดตหน้า
                        // (1) contact_display
                        document.getElementById('contact_display').innerHTML = `
                    <p>เบอร์โทร : ${newPhone}</p>
                    <p>อีเมล : ${newEmail}</p>
                `;
                        // (2) job_display
                        jobData.forEach(job => {
                            document.getElementById('job_display_' + job.id).innerHTML = `
                        <div class="card-top" style="height:150px; overflow:hidden;">
                            <img src="${ document.querySelector('#job_display_'+job.id+' img')?.getAttribute('src') || '' }"
                                 style="width:100%; height:100%; object-fit:cover;"
                                 alt="Job Image">
                        </div>
                        <h3>${job.title}</h3>
                        <p>${job.description}</p>
                        <p>รับจำนวน: ${job.number_student} คน</p>
                    `;
                        });
                        // ปิดโหมดแก้ไข
                        toggleEdit();
                    } else {
                        alert("Update Error: " + xhr.responseText);
                    }
                }
            };

            // 4) ส่งค่า
            let postData = "phone_number=" + encodeURIComponent(newPhone) +
                "&email=" + encodeURIComponent(newEmail) +
                "&job_data=" + encodeURIComponent(JSON.stringify(jobData));
            xhr.send(postData);
        }
    </script>
</body>

</html>

<?php $conn->close(); ?>